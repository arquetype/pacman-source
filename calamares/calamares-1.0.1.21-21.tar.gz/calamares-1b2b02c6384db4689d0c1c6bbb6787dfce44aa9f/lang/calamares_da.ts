<?xml version="1.0" ?><!DOCTYPE TS><TS language="da" version="2.1">
<context>
    <name>AlongsidePage</name>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="67"/>
        <source>Choose partition to shrink:</source>
        <translation>Vælg partitionen der skal krympes:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="68"/>
        <source>Allocate drive space by dragging the divider below:</source>
        <translation>Fordel disk plads ved at trække fordeleren nedenunder:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="167"/>
        <source>With this operation, the partition &lt;b&gt;%1&lt;/b&gt; which contains %4 will be shrunk to %2MB and a new %3MB partition will be created for %5.</source>
        <translation>Med denne handling, vil partitionen &lt;b&gt;%1&lt;/b&gt; der indeholder %4 blive krympet til %2MB og en ny partition på %3MB vil blive lavet til %5.</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="37"/>
        <source>Save</source>
        <translation>Gem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="44"/>
        <source>Open in External Browser</source>
        <translation>Åbn i Extern Browser</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="33"/>
        <source>Operations and Jobs</source>
        <translation>Handlinger og Jobs</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="38"/>
        <source>Time Elapsed</source>
        <translation>Tid Gået</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="64"/>
        <source>Total Time: 00:00:00</source>
        <translation>Total Tid: 00:00:00</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="81"/>
        <source>Operation: %p%</source>
        <translation>Handling: %p%</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="91"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="107"/>
        <source>Total: %p%</source>
        <translation>Total: %p%</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="20"/>
        <source>Installer</source>
        <translation>Installationsprogram</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="168"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Welcome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Velkommen&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="198"/>
        <source>Location</source>
        <translation>Lokation</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="224"/>
        <source>License Approval</source>
        <translation>Licens Godkendelse</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="257"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Installation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Installation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="287"/>
        <source>Install System</source>
        <translation>Installér System</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="320"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Configuration&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Konfiguration&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="331"/>
        <source>Reboot</source>
        <translation>Genstart</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="410"/>
        <source>Language</source>
        <translation>Sprog</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="443"/>
        <source>User Info</source>
        <translation>Bruger Information</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="469"/>
        <source>Summary</source>
        <translation>Resumé</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="514"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="521"/>
        <source>Disk Setup</source>
        <translation>Disk Indstilling</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="528"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Preparation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Forberedelse&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>BootLoaderModel</name>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="57"/>
        <source>Master Boot Record of %1</source>
        <translation>Master Boot Record af %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="71"/>
        <source>Boot Partition</source>
        <translation>Boot Partition</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="76"/>
        <source>System Partition</source>
        <translation>System Partition</translation>
    </message>
</context>
<context>
    <name>Calamares::DebugWindow</name>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="24"/>
        <source>GlobalStorage</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="34"/>
        <source>JobQueue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="44"/>
        <source>Modules</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.cpp" line="95"/>
        <source>Debug information</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Calamares::InstallationViewStep</name>
    <message>
        <location filename="../src/libcalamaresui/InstallationViewStep.cpp" line="75"/>
        <source>Install</source>
        <translation>Installér</translation>
    </message>
</context>
<context>
    <name>Calamares::JobThread</name>
    <message>
        <location filename="../src/libcalamares/JobQueue.cpp" line="88"/>
        <source>Done</source>
        <translation>Færdig</translation>
    </message>
</context>
<context>
    <name>Calamares::ProcessJob</name>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="51"/>
        <source>Run command %1 %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="79"/>
        <source>External command crashed</source>
        <translation>Extern kommando fejlede</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="80"/>
        <source>Command %1 crashed.
Output:
%2</source>
        <translation>Kommando %1 fejlede.
Udskrift:
%2</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="85"/>
        <source>External command failed to start</source>
        <translation>Extern kommando fejlede i at starte</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="86"/>
        <source>Command %1 failed to start.</source>
        <translation>Kommando %1 fejlede i at starte.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="90"/>
        <source>Internal error when starting command</source>
        <translation>Intern fejl ved start af kommando</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="91"/>
        <source>Bad parameters for process job call.</source>
        <translation>Dårlige parametre til process job kald.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="94"/>
        <source>External command failed to finish</source>
        <translation>Extern kommando fejlede i at færdiggøre</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="95"/>
        <source>Command %1 failed to finish in %2s.
Output:
%3</source>
        <translation>Kommando %1 fejlede i at færdiggøre efter %2s.
Udskrift:
%3</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="101"/>
        <source>External command finished with errors</source>
        <translation>Extern kommando blev færdiggjort uden fejl</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="102"/>
        <source>Command %1 finished with exit code %2.
Output:
%3</source>
        <translation>Kommando %1 blev færdiggjort med exit kode %2.
Udskrift:
%3</translation>
    </message>
</context>
<context>
    <name>Calamares::PythonJob</name>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="234"/>
        <source>Run script %1</source>
        <translation>Kør script %1</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="249"/>
        <source>Bad working directory path</source>
        <translation>Dårlig arbejdsmappe sti</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="250"/>
        <source>Working directory %1 for python job %2 is not readable.</source>
        <translation>Arbejdsmappe %1 for python job %2 er ikke læsbar.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="260"/>
        <source>Bad main script file</source>
        <translation>Dårlig hoved script fil</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="261"/>
        <source>Main script file %1 for python job %2 is not readable.</source>
        <translation>Hoved script fil %1 for python job %2 er ikke læsbar.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="306"/>
        <source>Boost.Python error in job &quot;%1&quot;.</source>
        <translation>Boost.Python fejl i job &quot;%1&quot;.</translation>
    </message>
</context>
<context>
    <name>Calamares::ViewManager</name>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="64"/>
        <source>&amp;Back</source>
        <translation>&amp;Tilbage</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="65"/>
        <source>&amp;Next</source>
        <translation>&amp;Næste</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="66"/>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="302"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Annullér</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="86"/>
        <source>Cancel installation?</source>
        <translation>Annullér installationen?</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="87"/>
        <source>Do you really want to cancel the current install process?
The installer will quit and all changes will be lost.</source>
        <translation>Vil du virkelig annullere den igangværende installationsprocess?
Installationsprogrammet vil stoppe og alle ændringer vil gå tabt.</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="272"/>
        <source>&amp;Quit</source>
        <translation>&amp;Opgiv</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="183"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="184"/>
        <source>Installation Failed</source>
        <translation>Installation Fejlede</translation>
    </message>
</context>
<context>
    <name>CalamaresPython::Helper</name>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="234"/>
        <source>Unknown exception type</source>
        <translation>Ukendt undtagelsestype</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="247"/>
        <source>unparseable Python error</source>
        <translation>Utilgængelig Python-fejl</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="263"/>
        <source>unparseable Python traceback</source>
        <translation>Utilgængeligt Python-traceback</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="267"/>
        <source>Unfetchable Python error.</source>
        <translation>Uhentbar Python fejl.</translation>
    </message>
</context>
<context>
    <name>CalamaresWindow</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="44"/>
        <source>%1 Installer</source>
        <translation>%1 Installationsprogram</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="98"/>
        <source>Show debug information</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CheckFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="34"/>
        <source>Checking file system on partition %1.</source>
        <translation>Tjekker filsystem på partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="50"/>
        <source>The file system check on partition %1 failed.</source>
        <translation>Filsystem tjekket på partition %1 fejlede.</translation>
    </message>
</context>
<context>
    <name>ChoicePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="115"/>
        <source>This computer currently does not seem to have an operating system on it. What would you like to do?</source>
        <translation>Denne computer ser ikke ud til at have et styresystem. Hvad vil du gerne gøre?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="119"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="187"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="234"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will delete all of your programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;Slet disk og installér %1&lt;/b&gt;&lt;br/&gt;&lt;font color =&quot;red&quot;&gt;Advarsel: &lt;/font&gt;Dette vil slette alle dine programmer, dokumenter, billeder, musik og alle andre filer.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="125"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="162"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="193"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="240"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which disk to erase.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="141"/>
        <source>This computer currently has %1 on it. What would you like to do?</source>
        <translation>Denne computer indeholder %1 lige nu. Hvad vil du gerne gøre?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="145"/>
        <source>&lt;b&gt;Install %2 alongside %1&lt;/b&gt;&lt;br/&gt;The installer will shrink the %1 volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="167"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="198"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="245"/>
        <source>&lt;b&gt;Replace a partition with %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which partition to erase.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="179"/>
        <source>&lt;b&gt;Install %1 alongside your current operating system&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="226"/>
        <source>&lt;b&gt;Install %1 alongside your current operating systems&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="261"/>
        <source>&lt;b&gt;Manual partitioning&lt;/b&gt;&lt;br/&gt;You can create or resize partitions yourself, or choose multiple partitions for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="154"/>
        <source>&lt;b&gt;Erase entire disk with %1 and install %2&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will erase the whole disk and delete all of your %1 programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;Slet hele harddisken med %1 og installér %2&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Advarsel: &lt;/font&gt;Dette vil slette hele harddisken og derved alle dine %1 programmer, dokumenter, billeder, musik, og enhver anden fil.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="176"/>
        <source>This computer already has an operating system on it. What would you like to do?</source>
        <translation>Denne computer har allerede et styresystem installeret. Hvad vil du gerne gøre?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="223"/>
        <source>This computer currently has multiple operating systems on it. What would you like to do?</source>
        <translation>Denne computer har allerede flere styresystemer installeret. Hvad vil du gerne gøre?</translation>
    </message>
</context>
<context>
    <name>ClearMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="42"/>
        <source>Clear mounts for partitioning operations on %1</source>
        <translation>Frigør monteringer til partitionering på %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="81"/>
        <source>Cleared all mounts for %1</source>
        <translation>Frigjorde alle monteringer til %1</translation>
    </message>
</context>
<context>
    <name>ClearTempMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="38"/>
        <source>Clear all temporary mounts.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="49"/>
        <source>Cannot get list of temporary mounts.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="88"/>
        <source>Cleared all temporary mounts.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ConfigurePageAdvanced</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="23"/>
        <source>Permissions</source>
        <translation>Rettigheder</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="35"/>
        <source>Allow applying operations without administrator privileges</source>
        <translation>Tillad at gennemføre handlinger uden administrator rettigheder</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="51"/>
        <source>Backend</source>
        <translation>Backend</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="57"/>
        <source>Active backend:</source>
        <translation>Aktiv backend:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="79"/>
        <source>Units</source>
        <translation>Enheder</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="85"/>
        <source>Preferred unit:</source>
        <translation>Foretrukket enhed:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="96"/>
        <source>Byte</source>
        <translation>Byte</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="101"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="106"/>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="111"/>
        <source>GiB</source>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="116"/>
        <source>TiB</source>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="121"/>
        <source>PiB</source>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="126"/>
        <source>EiB</source>
        <translation>EiB</translation>
    </message>
</context>
<context>
    <name>ConfigurePageFileSystemColors</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="23"/>
        <source>File Systems</source>
        <translation>Filsystem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="29"/>
        <source>luks:</source>
        <translation>luks:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="45"/>
        <source>ntfs:</source>
        <translation>ntfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="58"/>
        <source>ext2:</source>
        <translation>ext2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="87"/>
        <source>ext3:</source>
        <translation>ext3:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="116"/>
        <source>ext4:</source>
        <translation>ext4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="132"/>
        <source>btrfs:</source>
        <translation>btrfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="174"/>
        <source>linuxswap:</source>
        <translation>linuxswap:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="190"/>
        <source>fat16:</source>
        <translation>fat16:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="219"/>
        <source>fat32:</source>
        <translation>fat32:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="248"/>
        <source>zfs:</source>
        <translation>zfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="264"/>
        <source>reiserfs:</source>
        <translation>reiserfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="293"/>
        <source>reiser4:</source>
        <translation>reiser4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="322"/>
        <source>hpfs:</source>
        <translation>hpfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="338"/>
        <source>jfs</source>
        <translation>jfs</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="367"/>
        <source>hfs:</source>
        <translation>hfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="396"/>
        <source>hfsplus:</source>
        <translation>hfsplus:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="412"/>
        <source>ufs:</source>
        <translation>ufs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="441"/>
        <source>xfs:</source>
        <translation>xfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="470"/>
        <source>ocfs2:</source>
        <translation>ocfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="489"/>
        <source>extended:</source>
        <translation>udvidet:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="518"/>
        <source>unformatted:</source>
        <translation>uformateret:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="547"/>
        <source>unknown:</source>
        <translation>ukendt:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="570"/>
        <source>exfat:</source>
        <translation>exfat:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="583"/>
        <source>nilfs2:</source>
        <translation>nilfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="622"/>
        <source>lvm2 pv:</source>
        <translation>lvm2 pv:</translation>
    </message>
</context>
<context>
    <name>ConfigurePageGeneral</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="23"/>
        <source>Partition Alignment</source>
        <translation>Partition Justering</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="29"/>
        <source>Use cylinder based alignment (Windows XP compatible)</source>
        <translation>Brug cylinder baseret justering (Windows XP kompatibel)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="42"/>
        <source>Sector alignment:</source>
        <translation>Sektor justering:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="55"/>
        <source> sectors</source>
        <translation>sektorer</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="71"/>
        <source>Align partitions per default</source>
        <translation>Justér partitioner som standard</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="90"/>
        <source>Logging</source>
        <translation>Logføring</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="96"/>
        <source>Hide messages below:</source>
        <translation>Skjul nedenstående beskeder:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="107"/>
        <source>Debug</source>
        <translation>Fejlfinde</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="112"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="117"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="122"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="139"/>
        <source>File Systems</source>
        <translation>Filsystemer</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="145"/>
        <source>Default file system:</source>
        <translation>Standard filsystem:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="167"/>
        <source>Shredding</source>
        <translation>Markulering</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="173"/>
        <source>Overwrite with:</source>
        <translation>Overskriv med:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="180"/>
        <source>Random data</source>
        <translation>Tilfældig data</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="190"/>
        <source>Zeros</source>
        <translation>Nuller</translation>
    </message>
</context>
<context>
    <name>CreatePartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="14"/>
        <source>Create a Partition</source>
        <translation>Opret en partition</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="38"/>
        <source>Partition &amp;Type:</source>
        <translation>Partition &amp;Type:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="50"/>
        <source>&amp;Primary</source>
        <translation>&amp;Primær</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="60"/>
        <source>E&amp;xtended</source>
        <translation>&amp;Udvidet</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="89"/>
        <source>F&amp;ile System:</source>
        <translation>&amp;Filsystem:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="118"/>
        <source>&amp;Mount Point:</source>
        <translation>&amp;Bindingspunkt:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="164"/>
        <source>Si&amp;ze:</source>
        <translation>&amp;Størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="174"/>
        <source> MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="95"/>
        <source>Logical</source>
        <translation>Logisk</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="100"/>
        <source>Primary</source>
        <translation>Primær</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="117"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
</context>
<context>
    <name>CreatePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="47"/>
        <source>Create partition (file system: %1, size: %2 MB) on %3.</source>
        <translation>Opret partition (filsystem: %1, størrelse: %2 MB) på %3.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="60"/>
        <source>The installer failed to create partition on disk &apos;%1&apos;.</source>
        <translation>Installationsprogrammet fejlede i at oprette partition på disk &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="69"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Kunne ikke åbne enhed &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="79"/>
        <source>Could not open partition table.</source>
        <translation>Kunne ikke åbne partitionstabel.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="103"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>Installationsprogrammet fejlede i at oprette filsystem på partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="111"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>Installationsprogrammet fejlede i at opdatere partitionstabel på disk &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="20"/>
        <source>Create Partition Table</source>
        <translation>Opret partitionstabel</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="39"/>
        <source>Creating a new partition table will delete all existing data on the disk.</source>
        <translation>Hvis du opretter en ny partitionstabel vil det slette alle data på disken.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="65"/>
        <source>What kind of partition table do you want to create?</source>
        <translation>Hvilken slags partitionstabel vil du oprette?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="72"/>
        <source>Master Boot Record (MBR)</source>
        <translation>Master Boot Record (MBR)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="82"/>
        <source>GUID Partition Table (GPT)</source>
        <translation>GUID Partition Table (GPT)</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="48"/>
        <source>Create partition table</source>
        <translation>Opret partitionstabel</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="55"/>
        <source>The installer failed to create a partition table on %1.</source>
        <translation>Installationsprogrammet fejlede i at oprette en partitionstabel på %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="63"/>
        <source>Could not open device %1.</source>
        <translation>Kunne ikke åbne enhed %1.</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="20"/>
        <source>Choose the type of partition table you want to create:</source>
        <translation>Vælg hvilken type partitionstabel du vil oprette:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="29"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="39"/>
        <source>MS-Dos</source>
        <translation>MS-DOS</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="66"/>
        <source>(icon)</source>
        <translation>(ikon)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="79"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; This will destroy all data on the device!</source>
        <translation>&lt;b&gt;Advarsel&lt;/b&gt; Dette vil ødelægge alt data på enheden!</translation>
    </message>
</context>
<context>
    <name>CreateUserJob</name>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="51"/>
        <source>Create user %1</source>
        <translation>Opret bruger %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="67"/>
        <source>Sudoers dir is not writable.</source>
        <translation>Sudoernes mappe er ikke skrivbar.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="71"/>
        <source>Cannot create sudoers file for writing.</source>
        <translation>Kan ikke oprette sudoer fil til skrivning.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="79"/>
        <source>Cannot chmod sudoers file.</source>
        <translation>Kan ikke chmod sudoer filen.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="85"/>
        <source>Cannot open groups file for reading.</source>
        <translation>Kan ikke åbne gruppernes fil til læsning.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="123"/>
        <source>Cannot create user %1.</source>
        <translation>Kan ikke oprette bruger %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="125"/>
        <source>useradd terminated with error code %1.</source>
        <translation>useradd stoppet med fejl kode %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="130"/>
        <source>Cannot set full name for user %1.</source>
        <translation>Kan ikke indstille fuld navn for bruger %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="132"/>
        <source>chfn terminated with error code %1.</source>
        <translation>chfn stoppet med fejl kode %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="141"/>
        <source>Cannot set home directory ownership for user %1.</source>
        <translation>Kan ikke indstille hjemmemappe ejerskab for bruger %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="143"/>
        <source>chown terminated with error code %1.</source>
        <translation>chown stoppet med fejl kode %1.</translation>
    </message>
</context>
<context>
    <name>DecryptLuksDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="22"/>
        <source>&amp;Name:</source>
        <translation>&amp;Navn:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="35"/>
        <source>&amp;Passphrase:</source>
        <translation>&amp;Kodesætning:</translation>
    </message>
</context>
<context>
    <name>DeletePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="41"/>
        <source>Delete partition %1</source>
        <translation>Slet partition %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="48"/>
        <source>The installer failed to delete partition %1.</source>
        <translation>Installationsprogrammet fejlede ved sletning af partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="54"/>
        <source>Partition (%1) and device (%2) do not match.</source>
        <translation>Partition (%1) og enhed (%2) matcher ikke.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="66"/>
        <source>Could not open device %1.</source>
        <translation>Kunne ikke åbne enhed %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="75"/>
        <source>Could not open partition table.</source>
        <translation>Kunne ikke åbne partitionstabel.</translation>
    </message>
</context>
<context>
    <name>DeviceModel</name>
    <message>
        <location filename="../src/modules/partition/core/DeviceModel.cpp" line="79"/>
        <source>%1 - %2 (%3)</source>
        <translation>%1 - %2 (%3)</translation>
    </message>
</context>
<context>
    <name>DevicePropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="58"/>
        <source>Partition table:</source>
        <translation>Partitionstabel:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="77"/>
        <source>Cylinder alignment</source>
        <translation>Cylinder justering</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="84"/>
        <source>Sector based alignment</source>
        <translation>Saktorbaseret justering</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="113"/>
        <source>Capacity:</source>
        <translation>Kapacitet:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="130"/>
        <source>Total sectors:</source>
        <translation>Total Sektorer:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="160"/>
        <source>Cylinders/Heads/Sectors:</source>
        <translation>Cylindere/Hoveder/Sektorer:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="183"/>
        <source>Logical sector size:</source>
        <translation>Logisk sektor størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="200"/>
        <source>Physical sector size:</source>
        <translation>Fysisk sektor størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="217"/>
        <source>Cylinder size:</source>
        <translation>Cylinder størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="241"/>
        <source>Primaries/Max:</source>
        <translation>Primære/Max:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="265"/>
        <source>SMART status:</source>
        <translation>SMART status:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="303"/>
        <source>More...</source>
        <translation>Mere...</translation>
    </message>
</context>
<context>
    <name>EditExistingPartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="20"/>
        <source>Edit Existing Partition</source>
        <translation>Rediger Eksisterende Partition</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="50"/>
        <source>Content:</source>
        <translation>Indhold:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="60"/>
        <source>Keep</source>
        <translation>Behold</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="70"/>
        <source>Format</source>
        <translation>Formater</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="83"/>
        <source>Warning: Formatting the partition will erase all existing data.</source>
        <translation>Advarsel: Formatering af partitionen vil slette alle eksisterende data.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="93"/>
        <source>&amp;Mount Point:</source>
        <translation>&amp;Forbindingspunkt:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="113"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
</context>
<context>
    <name>EditMountOptionsDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="14"/>
        <source>Edit Mount Options</source>
        <translation>Rediger Forbindingsmuligheder</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="20"/>
        <source>Edit the mount options for this file system:</source>
        <translation>Rediger forbindelsesesmulighederne for dette filsystem:</translation>
    </message>
</context>
<context>
    <name>EditMountPointDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="17"/>
        <source>Path:</source>
        <translation>Sti:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="46"/>
        <source>Select...</source>
        <translation>Vælg...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="53"/>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="63"/>
        <source>Options:</source>
        <translation>Muligheder:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="73"/>
        <source>Read-only</source>
        <translation>Skrivelåst</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="80"/>
        <source>Users can mount and unmount</source>
        <translation>Brugere kan forbinde og afbinde</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="87"/>
        <source>No automatic mount</source>
        <translation>Ingen automatisk forbinding</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="94"/>
        <source>No update of file access times</source>
        <translation>Ingen opdatering af fil tilgang tider</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="101"/>
        <source>Synchronous access</source>
        <translation>Synkron adgang</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="108"/>
        <source>No update of directory access times</source>
        <translation>Ingen opdatering af mappe tilgang tider</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="115"/>
        <source>No binary execution</source>
        <translation>Ingen binær eksekvering</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="122"/>
        <source>Update access times relative to modification</source>
        <translation>Opdater tilgangstider relativ til modifikation</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="142"/>
        <source>More...</source>
        <translation>More...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="149"/>
        <source>Dump Frequency:</source>
        <translation>Dump Interval:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="178"/>
        <source>Pass Number:</source>
        <translation>Gennemgang Nummer:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="285"/>
        <source>Device Node</source>
        <translation>Enhedsnode:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="295"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="302"/>
        <source>Label</source>
        <translation>Etiket</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="309"/>
        <source>Identify by:</source>
        <translation>Identificér ved:</translation>
    </message>
</context>
<context>
    <name>EraseDiskPage</name>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="53"/>
        <source>Select drive:</source>
        <translation>Vælg drev:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="229"/>
        <source>Before:</source>
        <translation>Før:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="234"/>
        <source>After:</source>
        <translation>Efter:</translation>
    </message>
</context>
<context>
    <name>FileSystemSupportDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="17"/>
        <source>This table shows which file systems are supported and which specific operations can be performed on them.
Some file systems need external tools to be installed for them to be supported. But not all operations can be performed on all file systems, even if all required tools are installed. Please see the documentation for details. </source>
        <translation>Denne tabel viser hvilke filsystemer der er supporteret og hvilke specifikke handlinger der kan udøves på dem.
Nogle filsystemer kræver at eksterne værktøjer skal installeres for at være supporteret. Vær venlig at læse dokumentationen for detaljer.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="65"/>
        <source>File System</source>
        <translation>Filsystem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="70"/>
        <source>Create</source>
        <translation>Opret</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="75"/>
        <source>Grow</source>
        <translation>Voks</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="80"/>
        <source>Shrink</source>
        <translation>Skrumpe</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="85"/>
        <source>Move</source>
        <translation>Flyt</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="90"/>
        <source>Copy</source>
        <translation>Kopiér</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="95"/>
        <source>Check</source>
        <translation>Tjek</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="100"/>
        <source>Read Label</source>
        <translation>Læs Etiket</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="105"/>
        <source>Write Label</source>
        <translation>Skriv Etiket</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="110"/>
        <source>Read Usage</source>
        <translation>Læs Forbrug</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="115"/>
        <source>Backup</source>
        <translation>Sikkerhedskopiér</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="120"/>
        <source>Restore</source>
        <translation>Genopret</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="125"/>
        <source>Support Tools</source>
        <translation>Support Værktøjer</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="135"/>
        <source>Rescan Support</source>
        <comment>@action:button</comment>
        <translation>Genskan Support</translation>
    </message>
</context>
<context>
    <name>FillGlobalStorageJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="75"/>
        <source>Set partition information</source>
        <translation>Indstil partitionsinformation</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="85"/>
        <source>Failed to find path for boot loader</source>
        <translation>Fejlede i at finde sti til boot loaderen</translation>
    </message>
</context>
<context>
    <name>FinishedPage</name>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="77"/>
        <source>&amp;Restart now</source>
        <translation>&amp;Genstart nu</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.cpp" line="50"/>
        <source>&lt;h1&gt;All done.&lt;/h1&gt;&lt;br/&gt;%1 has been installed on your computer.&lt;br/&gt;You may now restart into your new system, or continue using the %2 Live environment.</source>
        <translation>&lt;h1&gt;Færdig.&lt;/h1&gt;&lt;br/&gt;%1 er blevet installeret på din computer.&lt;br/&gt;Du kan nu genstarte ind i dit nye system, eller fortsætte med at bruge %2 Live miljøet.</translation>
    </message>
</context>
<context>
    <name>FinishedViewStep</name>
    <message>
        <location filename="../src/modules/finished/FinishedViewStep.cpp" line="43"/>
        <source>All done</source>
        <translation>Færdig</translation>
    </message>
</context>
<context>
    <name>FormatPartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="47"/>
        <source>Format partition %1 (file system: %2, size: %3 MB) on %4.</source>
        <translation>Formater partition %1 (filsystem: %2, størrelse: %3 MB) på %4.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="59"/>
        <source>The installer failed to format partition %1 on disk &apos;%2&apos;.</source>
        <translation>Installationsprogrammet fejlede i at formatere partition %1 på disk &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="67"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Kunne ikke åbne enhed &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="76"/>
        <source>Could not open partition table.</source>
        <translation>Kunne ikke åbne partitionstabel.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="84"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>Installationsprogrammet fejlede i at oprette filsystem på partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="92"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>Installationsprogrammet fejlede i at opdatere partitionstabel på disk &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>GreetingPage</name>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="126"/>
        <source>&lt;h1&gt;Welcome to the %1 installer.&lt;/h1&gt;&lt;br/&gt;This program will ask you some questions and set up %2 on your computer.</source>
        <translation>&lt;h1&gt;Velkommen til %1 installationsprogrammet.&lt;/h1&gt;&lt;br/&gt;Dette program vil stille dig nogle spørgsmål og sætte %2 op på din computer.</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="144"/>
        <source>About %1 installer</source>
        <translation>Om %1 installationsprogrammet</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="146"/>
        <source>&lt;h1&gt;%1&lt;/h1&gt;&lt;br/&gt;&lt;b&gt;%2&lt;br/&gt;for %3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;Copyright 2014 Teo Mrnjavac &amp;lt;teo@kde.org&amp;gt;&lt;br/&gt;Thanks to: Anke Boersma, Aurélien Gâteau, Kevin Kofler, Philip Müller, Pier Luigi Fiorini and Rohan Garg.&lt;br/&gt;&lt;br/&gt;&lt;a href=&quot;https://calamares.io/&quot;&gt;Calamares&lt;/a&gt; development is sponsored by &lt;br/&gt;&lt;a href=&quot;http://www.blue-systems.com/&quot;&gt;Blue Systems&lt;/a&gt; - technologies for a better world.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="176"/>
        <source>%1 support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="104"/>
        <source>&amp;Release notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="114"/>
        <source>&amp;Known issues</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="124"/>
        <source>&amp;Support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="134"/>
        <source>&amp;About</source>
        <translation>&amp;Om</translation>
    </message>
</context>
<context>
    <name>GreetingViewStep</name>
    <message>
        <location filename="../src/modules/greeting/GreetingViewStep.cpp" line="43"/>
        <source>Welcome</source>
        <translation>Velkommen</translation>
    </message>
</context>
<context>
    <name>KeyboardPage</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="200"/>
        <source>Set keyboard model to %1.&lt;br/&gt;</source>
        <translation>Indstil tastatur model til %1.&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="202"/>
        <source>Set keyboard layout to %1/%2.</source>
        <translation>Indstil tastatur layout til %1/%2.</translation>
    </message>
</context>
<context>
    <name>KeyboardViewStep</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardViewStep.cpp" line="48"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
</context>
<context>
    <name>LCLocaleDialog</name>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="33"/>
        <source>System locale setting</source>
        <translation>System område indstilling</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="40"/>
        <source>The system locale setting affects the language and character set for some command line user interface elements.&lt;br/&gt;The current setting is &lt;b&gt;%1&lt;/b&gt;.</source>
        <translation>System område indstillingen påvirker sprog og karakter sæt for nogle kommando prompt brugerflade elementer.&gt;br/&gt;Den nuværende indstilling er&lt;b&gt;%1&lt;/b&gt;.</translation>
    </message>
</context>
<context>
    <name>LocalePage</name>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="159"/>
        <location filename="../src/modules/locale/LocalePage.cpp" line="170"/>
        <source>The system locale is set to %1.</source>
        <translation>System område indstillingen er sat til %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="167"/>
        <source>Region:</source>
        <translation>Region:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="168"/>
        <source>Zone:</source>
        <translation>Zone:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="173"/>
        <source>&amp;Change...</source>
        <translation>&amp;Ændre...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="267"/>
        <source>Set timezone to %1/%2.&lt;br/&gt;</source>
        <translation>Indstil tidszone til %1/%2.&lt;br/&gt;</translation>
    </message>
</context>
<context>
    <name>LocaleViewStep</name>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="45"/>
        <source>Loading location data...</source>
        <translation>Loader lokationsdata...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="79"/>
        <source>Location</source>
        <translation>Lokation</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>KDE Partitionsmanager</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="24"/>
        <source>Devices</source>
        <comment>@title:window</comment>
        <translation>Enheder</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="38"/>
        <source>Pending Operations</source>
        <comment>@title:window</comment>
        <translation>Ventende Handlinger</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="49"/>
        <source>Information</source>
        <comment>@title:window</comment>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="63"/>
        <source>Log Output</source>
        <comment>@title:window</comment>
        <translation>Før log over udskrift</translation>
    </message>
</context>
<context>
    <name>MoveFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="66"/>
        <source>Move file system of partition %1.</source>
        <translation>Flyt filsystem af partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="80"/>
        <source>Could not open file system on partition %1 for moving.</source>
        <translation>Kunne ikke åbne filsystem på partition %1 til flytning.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="86"/>
        <source>Could not create target for moving file system on partition %1.</source>
        <translation>Kunne ikke oprette destination til flytning af filsystem på partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="95"/>
        <source>Moving of partition %1 failed, changes have been rolled back.</source>
        <translation>Flytning af partition %1 fejlede, ændringer er tilbageført.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="101"/>
        <source>Moving of partition %1 failed. Roll back of the changes have failed.</source>
        <translation>Flytning af partition %1 fejlede. Tilbageføring af ændringer fejlede.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="113"/>
        <source>Updating boot sector after the moving of partition %1 failed.</source>
        <translation>Opdaterer boot sektor efter flytning af partition %1 fejlede.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="127"/>
        <source>The logical sector sizes in the source and target for copying are not the same. This is currently unsupported.</source>
        <translation>De logiske sektor størrelser for kilden og destination af kopiering er ikke den samme. Dette er ligenu ikke supporteret.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="200"/>
        <source>Source and target for copying do not overlap: Rollback is not required.</source>
        <translation>Kilde og destination for kopiering overlapper ikke: Tilebageføring ikke krævet.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="224"/>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="232"/>
        <source>Could not open device %1 to rollback copying.</source>
        <translation>Kunne ikke åbne enhed %1 til at tilbageføre kopiering.</translation>
    </message>
</context>
<context>
    <name>Page_Keyboard</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="70"/>
        <source>Keyboard Model:</source>
        <translation>Tastatur Model:</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Skriv her for at teste dit tastatur</translation>
    </message>
</context>
<context>
    <name>Page_UserSetup</name>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="33"/>
        <source>What is your name?</source>
        <translation>Hvad er dit navn?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="111"/>
        <source>What name do you want to use to log in?</source>
        <translation>Hvilket navn vil du bruge til at logge ind?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="191"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="319"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="425"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="553"/>
        <source>font-weight: normal</source>
        <translation>font-vægt: normal</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="194"/>
        <source>&lt;small&gt;If more than one person will use this computer, you can set up multiple accounts after installation.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Hvis mere end én person vil bruge denne computer, kan du indstille flere konti efter installationen.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="217"/>
        <source>Choose a password to keep your account safe.</source>
        <translation>Vælg en adgangskode for at beskytte din konto.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="322"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors. A good password will contain a mixture of letters, numbers and punctuation, should be at least eight characters long, and should be changed at regular intervals.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Skriv kodeordet to gange, så det kan blive tjekket for skrivefejl. Et godt kodeord vil indeholde et mix af bogstaver, tal og specialtegn, være mindst 8 cifre langt og bør skiftes jævnligt.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="345"/>
        <source>What is the name of this computer?</source>
        <translation>Hvad er navnet på denne computer?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="428"/>
        <source>&lt;small&gt;This name will be used if you make the computer visible to others on a network.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Dette navn vil blive brugt, hvis du gør computeren synlig for andre på netværket.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="451"/>
        <source>Choose a password for the administrator account.</source>
        <translation>Vælg et kodeord til administrator kontoen.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="556"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Skriv kodeordet to gange, så det kan blive tjekket for skrivefejl.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="596"/>
        <source>Log in automatically</source>
        <translation>Automatisk logind</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="606"/>
        <source>Require my password to log in</source>
        <translation>Kræv mit kodeord for at logge ind</translation>
    </message>
</context>
<context>
    <name>PartPropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="49"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>Filsystem:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="65"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>Etiket:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="82"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>Dette filsystem supportere ikke at indstille etiket.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="92"/>
        <source>Recreate existing file system</source>
        <comment>@action:button</comment>
        <translation>Genskab eksisterende filsystem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="106"/>
        <source>Mount point:</source>
        <comment>@label</comment>
        <translation>Forbindelsespunkt:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="123"/>
        <source>Partition type:</source>
        <comment>@label</comment>
        <translation>Partitionstype:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="140"/>
        <source>Status:</source>
        <comment>@label</comment>
        <translation>Status:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="157"/>
        <source>UUID:</source>
        <comment>@label</comment>
        <translation>UUID:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="187"/>
        <source>Size:</source>
        <comment>@label</comment>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="210"/>
        <source>Available:</source>
        <comment>@label partition capacity available</comment>
        <translation>Tilgængelig:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="227"/>
        <source>Used:</source>
        <comment>@label partition capacity used</comment>
        <translation>Brugt:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="251"/>
        <source>First sector:</source>
        <comment>@label</comment>
        <translation>Første sektor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="268"/>
        <source>Last sector:</source>
        <comment>@label</comment>
        <translation>Sidste sektor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="285"/>
        <source>Number of sectors:</source>
        <comment>@label</comment>
        <translation>Antal af sektorer:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="309"/>
        <source>Flags:</source>
        <comment>@label</comment>
        <translation>Flag:</translation>
    </message>
</context>
<context>
    <name>PartitionManagerWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>KDE Partitionsmanager</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="70"/>
        <source>Partition</source>
        <translation>Partition</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="75"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="80"/>
        <source>Mount Point</source>
        <translation>Forbindelsespunkt</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="85"/>
        <source>Label</source>
        <translation>Etiket</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="90"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="95"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="100"/>
        <source>Used</source>
        <translation>Brugt</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="105"/>
        <source>Available</source>
        <translation>Tilgængelig</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="110"/>
        <source>First Sector</source>
        <translation>Første Sektor</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="115"/>
        <source>Last Sector</source>
        <translation>Sidste Sektor</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="120"/>
        <source>Number of Sectors</source>
        <translation>Antal Sektorer</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="125"/>
        <source>Flags</source>
        <translation>Flag</translation>
    </message>
</context>
<context>
    <name>PartitionModel</name>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="132"/>
        <source>Free Space</source>
        <translation>Fri Plads</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="136"/>
        <source>New partition</source>
        <translation>Ny partition</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="175"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="177"/>
        <source>File System</source>
        <translation>Filsystem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="179"/>
        <source>Mount Point</source>
        <translation>Forbindelsespunkt</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="181"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
</context>
<context>
    <name>PartitionPage</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>&amp;Disk:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="51"/>
        <source>&amp;Revert All Changes</source>
        <translation>&amp;Tilbagefør Alle Ændringer</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="84"/>
        <source>New Partition &amp;Table</source>
        <translation>Ny Partitionstabel</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="104"/>
        <source>&amp;Create</source>
        <translation>&amp;Opret</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="111"/>
        <source>&amp;Edit</source>
        <translation>&amp;Redigér</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="118"/>
        <source>&amp;Delete</source>
        <translation>&amp;Slet</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="145"/>
        <source>&amp;Install boot loader on:</source>
        <translation>&amp;Installér boot loaderen på:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.cpp" line="135"/>
        <source>Are you sure you want to create a new partition table on %1?</source>
        <translation>Er du sikker på at du vil oprette en ny partitionstabel på %1?</translation>
    </message>
</context>
<context>
    <name>PartitionViewStep</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="66"/>
        <source>Gathering system information...</source>
        <translation>Samler system information...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="160"/>
        <source>Partitions</source>
        <translation>Partitioner</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="188"/>
        <source>Before:</source>
        <translation>Før:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="193"/>
        <source>After:</source>
        <translation>Efter:</translation>
    </message>
</context>
<context>
    <name>PreparePage</name>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="39"/>
        <source>For best results, please ensure that this computer:</source>
        <translation>For de bedste resultater, forsikrer dig at computeren:</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="96"/>
        <source>This computer does not satisfy the minimum requirements for installing %1.
Installation cannot continue.</source>
        <translation>Denne computer overholder ikke minimumskravene for at installere %1.
Installation kan ikke fortsætte.</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="109"/>
        <source>This computer does not satisfy some of the recommended requirements for installing %1.
Installation can continue, but some features might be disabled.</source>
        <translation>Denne computer overholder ikke alle anbefalede krav for at installere %1.
Installation kan fortsætte, men nogle features kan være deaktiveret.</translation>
    </message>
</context>
<context>
    <name>PrepareViewStep</name>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="54"/>
        <source>Gathering system information...</source>
        <translation>Samler system information...</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="91"/>
        <source>has at least %1 GB available drive space</source>
        <translation>har mindst %1 GB fri harddisk plads</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="99"/>
        <source>has at least %1 GB working memory</source>
        <translation>har mindst %1 GB hukkommelse</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="107"/>
        <source>is plugged in to a power source</source>
        <translation>er tilsluttet strømkilde</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="114"/>
        <source>is connected to the Internet</source>
        <translation>er forbundet til internettet</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="158"/>
        <source>Prepare</source>
        <translation>Forbered</translation>
    </message>
</context>
<context>
    <name>ProgressTreeModel</name>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="138"/>
        <source>Prepare</source>
        <translation>Forbered</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="151"/>
        <source>Install</source>
        <translation>Installér</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="161"/>
        <source>Finish</source>
        <translation>Færdiggør</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="82"/>
        <source>Default Keyboard Model</source>
        <translation>Standard Tastatur Model</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="127"/>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="163"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
</context>
<context>
    <name>ReleaseDialog</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="20"/>
        <source>KDE Release Builder</source>
        <translation>KDE Release Bygger</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="32"/>
        <source>Application</source>
        <translation>Program</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="38"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="48"/>
        <source>&amp;Version:</source>
        <translation>&amp;Version:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="93"/>
        <source>Repository and Revision</source>
        <translation>Repositorie og Revision</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="99"/>
        <source>&amp;Checkout From:</source>
        <translation>&amp;Tjek ud fra:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="119"/>
        <source>trunk</source>
        <translation>trunk</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="124"/>
        <source>branches</source>
        <translation>branches</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="129"/>
        <source>tags</source>
        <translation>tags</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="137"/>
        <source>Ta&amp;g/Branch:</source>
        <translation>Ta&amp;g/Branch</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="163"/>
        <source>&amp;SVN Access:</source>
        <translation>&amp;SVN Access:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="183"/>
        <source>anonsvn</source>
        <translation>anonsvn</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="188"/>
        <source>https</source>
        <translation>https</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="193"/>
        <source>svn+ssh</source>
        <translation>svn+ssh</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="201"/>
        <source>&amp;User:</source>
        <translation>&amp;Bruger:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="236"/>
        <source>Options</source>
        <translation>Muligheder</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="242"/>
        <source>Get &amp;Documentation</source>
        <translation>Få &amp;Dokumentation</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="252"/>
        <source>Get &amp;Translations</source>
        <translation>Få &amp;Oversættelser</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="262"/>
        <source>C&amp;reate Tag</source>
        <translation>&amp;Opret Tag</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="271"/>
        <source>S&amp;kip translations below completion:</source>
        <translation>&amp;Spring over oversættelser under færdiggørelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="306"/>
        <source> %</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="324"/>
        <source>Create Tar&amp;ball</source>
        <translation>Opret Tar&amp;ball</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="334"/>
        <source>Apply &amp;fixes</source>
        <translation>Anvend &amp;rettelser</translation>
    </message>
</context>
<context>
    <name>ReplacePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>&amp;Disk:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="109"/>
        <source>Select where to install %1.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;this will delete all files on the selected partition.</source>
        <translation>Vælg hvor %1 skal installeres.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Advarsel: &lt;/font&gt;dette vil slette alle filerne på den valgte partition.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="136"/>
        <source>The selected item does not appear to be a valid partition.</source>
        <translation>Det valgte emne ser ikke ud til at være en gyldig partition.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="144"/>
        <source>%1 cannot be installed on empty space. Please select an existing partition.</source>
        <translation>%1 kan ikke installeres på tomt plads. Vælg venligst en eksisterende partition.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="155"/>
        <source>%1 cannot be installed on an extended partition. Please select an existing primary or logical partition.</source>
        <translation>%1 kan ikke installeres på en udvidet partition. Vælg venligst en eksisterende primær eller logisk partition.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="166"/>
        <source>%1 cannot be installed on this partition.</source>
        <translation>%1 kan ikke installeres på denne partition.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="173"/>
        <source>Data partition (%1)</source>
        <translation>Data partition (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="190"/>
        <source>Unknown system partition (%1)</source>
        <translation>Ukendt system partition (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="195"/>
        <source>%1 system partition (%2)</source>
        <translation>%1 system partition (%2)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="206"/>
        <source>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;The partition %1 is too small for %2. Please select a partition with capacity at least %3 GiB.</source>
        <translation>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;Partition %1 er for lille til %2. Vælg venligst en partition med minimum %3 GB plads.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="220"/>
        <source>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 will be installed on %2.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;all data on partition%2 will be lost.</source>
        <translation>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 vil blive installeret på %2.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Advarsel: &lt;/font&gt;Al data på partition %2 vil gå tabt.</translation>
    </message>
</context>
<context>
    <name>ResizeFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="75"/>
        <source>Resize file system on partition %1.</source>
        <translation>Ændre størrelse af filsystem på partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="90"/>
        <source>Parted failed to resize filesystem.</source>
        <translation>Parted fejlede i at ændre størrelse på filsystem.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="100"/>
        <source>Failed to resize filesystem.</source>
        <translation>Fejlede i at ændre størrelse på filsystem.</translation>
    </message>
</context>
<context>
    <name>ResizePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="186"/>
        <source>Resize partition %1.</source>
        <translation>Ændre størrelse på partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="208"/>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="266"/>
        <source>The installer failed to resize partition %1 on disk &apos;%2&apos;.</source>
        <translation>Installationsprogrammet fejlede i at ændre størrelse på partition %1 på disk &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="213"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Kunne ikke åbne enhed &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>SetHostNameJob</name>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="36"/>
        <source>Set hostname %1</source>
        <translation>Indstil værtsnavn %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="46"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="53"/>
        <source>Internal Error</source>
        <translation>Intern Fejl</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="60"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="71"/>
        <source>Cannot write hostname to target system</source>
        <translation>Kan ikke skrive værtsnavn til mål system</translation>
    </message>
</context>
<context>
    <name>SetKeyboardLayoutJob</name>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="57"/>
        <source>Set keyboard model to %1, layout to %2-%3</source>
        <translation>Indstil tastatur model til %1, layout til %2-%3</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="284"/>
        <source>Failed to write keyboard configuration for the virtual console.</source>
        <translation>Fejl ved at skrive tastatur konfiguration for den virtuelle konsol.</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="285"/>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="289"/>
        <source>Failed to write to %1</source>
        <translation>Fejlede at skrive til %1</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="288"/>
        <source>Failed to write keyboard configuration for X11.</source>
        <translation>Fejlede at skrive tastatur konfiguration til X11.</translation>
    </message>
</context>
<context>
    <name>SetPartGeometryJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="143"/>
        <source>Update geometry of partition %1.</source>
        <translation>Opdatér geometri af partition %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="155"/>
        <source>Failed to change the geometry of the partition.</source>
        <translation>Fejlede i at ændre geometri af partitionen.</translation>
    </message>
</context>
<context>
    <name>SetPasswordJob</name>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="42"/>
        <source>Set password for user %1</source>
        <translation>Indstil kodeord for bruger %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="52"/>
        <source>Bad destination system path.</source>
        <translation>Dårlig destination systemsti.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="53"/>
        <source>rootMountPoint is %1</source>
        <translation>rodMonteringsPunkt er %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="62"/>
        <source>Cannot set password for user %1.</source>
        <translation>Kan ikke indstille kodeord for bruger %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="64"/>
        <source>usermod terminated with error code %1.</source>
        <translation>usermod stoppede med fejl kode %1.</translation>
    </message>
</context>
<context>
    <name>SetTimezoneJob</name>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="41"/>
        <source>Set timezone to %1/%2</source>
        <translation>Indstil tidszone til %1/%2</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="56"/>
        <source>Cannot access selected timezone path.</source>
        <translation>Kan ikke tilgå den valgte tidszone sti.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="57"/>
        <source>Bad path: %1</source>
        <translation>Dårlig sti: %1</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="69"/>
        <source>Cannot set timezone.</source>
        <translation>Kan ikke indstille tidszone.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="70"/>
        <source>Link creation failed, target: %1; link name: %2</source>
        <translation>Link oprettelse fejlede, mål: %1; link navn: %2</translation>
    </message>
</context>
<context>
    <name>SizeDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="62"/>
        <source>First sector:</source>
        <comment>@label:listbox</comment>
        <translation>Første sektor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="97"/>
        <source>Last sector:</source>
        <comment>@label:listbox</comment>
        <translation>Sidste sektor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="120"/>
        <source>Align partition</source>
        <translation>Justér partition</translation>
    </message>
</context>
<context>
    <name>SizeDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="55"/>
        <source>Partition type:</source>
        <comment>@label:listbox</comment>
        <translation>Partitionstype:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="70"/>
        <source>Primary</source>
        <translation>Primær</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="77"/>
        <source>Extended</source>
        <translation>Udvidet</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="84"/>
        <source>Logical</source>
        <translation>Logisk</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="99"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>Filsystem:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="115"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>Etiket:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="134"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>Dette filsystem supporterer ikke at indstille etiket.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="152"/>
        <source>Minimum size:</source>
        <comment>@label</comment>
        <translation>Minimum størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="175"/>
        <source>Maximum size:</source>
        <comment>@label</comment>
        <translation>Maximum størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="198"/>
        <source>Free space before:</source>
        <comment>@label:listbox</comment>
        <translation>Fri plads før:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="233"/>
        <source>Size:</source>
        <comment>@label:listbox</comment>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="262"/>
        <source>Free space after:</source>
        <comment>@label:listbox</comment>
        <translation>Fri plads efter:</translation>
    </message>
</context>
<context>
    <name>SmartDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="23"/>
        <source>SMART status:</source>
        <translation>SMART status:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="63"/>
        <source>Model:</source>
        <translation>Model:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="92"/>
        <source>Serial number:</source>
        <translation>Serie nummer:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="121"/>
        <source>Firmware revision:</source>
        <translation>Firmware revision:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="150"/>
        <source>Temperature:</source>
        <translation>Temperatur:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="179"/>
        <source>Bad sectors:</source>
        <translation>Dårlige sektorer:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="208"/>
        <source>Powered on for:</source>
        <translation>Strøm på for:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="237"/>
        <source>Power cycles:</source>
        <translation>Strøm cyklus:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="289"/>
        <source>Id</source>
        <translation>Id</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="294"/>
        <source>Attribute</source>
        <translation>Attribut</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="299"/>
        <source>Failure Type</source>
        <translation>Fejl Type</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="304"/>
        <source>Update Type</source>
        <translation>Opdateringstype</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="309"/>
        <source>Worst</source>
        <translation>Værste</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="314"/>
        <source>Current</source>
        <translation>Nuværende</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="319"/>
        <source>Threshold</source>
        <translation>Tærskel</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="324"/>
        <source>Raw</source>
        <translation>Rå</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="329"/>
        <source>Assessment</source>
        <translation>Vurdering</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="334"/>
        <source>Value</source>
        <translation>Værdi</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="385"/>
        <source>Overall assessment:</source>
        <translation>Samlet vurdering:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="414"/>
        <source>Self tests:</source>
        <translation>Selvtests:</translation>
    </message>
</context>
<context>
    <name>SummaryViewStep</name>
    <message>
        <location filename="../src/modules/summary/SummaryViewStep.cpp" line="41"/>
        <source>Summary</source>
        <translation>Opsummering</translation>
    </message>
</context>
<context>
    <name>TreeLogBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="54"/>
        <source>Sev.</source>
        <comment>@title:column Severity of a log entry / log level. Text must be very short.</comment>
        <translation>Sev.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="57"/>
        <source>Severity</source>
        <translation>Betydning</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="62"/>
        <source>Time</source>
        <comment>@title:column a time stamp of a log entry</comment>
        <translation>Tid</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="67"/>
        <source>Message</source>
        <comment>@title:column the text message of a log entry</comment>
        <translation>Besked</translation>
    </message>
</context>
<context>
    <name>UsersPage</name>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="233"/>
        <source>Your username is too long.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="243"/>
        <source>Your username contains invalid characters. Only lowercase letters and numbers are allowed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="287"/>
        <source>Your hostname is too short.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="298"/>
        <source>Your hostname is too long.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="309"/>
        <source>Your hostname contains invalid characters. Only letters, numbers and dashes are allowed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="340"/>
        <location filename="../src/modules/users/UsersPage.cpp" line="373"/>
        <source>Your passwords do not match!</source>
        <translation>Dine kodeord er ikke ens!</translation>
    </message>
</context>
<context>
    <name>UsersViewStep</name>
    <message>
        <location filename="../src/modules/users/UsersViewStep.cpp" line="46"/>
        <source>Users</source>
        <translation>Brugere</translation>
    </message>
</context>
</TS>