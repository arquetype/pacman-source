<?xml version="1.0" ?><!DOCTYPE TS><TS language="it_IT" version="2.1">
<context>
    <name>AlongsidePage</name>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="67"/>
        <source>Choose partition to shrink:</source>
        <translation>Scegli la partizione da ridimensionare:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="68"/>
        <source>Allocate drive space by dragging the divider below:</source>
        <translation>Assegna spazio su disco trascinando il separatore sottostante:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="167"/>
        <source>With this operation, the partition &lt;b&gt;%1&lt;/b&gt; which contains %4 will be shrunk to %2MB and a new %3MB partition will be created for %5.</source>
        <translation>Con questa operazione, la partizione &lt;b&gt;%1&lt;/b&gt; contenente %4 sarà ridotta a %2MB e sarà creata una nuova partizione di %3MB per %5.</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="37"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="44"/>
        <source>Open in External Browser</source>
        <translation>Apri in un browser esterno</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="33"/>
        <source>Operations and Jobs</source>
        <translation>Operazioni e attività</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="38"/>
        <source>Time Elapsed</source>
        <translation>Tempo trascorso</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="64"/>
        <source>Total Time: 00:00:00</source>
        <translation>Tempo complessivo: 00:00:00</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="81"/>
        <source>Operation: %p%</source>
        <translation>Operazione: %p%</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="91"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="107"/>
        <source>Total: %p%</source>
        <translation>Totale: %p%</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="20"/>
        <source>Installer</source>
        <translation>Programma di installazione</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="168"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Welcome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Benvenuto&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="198"/>
        <source>Location</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="224"/>
        <source>License Approval</source>
        <translation>Approvazione della licenza</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="257"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Installation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Installazione&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="287"/>
        <source>Install System</source>
        <translation>Installa il Sistema</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="320"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Configuration&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Configurazione&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="331"/>
        <source>Reboot</source>
        <translation>Riavvia</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="410"/>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="443"/>
        <source>User Info</source>
        <translation>Informazioni Utente</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="469"/>
        <source>Summary</source>
        <translation>Riepilogo</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="514"/>
        <source>Keyboard</source>
        <translation>Tastiera</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="521"/>
        <source>Disk Setup</source>
        <translation>Configurazione del disco</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="528"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Preparation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Preparazione&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>BootLoaderModel</name>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="57"/>
        <source>Master Boot Record of %1</source>
        <translation>Master Boot Record di %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="71"/>
        <source>Boot Partition</source>
        <translation>Partizione di avvio</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="76"/>
        <source>System Partition</source>
        <translation>Partizione di sistema</translation>
    </message>
</context>
<context>
    <name>Calamares::DebugWindow</name>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="24"/>
        <source>GlobalStorage</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="34"/>
        <source>JobQueue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="44"/>
        <source>Modules</source>
        <translation>Moduli</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.cpp" line="95"/>
        <source>Debug information</source>
        <translation>Informazioni debug</translation>
    </message>
</context>
<context>
    <name>Calamares::InstallationViewStep</name>
    <message>
        <location filename="../src/libcalamaresui/InstallationViewStep.cpp" line="75"/>
        <source>Install</source>
        <translation>Installa</translation>
    </message>
</context>
<context>
    <name>Calamares::JobThread</name>
    <message>
        <location filename="../src/libcalamares/JobQueue.cpp" line="88"/>
        <source>Done</source>
        <translation>Fatto</translation>
    </message>
</context>
<context>
    <name>Calamares::ProcessJob</name>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="51"/>
        <source>Run command %1 %2</source>
        <translation>Esegui comando %1 %2</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="79"/>
        <source>External command crashed</source>
        <translation>Il comando esterno si è arrestato improvvisamente</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="80"/>
        <source>Command %1 crashed.
Output:
%2</source>
        <translation>Il comando %1 si è arrestato improvvisamente.
Output:
%2</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="85"/>
        <source>External command failed to start</source>
        <translation>Il comando esterno non si è avviato</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="86"/>
        <source>Command %1 failed to start.</source>
        <translation>Il comando %1 non si è avviato</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="90"/>
        <source>Internal error when starting command</source>
        <translation>Errore interno all&apos;avvio del comando</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="91"/>
        <source>Bad parameters for process job call.</source>
        <translation>Parametri errati per elaborare l&apos;attività richiesta</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="94"/>
        <source>External command failed to finish</source>
        <translation>Il comando esterno non è stato portato a termine</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="95"/>
        <source>Command %1 failed to finish in %2s.
Output:
%3</source>
        <translation>Il comando %1 non è stato portato a termine in %2s.
Output:
%3</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="101"/>
        <source>External command finished with errors</source>
        <translation>Il comando esterno è terminato con errori</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="102"/>
        <source>Command %1 finished with exit code %2.
Output:
%3</source>
        <translation>Il comando %1 è terminato con codice di uscita %2.
Output:
%3</translation>
    </message>
</context>
<context>
    <name>Calamares::PythonJob</name>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="234"/>
        <source>Run script %1</source>
        <translation>Avvia lo script %1</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="249"/>
        <source>Bad working directory path</source>
        <translation>Il percorso della cartella corrente non è corretto</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="250"/>
        <source>Working directory %1 for python job %2 is not readable.</source>
        <translation>La cartella corrente %1 per l&apos;attività di Python %2 non è accessibile.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="260"/>
        <source>Bad main script file</source>
        <translation>File dello script principale non valido</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="261"/>
        <source>Main script file %1 for python job %2 is not readable.</source>
        <translation>Il file principale dello script %1 per l&apos;attività di python %2 non è accessibile.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="306"/>
        <source>Boost.Python error in job &quot;%1&quot;.</source>
        <translation>Errore da Boost.Python nell&apos;operazione &quot;%1&quot;.</translation>
    </message>
</context>
<context>
    <name>Calamares::ViewManager</name>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="64"/>
        <source>&amp;Back</source>
        <translation>&amp;Indietro</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="65"/>
        <source>&amp;Next</source>
        <translation>&amp;Avanti</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="66"/>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="302"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Annulla</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="86"/>
        <source>Cancel installation?</source>
        <translation>Annullare l&apos;installazione?</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="87"/>
        <source>Do you really want to cancel the current install process?
The installer will quit and all changes will be lost.</source>
        <translation>Vuoi davvero annullare l&apos;installazione in corso?
Il programma di installazione sarà chiuso, e tutte le modifiche andranno perse.</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="272"/>
        <source>&amp;Quit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="183"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="184"/>
        <source>Installation Failed</source>
        <translation>Installazione non riuscita</translation>
    </message>
</context>
<context>
    <name>CalamaresPython::Helper</name>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="234"/>
        <source>Unknown exception type</source>
        <translation>Tipo di eccezione sconosciuto</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="247"/>
        <source>unparseable Python error</source>
        <translation>Errore Python non definibile</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="263"/>
        <source>unparseable Python traceback</source>
        <translation>Traceback Python non definibile</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="267"/>
        <source>Unfetchable Python error.</source>
        <translation>Errore di Python non definibile.</translation>
    </message>
</context>
<context>
    <name>CalamaresWindow</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="44"/>
        <source>%1 Installer</source>
        <translation>%1 Programma di installazione</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="98"/>
        <source>Show debug information</source>
        <translation>Mostra informazioni debug</translation>
    </message>
</context>
<context>
    <name>CheckFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="34"/>
        <source>Checking file system on partition %1.</source>
        <translation>Controllo del file system sulla partizione %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="50"/>
        <source>The file system check on partition %1 failed.</source>
        <translation>Il controllo del file system sulla partizione %1 non è riuscito.</translation>
    </message>
</context>
<context>
    <name>ChoicePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="115"/>
        <source>This computer currently does not seem to have an operating system on it. What would you like to do?</source>
        <translation>Questo computer sembra non avere un sistema operativo installato. Cosa vuoi fare?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="119"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="187"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="234"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will delete all of your programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;Cancella il disco e installa %1&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Attenzione: &lt;/font&gt;Questo cancellerà tutti i tuoi programmi, documenti, foto, musica e ogni altro file.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="125"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="162"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="193"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="240"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which disk to erase.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="141"/>
        <source>This computer currently has %1 on it. What would you like to do?</source>
        <translation>Su questo computer è installato %1. Cosa vuoi fare?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="145"/>
        <source>&lt;b&gt;Install %2 alongside %1&lt;/b&gt;&lt;br/&gt;The installer will shrink the %1 volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="167"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="198"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="245"/>
        <source>&lt;b&gt;Replace a partition with %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which partition to erase.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="179"/>
        <source>&lt;b&gt;Install %1 alongside your current operating system&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="226"/>
        <source>&lt;b&gt;Install %1 alongside your current operating systems&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="261"/>
        <source>&lt;b&gt;Manual partitioning&lt;/b&gt;&lt;br/&gt;You can create or resize partitions yourself, or choose multiple partitions for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="154"/>
        <source>&lt;b&gt;Erase entire disk with %1 and install %2&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will erase the whole disk and delete all of your %1 programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;Cancella l&apos;intero disco con %1 e installa %2&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Attenzione: &lt;/font&gt;Questo cancellerà l&apos;intero disco e tutti i %1 programmi, documenti, foto, musica, e ogni altro file.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="176"/>
        <source>This computer already has an operating system on it. What would you like to do?</source>
        <translation>Su questo computer è già installato un sistema operativo. Cosa vuoi fare?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="223"/>
        <source>This computer currently has multiple operating systems on it. What would you like to do?</source>
        <translation>Su questo computer sono installati più sistemi operativi. Cosa vuoi fare?</translation>
    </message>
</context>
<context>
    <name>ClearMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="42"/>
        <source>Clear mounts for partitioning operations on %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="81"/>
        <source>Cleared all mounts for %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ClearTempMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="38"/>
        <source>Clear all temporary mounts.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="49"/>
        <source>Cannot get list of temporary mounts.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="88"/>
        <source>Cleared all temporary mounts.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ConfigurePageAdvanced</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="23"/>
        <source>Permissions</source>
        <translation>Permessi</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="35"/>
        <source>Allow applying operations without administrator privileges</source>
        <translation>Permetti la conferma di operazioni senza privilegi da amministratore</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="51"/>
        <source>Backend</source>
        <translation>Backend</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="57"/>
        <source>Active backend:</source>
        <translation>Backend attivo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="79"/>
        <source>Units</source>
        <translation>Unità</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="85"/>
        <source>Preferred unit:</source>
        <translation>Unità preferita:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="96"/>
        <source>Byte</source>
        <translation>Byte</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="101"/>
        <source>KiB</source>
        <translation>KB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="106"/>
        <source>MiB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="111"/>
        <source>GiB</source>
        <translation>GB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="116"/>
        <source>TiB</source>
        <translation>TB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="121"/>
        <source>PiB</source>
        <translation>PB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="126"/>
        <source>EiB</source>
        <translation>EB</translation>
    </message>
</context>
<context>
    <name>ConfigurePageFileSystemColors</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="23"/>
        <source>File Systems</source>
        <translation>File System</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="29"/>
        <source>luks:</source>
        <translation>luks:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="45"/>
        <source>ntfs:</source>
        <translation>ntfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="58"/>
        <source>ext2:</source>
        <translation>ext2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="87"/>
        <source>ext3:</source>
        <translation>ext3:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="116"/>
        <source>ext4:</source>
        <translation>ext4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="132"/>
        <source>btrfs:</source>
        <translation>btrfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="174"/>
        <source>linuxswap:</source>
        <translation>linuxswap:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="190"/>
        <source>fat16:</source>
        <translation>fat16:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="219"/>
        <source>fat32:</source>
        <translation>fat32:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="248"/>
        <source>zfs:</source>
        <translation>zfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="264"/>
        <source>reiserfs:</source>
        <translation>reiserfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="293"/>
        <source>reiser4:</source>
        <translation>reiser4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="322"/>
        <source>hpfs:</source>
        <translation>hpfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="338"/>
        <source>jfs</source>
        <translation>jfs</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="367"/>
        <source>hfs:</source>
        <translation>hfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="396"/>
        <source>hfsplus:</source>
        <translation>hfsplus:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="412"/>
        <source>ufs:</source>
        <translation>ufs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="441"/>
        <source>xfs:</source>
        <translation>xfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="470"/>
        <source>ocfs2:</source>
        <translation>ocfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="489"/>
        <source>extended:</source>
        <translation>estesa:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="518"/>
        <source>unformatted:</source>
        <translation>non formattata:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="547"/>
        <source>unknown:</source>
        <translation>sconosciuta:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="570"/>
        <source>exfat:</source>
        <translation>exfat:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="583"/>
        <source>nilfs2:</source>
        <translation>nilfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="622"/>
        <source>lvm2 pv:</source>
        <translation>lvm2 pv:</translation>
    </message>
</context>
<context>
    <name>ConfigurePageGeneral</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="23"/>
        <source>Partition Alignment</source>
        <translation>Allineamento partizione:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="29"/>
        <source>Use cylinder based alignment (Windows XP compatible)</source>
        <translation>Usa allineamento basato sui cilindri (compatibile con Windows XP)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="42"/>
        <source>Sector alignment:</source>
        <translation>Allineamento di settore:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="55"/>
        <source> sectors</source>
        <translation>settori</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="71"/>
        <source>Align partitions per default</source>
        <translation>Allinea le partizioni come impostazione predefinita</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="90"/>
        <source>Logging</source>
        <translation>Registrazione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="96"/>
        <source>Hide messages below:</source>
        <translation>Nascondi messaggi sottostanti:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="107"/>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="112"/>
        <source>Information</source>
        <translation>Informazione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="117"/>
        <source>Warning</source>
        <translation>Avviso</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="122"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="139"/>
        <source>File Systems</source>
        <translation>File System</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="145"/>
        <source>Default file system:</source>
        <translation>File system di default:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="167"/>
        <source>Shredding</source>
        <translation>Distruzione in corso</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="173"/>
        <source>Overwrite with:</source>
        <translation>Sovrascrivi con:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="180"/>
        <source>Random data</source>
        <translation>Dati casuali</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="190"/>
        <source>Zeros</source>
        <translation>Zeri</translation>
    </message>
</context>
<context>
    <name>CreatePartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="14"/>
        <source>Create a Partition</source>
        <translation>Crea una partizione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="38"/>
        <source>Partition &amp;Type:</source>
        <translation>&amp;Tipo di partizione:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="50"/>
        <source>&amp;Primary</source>
        <translation>&amp;Primaria</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="60"/>
        <source>E&amp;xtended</source>
        <translation>E&amp;stesa</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="89"/>
        <source>F&amp;ile System:</source>
        <translation>F&amp;ile system:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="118"/>
        <source>&amp;Mount Point:</source>
        <translation>Punto di &amp;mount:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="164"/>
        <source>Si&amp;ze:</source>
        <translation>&amp;Dimensione:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="174"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="95"/>
        <source>Logical</source>
        <translation>Logica</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="100"/>
        <source>Primary</source>
        <translation>Primaria</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="117"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
</context>
<context>
    <name>CreatePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="47"/>
        <source>Create partition (file system: %1, size: %2 MB) on %3.</source>
        <translation>Crea partizione (file system: %1, dimensione: %2 MB) su %3.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="60"/>
        <source>The installer failed to create partition on disk &apos;%1&apos;.</source>
        <translation>Il programma di installazione non è riuscito a creare la partizione sul disco &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="69"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Impossibile aprire il disco &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="79"/>
        <source>Could not open partition table.</source>
        <translation>Impossibile aprire la tabella delle partizioni.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="103"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>Il programma di installazione non è riuscito a creare il file system nella partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="111"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>Il programma di installazione non è riuscito ad aggiornare la tabella delle partizioni sul disco &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="20"/>
        <source>Create Partition Table</source>
        <translation>Crea tabella delle partizioni</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="39"/>
        <source>Creating a new partition table will delete all existing data on the disk.</source>
        <translation>La creazione di una nuova tabella delle partizioni cancellerà tutti i dati esistenti sul disco.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="65"/>
        <source>What kind of partition table do you want to create?</source>
        <translation>Che tipo di tabella delle partizioni vuoi creare?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="72"/>
        <source>Master Boot Record (MBR)</source>
        <translation>Master Boot Record (MBR)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="82"/>
        <source>GUID Partition Table (GPT)</source>
        <translation>Tavola delle Partizioni GUID (GPT)</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="48"/>
        <source>Create partition table</source>
        <translation>Crea tabella delle partizioni</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="55"/>
        <source>The installer failed to create a partition table on %1.</source>
        <translation>Il programma di installazione non è riuscito a creare una tabella delle partizioni su %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="63"/>
        <source>Could not open device %1.</source>
        <translation>Impossibile aprire il dispositivo %1.</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="20"/>
        <source>Choose the type of partition table you want to create:</source>
        <translation>Scegli il tipo di tabella delle partizioni da creare:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="29"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="39"/>
        <source>MS-Dos</source>
        <translation>MS-Dos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="66"/>
        <source>(icon)</source>
        <translation>(icona)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="79"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; This will destroy all data on the device!</source>
        <translation>&lt;b&gt;Attenzione:&lt;/b&gt; Questo distruggerà tutti i dati sul dispositivo!</translation>
    </message>
</context>
<context>
    <name>CreateUserJob</name>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="51"/>
        <source>Create user %1</source>
        <translation>Crea l&apos;utente %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="67"/>
        <source>Sudoers dir is not writable.</source>
        <translation>La cartella sudoers non è scrivibile.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="71"/>
        <source>Cannot create sudoers file for writing.</source>
        <translation>Impossibile creare il file sudoers in scrittura.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="79"/>
        <source>Cannot chmod sudoers file.</source>
        <translation>Impossibile eseguire chmod sul file sudoers.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="85"/>
        <source>Cannot open groups file for reading.</source>
        <translation>Impossibile aprire il file groups in lettura.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="123"/>
        <source>Cannot create user %1.</source>
        <translation>Impossibile creare l&apos;utente %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="125"/>
        <source>useradd terminated with error code %1.</source>
        <translation>useradd si è chiuso con codice di errore %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="130"/>
        <source>Cannot set full name for user %1.</source>
        <translation>Impossibile impostare il nome completo per l&apos;utente %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="132"/>
        <source>chfn terminated with error code %1.</source>
        <translation>chfn si è chiuso con codice di errore %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="141"/>
        <source>Cannot set home directory ownership for user %1.</source>
        <translation>Impossibile impostare i diritti sulla cartella home per l&apos;utente %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="143"/>
        <source>chown terminated with error code %1.</source>
        <translation>chown si è chiuso con codice di errore %1.</translation>
    </message>
</context>
<context>
    <name>DecryptLuksDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="22"/>
        <source>&amp;Name:</source>
        <translation>&amp;Nome:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="35"/>
        <source>&amp;Passphrase:</source>
        <translation>&amp;Frase di accesso:</translation>
    </message>
</context>
<context>
    <name>DeletePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="41"/>
        <source>Delete partition %1</source>
        <translation>Cancella la partizione %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="48"/>
        <source>The installer failed to delete partition %1.</source>
        <translation>Il programma di installazione non è riuscito a cancellare la partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="54"/>
        <source>Partition (%1) and device (%2) do not match.</source>
        <translation>La partizione (%1) ed il dispositivo (%2) non corrispondono.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="66"/>
        <source>Could not open device %1.</source>
        <translation>Impossibile aprire il dispositivo %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="75"/>
        <source>Could not open partition table.</source>
        <translation>Impossibile aprire la tabella delle partizioni.</translation>
    </message>
</context>
<context>
    <name>DeviceModel</name>
    <message>
        <location filename="../src/modules/partition/core/DeviceModel.cpp" line="79"/>
        <source>%1 - %2 (%3)</source>
        <translation>%1 - %2 (%3)</translation>
    </message>
</context>
<context>
    <name>DevicePropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="58"/>
        <source>Partition table:</source>
        <translation>Tabella delle partizioni:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="77"/>
        <source>Cylinder alignment</source>
        <translation>Allineamento del cilindro</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="84"/>
        <source>Sector based alignment</source>
        <translation>Allineamento al settore</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="113"/>
        <source>Capacity:</source>
        <translation>Capacità:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="130"/>
        <source>Total sectors:</source>
        <translation>Settori totali:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="160"/>
        <source>Cylinders/Heads/Sectors:</source>
        <translation>Cilindri/Testine/Settori:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="183"/>
        <source>Logical sector size:</source>
        <translation>Dimensione del settore logico:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="200"/>
        <source>Physical sector size:</source>
        <translation>Dimensione del settore fisico:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="217"/>
        <source>Cylinder size:</source>
        <translation>Dimensioni del cilindro:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="241"/>
        <source>Primaries/Max:</source>
        <translation>Primarie/Max:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="265"/>
        <source>SMART status:</source>
        <translation>Stato SMART:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="303"/>
        <source>More...</source>
        <translation>Altro...</translation>
    </message>
</context>
<context>
    <name>EditExistingPartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="20"/>
        <source>Edit Existing Partition</source>
        <translation>Modifica la partizione esistente</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="50"/>
        <source>Content:</source>
        <translation>Contenuto:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="60"/>
        <source>Keep</source>
        <translation>Mantieni</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="70"/>
        <source>Format</source>
        <translation>Formatta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="83"/>
        <source>Warning: Formatting the partition will erase all existing data.</source>
        <translation>Attenzione: la formattazione della partizione cancellerà tutti i dati!</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="93"/>
        <source>&amp;Mount Point:</source>
        <translation>Punto di &amp;Mount:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="113"/>
        <source>Size:</source>
        <translation>Dimensioni:</translation>
    </message>
</context>
<context>
    <name>EditMountOptionsDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="14"/>
        <source>Edit Mount Options</source>
        <translation>Cambia le opzioni di mount</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="20"/>
        <source>Edit the mount options for this file system:</source>
        <translation>Cambia le opzioni di mount per questo file system:</translation>
    </message>
</context>
<context>
    <name>EditMountPointDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="17"/>
        <source>Path:</source>
        <translation>Percorso:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="46"/>
        <source>Select...</source>
        <translation>Seleziona...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="53"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="63"/>
        <source>Options:</source>
        <translation>Opzioni:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="73"/>
        <source>Read-only</source>
        <translation>Sola lettura</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="80"/>
        <source>Users can mount and unmount</source>
        <translation>Gli utenti possono effettuare mount e unmount</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="87"/>
        <source>No automatic mount</source>
        <translation>Nessun mount automatico</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="94"/>
        <source>No update of file access times</source>
        <translation>Nessun aggiornamento degli orari di accesso ai file</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="101"/>
        <source>Synchronous access</source>
        <translation>Accesso sincrono</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="108"/>
        <source>No update of directory access times</source>
        <translation>Nessun aggiornamento degli orari di accesso alle cartelle</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="115"/>
        <source>No binary execution</source>
        <translation>Nessuna esecuzione di file esenguibili</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="122"/>
        <source>Update access times relative to modification</source>
        <translation>Aggiorna gli orari di accesso relativi alle modifiche</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="142"/>
        <source>More...</source>
        <translation>Altro...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="149"/>
        <source>Dump Frequency:</source>
        <translation>Frequenza dei dump:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="178"/>
        <source>Pass Number:</source>
        <translation>Numero pass:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="285"/>
        <source>Device Node</source>
        <translation>Nodo di dispositivo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="295"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="302"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="309"/>
        <source>Identify by:</source>
        <translation>Identifica con:</translation>
    </message>
</context>
<context>
    <name>EraseDiskPage</name>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="53"/>
        <source>Select drive:</source>
        <translation>Seleziona il disco:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="229"/>
        <source>Before:</source>
        <translation>Prima:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="234"/>
        <source>After:</source>
        <translation>Dopo:</translation>
    </message>
</context>
<context>
    <name>FileSystemSupportDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="17"/>
        <source>This table shows which file systems are supported and which specific operations can be performed on them.
Some file systems need external tools to be installed for them to be supported. But not all operations can be performed on all file systems, even if all required tools are installed. Please see the documentation for details. </source>
        <translation>Questa tabella mostra quali file system sono supportati e quali operazioni possono essere effettuate su di essi.
Alcuni file system necessitano l&apos;installazione di strumenti esterni per essere supportati. Non tutte le operazioni possono essere effettuate su tutti i file system nonostante siano stati installati gli strumenti richiesti. Per ulteriori dettagli, consultare la documentazione.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="65"/>
        <source>File System</source>
        <translation>File System</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="70"/>
        <source>Create</source>
        <translation>Crea</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="75"/>
        <source>Grow</source>
        <translation>Aumenta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="80"/>
        <source>Shrink</source>
        <translation>Riduci</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="85"/>
        <source>Move</source>
        <translation>Sposta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="90"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="95"/>
        <source>Check</source>
        <translation>Controlla</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="100"/>
        <source>Read Label</source>
        <translation>Leggi etichetta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="105"/>
        <source>Write Label</source>
        <translation>Scrivi etichetta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="110"/>
        <source>Read Usage</source>
        <translation>Uso in lettura</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="115"/>
        <source>Backup</source>
        <translation>Backup</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="120"/>
        <source>Restore</source>
        <translation>Ripristino</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="125"/>
        <source>Support Tools</source>
        <translation>Strumenti di supporto</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="135"/>
        <source>Rescan Support</source>
        <comment>@action:button</comment>
        <translation>Ricontrolla supporto</translation>
    </message>
</context>
<context>
    <name>FillGlobalStorageJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="75"/>
        <source>Set partition information</source>
        <translation>Imposta informazioni partizione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="85"/>
        <source>Failed to find path for boot loader</source>
        <translation>Impossibile trovare il percorso per il boot loader</translation>
    </message>
</context>
<context>
    <name>FinishedPage</name>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="77"/>
        <source>&amp;Restart now</source>
        <translation>&amp;Riavvia ora</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.cpp" line="50"/>
        <source>&lt;h1&gt;All done.&lt;/h1&gt;&lt;br/&gt;%1 has been installed on your computer.&lt;br/&gt;You may now restart into your new system, or continue using the %2 Live environment.</source>
        <translation>&lt;h1&gt;Tutto fatto.&lt;/ h1&gt;&lt;br/&gt;%1 è stato installato sul computer.&lt;br/&gt;Ora è possibile riavviare il sistema, o continuare a utilizzare l&apos;ambiente Live di %2 .</translation>
    </message>
</context>
<context>
    <name>FinishedViewStep</name>
    <message>
        <location filename="../src/modules/finished/FinishedViewStep.cpp" line="43"/>
        <source>All done</source>
        <translation>Tutto Fatto</translation>
    </message>
</context>
<context>
    <name>FormatPartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="47"/>
        <source>Format partition %1 (file system: %2, size: %3 MB) on %4.</source>
        <translation>Formatta partizione %1 (file system: %2, dimensioni: %3 MB) su %4</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="59"/>
        <source>The installer failed to format partition %1 on disk &apos;%2&apos;.</source>
        <translation>Il programma di installazione non è riuscito a formattare la partizione %1 sul disco &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="67"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Impossibile aprire il dispositivo &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="76"/>
        <source>Could not open partition table.</source>
        <translation>Impossibile aprire la tabella delle partizioni.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="84"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>Il programma di installazione non è riuscito a creare il file system sulla partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="92"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>Il programma di installazione non è riuscito ad aggiornare la tabella delle partizioni sul disco &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>GreetingPage</name>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="126"/>
        <source>&lt;h1&gt;Welcome to the %1 installer.&lt;/h1&gt;&lt;br/&gt;This program will ask you some questions and set up %2 on your computer.</source>
        <translation>&lt;h1&gt;Benvenuto nel programma di installazione di %1.&lt;/h1&gt;&lt;br/&gt;Ti verranno poste alcune domande e %2 sarà installato sul tuo computer.</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="144"/>
        <source>About %1 installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="146"/>
        <source>&lt;h1&gt;%1&lt;/h1&gt;&lt;br/&gt;&lt;b&gt;%2&lt;br/&gt;for %3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;Copyright 2014 Teo Mrnjavac &amp;lt;teo@kde.org&amp;gt;&lt;br/&gt;Thanks to: Anke Boersma, Aurélien Gâteau, Kevin Kofler, Philip Müller, Pier Luigi Fiorini and Rohan Garg.&lt;br/&gt;&lt;br/&gt;&lt;a href=&quot;https://calamares.io/&quot;&gt;Calamares&lt;/a&gt; development is sponsored by &lt;br/&gt;&lt;a href=&quot;http://www.blue-systems.com/&quot;&gt;Blue Systems&lt;/a&gt; - technologies for a better world.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="176"/>
        <source>%1 support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="104"/>
        <source>&amp;Release notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="114"/>
        <source>&amp;Known issues</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="124"/>
        <source>&amp;Support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="134"/>
        <source>&amp;About</source>
        <translation>&amp;Informazioni su</translation>
    </message>
</context>
<context>
    <name>GreetingViewStep</name>
    <message>
        <location filename="../src/modules/greeting/GreetingViewStep.cpp" line="43"/>
        <source>Welcome</source>
        <translation>Benvenuto</translation>
    </message>
</context>
<context>
    <name>KeyboardPage</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="200"/>
        <source>Set keyboard model to %1.&lt;br/&gt;</source>
        <translation>Imposta il modello di tastiera a %1.&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="202"/>
        <source>Set keyboard layout to %1/%2.</source>
        <translation>Imposta il layout della tastiera a %1%2.</translation>
    </message>
</context>
<context>
    <name>KeyboardViewStep</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardViewStep.cpp" line="48"/>
        <source>Keyboard</source>
        <translation>Tastiera</translation>
    </message>
</context>
<context>
    <name>LCLocaleDialog</name>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="33"/>
        <source>System locale setting</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="40"/>
        <source>The system locale setting affects the language and character set for some command line user interface elements.&lt;br/&gt;The current setting is &lt;b&gt;%1&lt;/b&gt;.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>LocalePage</name>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="159"/>
        <location filename="../src/modules/locale/LocalePage.cpp" line="170"/>
        <source>The system locale is set to %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="167"/>
        <source>Region:</source>
        <translation>Area:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="168"/>
        <source>Zone:</source>
        <translation>Zona:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="173"/>
        <source>&amp;Change...</source>
        <translation>&amp;Cambia...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="267"/>
        <source>Set timezone to %1/%2.&lt;br/&gt;</source>
        <translation>Imposta il fuso orario a %1%2.&lt;br/&gt;</translation>
    </message>
</context>
<context>
    <name>LocaleViewStep</name>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="45"/>
        <source>Loading location data...</source>
        <translation>Caricamento dei dati di posizione...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="79"/>
        <source>Location</source>
        <translation>Posizione</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>Gestore delle partizioni di KDE</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="24"/>
        <source>Devices</source>
        <comment>@title:window</comment>
        <translation>Dispositivi</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="38"/>
        <source>Pending Operations</source>
        <comment>@title:window</comment>
        <translation>Operazioni in attesa</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="49"/>
        <source>Information</source>
        <comment>@title:window</comment>
        <translation>Informazione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="63"/>
        <source>Log Output</source>
        <comment>@title:window</comment>
        <translation>Registra l&apos;output</translation>
    </message>
</context>
<context>
    <name>MoveFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="66"/>
        <source>Move file system of partition %1.</source>
        <translation>Sposta il file system della partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="80"/>
        <source>Could not open file system on partition %1 for moving.</source>
        <translation>Impossibile aprire il file system della partizione %1 per lo spostamento.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="86"/>
        <source>Could not create target for moving file system on partition %1.</source>
        <translation>Impossibile creare la destinazione per lo spostamento del file system sulla partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="95"/>
        <source>Moving of partition %1 failed, changes have been rolled back.</source>
        <translation>Lo spostamento della partizione %1 non è andato a buon fine, i cambiamenti sono stati annullati.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="101"/>
        <source>Moving of partition %1 failed. Roll back of the changes have failed.</source>
        <translation>Lo spostamento della partizione %1 non è andato a buon fine. L&apos;annullamento dei cambiamenti non è andato a buon fine.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="113"/>
        <source>Updating boot sector after the moving of partition %1 failed.</source>
        <translation>L&apos;aggiornamento del settore di avvio eseguito dopo lo spostamento della partizione %1 non è andato a buon fine.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="127"/>
        <source>The logical sector sizes in the source and target for copying are not the same. This is currently unsupported.</source>
        <translation>Le dimensioni dei settori logici dell&apos;origine e della destinazione non  uguali per la copia. Attualmente ciò non è supportato.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="200"/>
        <source>Source and target for copying do not overlap: Rollback is not required.</source>
        <translation>Origine e destinazione per la copia non coincidono: non è necessario annullare i cambiamenti.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="224"/>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="232"/>
        <source>Could not open device %1 to rollback copying.</source>
        <translation>Impossibile aprire il dispositivo %1 per annullare la copia.</translation>
    </message>
</context>
<context>
    <name>Page_Keyboard</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="70"/>
        <source>Keyboard Model:</source>
        <translation>Modello della tastiera:</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Digita qui per provare la tastiera</translation>
    </message>
</context>
<context>
    <name>Page_UserSetup</name>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="33"/>
        <source>What is your name?</source>
        <translation>Qual&apos;è il tuo nome?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="111"/>
        <source>What name do you want to use to log in?</source>
        <translation>Che nome vuoi usare per autenticarti?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="191"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="319"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="425"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="553"/>
        <source>font-weight: normal</source>
        <translation>Dimensione font: normale</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="194"/>
        <source>&lt;small&gt;If more than one person will use this computer, you can set up multiple accounts after installation.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Se più utenti useranno questo computer, puoi impostare altri account dopo l&apos;installazione.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="217"/>
        <source>Choose a password to keep your account safe.</source>
        <translation>Scegli una password per rendere sicuro il tuo account.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="322"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors. A good password will contain a mixture of letters, numbers and punctuation, should be at least eight characters long, and should be changed at regular intervals.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Inserisci la password due volte per controllare eventuali errori di battitura. Una buona password contiene lettere, numeri e segni di punteggiatura. Deve essere lunga almeno otto caratteri e dovrebbe essere cambiata a intervalli regolari.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="345"/>
        <source>What is the name of this computer?</source>
        <translation>Qual è il nome di questo computer?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="428"/>
        <source>&lt;small&gt;This name will be used if you make the computer visible to others on a network.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Questo nome sarà usato se rendi visibile il computer ad altre persone in una rete.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="451"/>
        <source>Choose a password for the administrator account.</source>
        <translation>Scegli una password per l&apos;account dell&apos;amministratore.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="556"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Inserisci la password due volte per controllare eventuali errori di battitura.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="596"/>
        <source>Log in automatically</source>
        <translation>Accedi automaticamente</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="606"/>
        <source>Require my password to log in</source>
        <translation>Richiedi la password per accedere</translation>
    </message>
</context>
<context>
    <name>PartPropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="49"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>File system:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="65"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>Etichetta:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="82"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>Questo file system non supporta l&apos;assegnazione di un&apos;etichetta.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="92"/>
        <source>Recreate existing file system</source>
        <comment>@action:button</comment>
        <translation>Ricrea un file system esistente</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="106"/>
        <source>Mount point:</source>
        <comment>@label</comment>
        <translation>Punto di mount:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="123"/>
        <source>Partition type:</source>
        <comment>@label</comment>
        <translation>Tipo partizione:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="140"/>
        <source>Status:</source>
        <comment>@label</comment>
        <translation>Stato:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="157"/>
        <source>UUID:</source>
        <comment>@label</comment>
        <translation>UUID:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="187"/>
        <source>Size:</source>
        <comment>@label</comment>
        <translation>Dimensione:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="210"/>
        <source>Available:</source>
        <comment>@label partition capacity available</comment>
        <translation>Disponibile:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="227"/>
        <source>Used:</source>
        <comment>@label partition capacity used</comment>
        <translation>In uso:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="251"/>
        <source>First sector:</source>
        <comment>@label</comment>
        <translation>Primo settore:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="268"/>
        <source>Last sector:</source>
        <comment>@label</comment>
        <translation>Ultimo settore:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="285"/>
        <source>Number of sectors:</source>
        <comment>@label</comment>
        <translation>Numero di settori:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="309"/>
        <source>Flags:</source>
        <comment>@label</comment>
        <translation>Flag:</translation>
    </message>
</context>
<context>
    <name>PartitionManagerWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>Gestore delle partizioni di KDE</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="70"/>
        <source>Partition</source>
        <translation>Partizione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="75"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="80"/>
        <source>Mount Point</source>
        <translation>Punto di mount</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="85"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="90"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="95"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="100"/>
        <source>Used</source>
        <translation>In uso</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="105"/>
        <source>Available</source>
        <translation>Disponibile</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="110"/>
        <source>First Sector</source>
        <translation>Primo settore</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="115"/>
        <source>Last Sector</source>
        <translation>Ultimo settore</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="120"/>
        <source>Number of Sectors</source>
        <translation>Numero di settori</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="125"/>
        <source>Flags</source>
        <translation>Flag</translation>
    </message>
</context>
<context>
    <name>PartitionModel</name>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="132"/>
        <source>Free Space</source>
        <translation>Spazio disponibile</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="136"/>
        <source>New partition</source>
        <translation>Nuova partizione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="175"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="177"/>
        <source>File System</source>
        <translation>File System</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="179"/>
        <source>Mount Point</source>
        <translation>Punto di mount</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="181"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
</context>
<context>
    <name>PartitionPage</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>&amp;Disco:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="51"/>
        <source>&amp;Revert All Changes</source>
        <translation>&amp;Annulla tutte le modifiche</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="84"/>
        <source>New Partition &amp;Table</source>
        <translation>Nuova &amp;Tabella delle partizioni</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="104"/>
        <source>&amp;Create</source>
        <translation>&amp;Crea</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="111"/>
        <source>&amp;Edit</source>
        <translation>&amp;Modifica</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="118"/>
        <source>&amp;Delete</source>
        <translation>&amp;Cancella</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="145"/>
        <source>&amp;Install boot loader on:</source>
        <translation>&amp;Installa il boot loader su:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.cpp" line="135"/>
        <source>Are you sure you want to create a new partition table on %1?</source>
        <translation>Sei sicuro di voler creare una nuova tabella delle partizioni su %1?</translation>
    </message>
</context>
<context>
    <name>PartitionViewStep</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="66"/>
        <source>Gathering system information...</source>
        <translation>Raccolta delle informazioni di sistema...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="160"/>
        <source>Partitions</source>
        <translation>Partizioni</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="188"/>
        <source>Before:</source>
        <translation>Prima:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="193"/>
        <source>After:</source>
        <translation>Dopo:</translation>
    </message>
</context>
<context>
    <name>PreparePage</name>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="39"/>
        <source>For best results, please ensure that this computer:</source>
        <translation>Per ottenere prestazioni ottimali, assicurarsi che questo computer:</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="96"/>
        <source>This computer does not satisfy the minimum requirements for installing %1.
Installation cannot continue.</source>
        <translation>Questo computer non soddisfa i requisiti minimi per l&apos;installazione di %1. 
L&apos;installazione non può continuare.</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="109"/>
        <source>This computer does not satisfy some of the recommended requirements for installing %1.
Installation can continue, but some features might be disabled.</source>
        <translation>Questo computer non soddisfa alcuni requisiti raccomandati per l&apos;installazione di %1. L&apos;installazione può continuare ma alcune funzionalità potrebbero essere disattivate.</translation>
    </message>
</context>
<context>
    <name>PrepareViewStep</name>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="54"/>
        <source>Gathering system information...</source>
        <translation>Raccolta informazioni sul sistema...</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="91"/>
        <source>has at least %1 GB available drive space</source>
        <translation>ha almeno %1 GB di spazio libero</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="99"/>
        <source>has at least %1 GB working memory</source>
        <translation>ha almeno %1 GB di memoria</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="107"/>
        <source>is plugged in to a power source</source>
        <translation>è collegato a una presa di alimentazione</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="114"/>
        <source>is connected to the Internet</source>
        <translation>è connesso a Internet</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="158"/>
        <source>Prepare</source>
        <translation>Prepara</translation>
    </message>
</context>
<context>
    <name>ProgressTreeModel</name>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="138"/>
        <source>Prepare</source>
        <translation>Prepara</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="151"/>
        <source>Install</source>
        <translation>Installa</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="161"/>
        <source>Finish</source>
        <translation>Termina</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="82"/>
        <source>Default Keyboard Model</source>
        <translation>Modello tastiera di default</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="127"/>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="163"/>
        <source>Default</source>
        <translation>Default</translation>
    </message>
</context>
<context>
    <name>ReleaseDialog</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="20"/>
        <source>KDE Release Builder</source>
        <translation>Builder di rilascio per KDE</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="32"/>
        <source>Application</source>
        <translation>Applicazione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="38"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="48"/>
        <source>&amp;Version:</source>
        <translation>&amp;Versione:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="93"/>
        <source>Repository and Revision</source>
        <translation>Repository e Revisione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="99"/>
        <source>&amp;Checkout From:</source>
        <translation>&amp;Checkout da:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="119"/>
        <source>trunk</source>
        <translation>trunk</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="124"/>
        <source>branches</source>
        <translation>branches</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="129"/>
        <source>tags</source>
        <translation>tags</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="137"/>
        <source>Ta&amp;g/Branch:</source>
        <translation>Ta&amp;g/Branch:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="163"/>
        <source>&amp;SVN Access:</source>
        <translation>Accesso &amp;SVN:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="183"/>
        <source>anonsvn</source>
        <translation>anonsvn</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="188"/>
        <source>https</source>
        <translation>https</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="193"/>
        <source>svn+ssh</source>
        <translation>svn+ssh</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="201"/>
        <source>&amp;User:</source>
        <translation>&amp;Utente:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="236"/>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="242"/>
        <source>Get &amp;Documentation</source>
        <translation>Ottieni &amp;Documentazione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="252"/>
        <source>Get &amp;Translations</source>
        <translation>Ottieni &amp;Traduzioni</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="262"/>
        <source>C&amp;reate Tag</source>
        <translation>C&amp;rea Tag</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="271"/>
        <source>S&amp;kip translations below completion:</source>
        <translation>S&amp;alta le traduzioni dopo il completamento</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="306"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="324"/>
        <source>Create Tar&amp;ball</source>
        <translation>Crea Tar&amp;ball</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="334"/>
        <source>Apply &amp;fixes</source>
        <translation>Applica le &amp;correzioni</translation>
    </message>
</context>
<context>
    <name>ReplacePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="14"/>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>&amp;Disco:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="109"/>
        <source>Select where to install %1.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;this will delete all files on the selected partition.</source>
        <translation>Seleziona dove installare %1.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Attenzione: &lt;/font&gt;questo elimina tutti i file nella partizione selezionata.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="136"/>
        <source>The selected item does not appear to be a valid partition.</source>
        <translation>L&apos;elemento selezionato non sembra una partizione valida.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="144"/>
        <source>%1 cannot be installed on empty space. Please select an existing partition.</source>
        <translation>%1 non può essere installato su dello spazio vuoto. Seleziona una partizione esistente.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="155"/>
        <source>%1 cannot be installed on an extended partition. Please select an existing primary or logical partition.</source>
        <translation>%1 non può essere installato su una partizione estesa. Seleziona una partizione primaria o logica esistente.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="166"/>
        <source>%1 cannot be installed on this partition.</source>
        <translation>%1 non può essere installato su questa partizione.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="173"/>
        <source>Data partition (%1)</source>
        <translation>Partizione dati (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="190"/>
        <source>Unknown system partition (%1)</source>
        <translation>Partizione di sistema sconosciuta (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="195"/>
        <source>%1 system partition (%2)</source>
        <translation>%1 partizione di sistema (%2)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="206"/>
        <source>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;The partition %1 is too small for %2. Please select a partition with capacity at least %3 GiB.</source>
        <translation>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;La partizione %1 è troppo piccola per %2. Seleziona una partizione con una capacità di almeno %3 GB.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="220"/>
        <source>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 will be installed on %2.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;all data on partition%2 will be lost.</source>
        <translation>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 sarà installato su %2.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Attenzione: &lt;/font&gt;tutti i dati sulla partizione %2 andranno persi.</translation>
    </message>
</context>
<context>
    <name>ResizeFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="75"/>
        <source>Resize file system on partition %1.</source>
        <translation>Ridimensiona il file system sulla partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="90"/>
        <source>Parted failed to resize filesystem.</source>
        <translation>Parted non è riuscito a ridimensionare il filesystem.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="100"/>
        <source>Failed to resize filesystem.</source>
        <translation>Impossibile ridimensionare il filesystem.</translation>
    </message>
</context>
<context>
    <name>ResizePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="186"/>
        <source>Resize partition %1.</source>
        <translation>Ridimensiona partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="208"/>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="266"/>
        <source>The installer failed to resize partition %1 on disk &apos;%2&apos;.</source>
        <translation>Il programma di installazione non è riuscito a ridimensionare la partizione %1 sul disco &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="213"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Non riesco ad aprire il dispositivo &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>SetHostNameJob</name>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="36"/>
        <source>Set hostname %1</source>
        <translation>Imposta hostname %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="46"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="53"/>
        <source>Internal Error</source>
        <translation>Errore interno</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="60"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="71"/>
        <source>Cannot write hostname to target system</source>
        <translation>Impossibile scrivere l&apos;hostname nel sistema di destinazione</translation>
    </message>
</context>
<context>
    <name>SetKeyboardLayoutJob</name>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="57"/>
        <source>Set keyboard model to %1, layout to %2-%3</source>
        <translation>Imposta tastiera a %1, con layout %2-%3</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="284"/>
        <source>Failed to write keyboard configuration for the virtual console.</source>
        <translation>Non è stato possibile scrivere la configurazione della tastiera per la console virtuale.</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="285"/>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="289"/>
        <source>Failed to write to %1</source>
        <translation>Non è stato possibile scrivere su %1</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="288"/>
        <source>Failed to write keyboard configuration for X11.</source>
        <translation>Non è stato possibile scrivere la configurazione della tastiera per X11.</translation>
    </message>
</context>
<context>
    <name>SetPartGeometryJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="143"/>
        <source>Update geometry of partition %1.</source>
        <translation>Aggiorna la geometria della partizione %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="155"/>
        <source>Failed to change the geometry of the partition.</source>
        <translation>Impossibile modificare la geometria della partizione.</translation>
    </message>
</context>
<context>
    <name>SetPasswordJob</name>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="42"/>
        <source>Set password for user %1</source>
        <translation>Imposta la password per l&apos;utente %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="52"/>
        <source>Bad destination system path.</source>
        <translation>Percorso di destinazione del sistema errato.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="53"/>
        <source>rootMountPoint is %1</source>
        <translation>punto di mount per root è %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="62"/>
        <source>Cannot set password for user %1.</source>
        <translation>Impossibile impostare la password per l&apos;utente %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="64"/>
        <source>usermod terminated with error code %1.</source>
        <translation>usermod si è chiuso con codice di errore %1.</translation>
    </message>
</context>
<context>
    <name>SetTimezoneJob</name>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="41"/>
        <source>Set timezone to %1/%2</source>
        <translation>Imposta il fuso orario su %1%2</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="56"/>
        <source>Cannot access selected timezone path.</source>
        <translation>Impossibile accedere al percorso della timezone selezionata.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="57"/>
        <source>Bad path: %1</source>
        <translation>Percorso errato: %1</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="69"/>
        <source>Cannot set timezone.</source>
        <translation>Impossibile impostare il fuso orario.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="70"/>
        <source>Link creation failed, target: %1; link name: %2</source>
        <translation>Creazione del collegamento non riuscita, destinazione: %1; nome collegamento: %2</translation>
    </message>
</context>
<context>
    <name>SizeDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="62"/>
        <source>First sector:</source>
        <comment>@label:listbox</comment>
        <translation>Primo settore:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="97"/>
        <source>Last sector:</source>
        <comment>@label:listbox</comment>
        <translation>Ultimo settore:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="120"/>
        <source>Align partition</source>
        <translation>Allinea partizione</translation>
    </message>
</context>
<context>
    <name>SizeDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="55"/>
        <source>Partition type:</source>
        <comment>@label:listbox</comment>
        <translation>Tipo di partizione:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="70"/>
        <source>Primary</source>
        <translation>Primaria</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="77"/>
        <source>Extended</source>
        <translation>Estesa</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="84"/>
        <source>Logical</source>
        <translation>Logica</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="99"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>File system:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="115"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>Etichetta:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="134"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>Questo file system non supporta l&apos;impostazione di una label.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="152"/>
        <source>Minimum size:</source>
        <comment>@label</comment>
        <translation>Dimensioni minime:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="175"/>
        <source>Maximum size:</source>
        <comment>@label</comment>
        <translation>Dimensioni massime:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="198"/>
        <source>Free space before:</source>
        <comment>@label:listbox</comment>
        <translation>Spazio libero precedente:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="233"/>
        <source>Size:</source>
        <comment>@label:listbox</comment>
        <translation>Dimensioni:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="262"/>
        <source>Free space after:</source>
        <comment>@label:listbox</comment>
        <translation>Spazio libero seguente:</translation>
    </message>
</context>
<context>
    <name>SmartDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="23"/>
        <source>SMART status:</source>
        <translation>stato SMART:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="63"/>
        <source>Model:</source>
        <translation>Modello:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="92"/>
        <source>Serial number:</source>
        <translation>Numero di serie:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="121"/>
        <source>Firmware revision:</source>
        <translation>Versione del firmware:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="150"/>
        <source>Temperature:</source>
        <translation>Temperatura:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="179"/>
        <source>Bad sectors:</source>
        <translation>Settori difettosi:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="208"/>
        <source>Powered on for:</source>
        <translation>Acceso per:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="237"/>
        <source>Power cycles:</source>
        <translation>Ricariche:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="289"/>
        <source>Id</source>
        <translation>Id</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="294"/>
        <source>Attribute</source>
        <translation>Attributo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="299"/>
        <source>Failure Type</source>
        <translation>Tipo di guasto</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="304"/>
        <source>Update Type</source>
        <translation>Tipo di aggiornamento</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="309"/>
        <source>Worst</source>
        <translation>Peggiore</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="314"/>
        <source>Current</source>
        <translation>Attuale</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="319"/>
        <source>Threshold</source>
        <translation>Soglia</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="324"/>
        <source>Raw</source>
        <translation>Raw</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="329"/>
        <source>Assessment</source>
        <translation>Valutazione</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="334"/>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="385"/>
        <source>Overall assessment:</source>
        <translation>Valutazione complessiva</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="414"/>
        <source>Self tests:</source>
        <translation>Test automatici:</translation>
    </message>
</context>
<context>
    <name>SummaryViewStep</name>
    <message>
        <location filename="../src/modules/summary/SummaryViewStep.cpp" line="41"/>
        <source>Summary</source>
        <translation>Riepilogo</translation>
    </message>
</context>
<context>
    <name>TreeLogBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="54"/>
        <source>Sev.</source>
        <comment>@title:column Severity of a log entry / log level. Text must be very short.</comment>
        <translation>Vari</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="57"/>
        <source>Severity</source>
        <translation>Gravità</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="62"/>
        <source>Time</source>
        <comment>@title:column a time stamp of a log entry</comment>
        <translation>Ora</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="67"/>
        <source>Message</source>
        <comment>@title:column the text message of a log entry</comment>
        <translation>Messaggio</translation>
    </message>
</context>
<context>
    <name>UsersPage</name>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="233"/>
        <source>Your username is too long.</source>
        <translation>Il nome utente è troppo lungo.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="243"/>
        <source>Your username contains invalid characters. Only lowercase letters and numbers are allowed.</source>
        <translation>Il tuo nome utente contiene caratteri non validi. Sono ammessi solo lettere minuscole e numeri.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="287"/>
        <source>Your hostname is too short.</source>
        <translation>Il tuo hostname è troppo corto.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="298"/>
        <source>Your hostname is too long.</source>
        <translation>Il tuo hostname è troppo lungo.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="309"/>
        <source>Your hostname contains invalid characters. Only letters, numbers and dashes are allowed.</source>
        <translation>Il tuo hostname contiene caratteri non validi. Sono ammessi solo lettere, numeri e trattini.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="340"/>
        <location filename="../src/modules/users/UsersPage.cpp" line="373"/>
        <source>Your passwords do not match!</source>
        <translation>Le tue password non corrispondono!</translation>
    </message>
</context>
<context>
    <name>UsersViewStep</name>
    <message>
        <location filename="../src/modules/users/UsersViewStep.cpp" line="46"/>
        <source>Users</source>
        <translation>Utenti</translation>
    </message>
</context>
</TS>