<?xml version="1.0" ?><!DOCTYPE TS><TS language="ja" version="2.1">
<context>
    <name>AlongsidePage</name>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="67"/>
        <source>Choose partition to shrink:</source>
        <translation>縮小するパーティションを選択してください</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="68"/>
        <source>Allocate drive space by dragging the divider below:</source>
        <translation>下記のデバイダをドラッグして、ドライブスペースを割り当てる：</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="167"/>
        <source>With this operation, the partition &lt;b&gt;%1&lt;/b&gt; which contains %4 will be shrunk to %2MB and a new %3MB partition will be created for %5.</source>
        <translation>この操作によって、   %4 を含むパーティション &lt;b&gt;%1&lt;/b&gt; が %2 MBに縮小し、新たに %5 のために %3MB のパーティションが生成されます。</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="37"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="44"/>
        <source>Open in External Browser</source>
        <translation>外部ブラウザで開く</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="33"/>
        <source>Operations and Jobs</source>
        <translation>操作およびジョブ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="38"/>
        <source>Time Elapsed</source>
        <translation>経過時間</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="64"/>
        <source>Total Time: 00:00:00</source>
        <translation>トータル時間: 00:00:00</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="81"/>
        <source>Operation: %p%</source>
        <translation>操作:  %p%</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="91"/>
        <source>Status</source>
        <translation>状態</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="107"/>
        <source>Total: %p%</source>
        <translation>トータル: %p%</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="20"/>
        <source>Installer</source>
        <translation>インストーラー</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="168"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Welcome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;ようこそ&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="198"/>
        <source>Location</source>
        <translation>地域</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="224"/>
        <source>License Approval</source>
        <translation>ライセンスに同意</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="257"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Installation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;インストール&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="287"/>
        <source>Install System</source>
        <translation>システムをインストール</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="320"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Configuration&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;設定&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="331"/>
        <source>Reboot</source>
        <translation>再起動</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="410"/>
        <source>Language</source>
        <translation>言語</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="443"/>
        <source>User Info</source>
        <translation>ユーザー情報</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="469"/>
        <source>Summary</source>
        <translation>要約</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="514"/>
        <source>Keyboard</source>
        <translation>キーボード</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="521"/>
        <source>Disk Setup</source>
        <translation>ディスクのセットアップ</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="528"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Preparation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;準備&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>BootLoaderModel</name>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="57"/>
        <source>Master Boot Record of %1</source>
        <translation>%1 のマスターブートレコード</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="71"/>
        <source>Boot Partition</source>
        <translation>ブートパーティション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="76"/>
        <source>System Partition</source>
        <translation>システムパーティション</translation>
    </message>
</context>
<context>
    <name>Calamares::DebugWindow</name>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="24"/>
        <source>GlobalStorage</source>
        <translation>グローバルストレージ</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="34"/>
        <source>JobQueue</source>
        <translation>ジョブキュー</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="44"/>
        <source>Modules</source>
        <translation>モジュール</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.cpp" line="95"/>
        <source>Debug information</source>
        <translation>デバッグ情報</translation>
    </message>
</context>
<context>
    <name>Calamares::InstallationViewStep</name>
    <message>
        <location filename="../src/libcalamaresui/InstallationViewStep.cpp" line="75"/>
        <source>Install</source>
        <translation>インストール</translation>
    </message>
</context>
<context>
    <name>Calamares::JobThread</name>
    <message>
        <location filename="../src/libcalamares/JobQueue.cpp" line="88"/>
        <source>Done</source>
        <translation>完了</translation>
    </message>
</context>
<context>
    <name>Calamares::ProcessJob</name>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="51"/>
        <source>Run command %1 %2</source>
        <translation>コマンド %1 %2 を実行</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="79"/>
        <source>External command crashed</source>
        <translation>外部コマンドのクラッシュ</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="80"/>
        <source>Command %1 crashed.
Output:
%2</source>
        <translation>コマンド %1 がクラッシュ
出力:
%2</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="85"/>
        <source>External command failed to start</source>
        <translation>外部コマンドの開始に失敗</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="86"/>
        <source>Command %1 failed to start.</source>
        <translation>コマンド %1 の開始に失敗</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="90"/>
        <source>Internal error when starting command</source>
        <translation>コマンド開始時における内部エラー</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="91"/>
        <source>Bad parameters for process job call.</source>
        <translation>ジョブ呼び出しにおける不正なパラメータ</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="94"/>
        <source>External command failed to finish</source>
        <translation>外部コマンドの完了に失敗</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="95"/>
        <source>Command %1 failed to finish in %2s.
Output:
%3</source>
        <translation>%2s においてコマンド %1 の完了に失敗。
出力:
%3 </translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="101"/>
        <source>External command finished with errors</source>
        <translation>外部コマンドでエラー</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="102"/>
        <source>Command %1 finished with exit code %2.
Output:
%3</source>
        <translation>コマンド %1 がコード %2 によって終了
出力:
%3</translation>
    </message>
</context>
<context>
    <name>Calamares::PythonJob</name>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="234"/>
        <source>Run script %1</source>
        <translation>スクリプト %1 を実行</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="249"/>
        <source>Bad working directory path</source>
        <translation>不正なワーキングディレクトリパス</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="250"/>
        <source>Working directory %1 for python job %2 is not readable.</source>
        <translation>pythonジョブ %2 におけるワーキングディレクトリ %1 が読み込めません。</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="260"/>
        <source>Bad main script file</source>
        <translation>不正なメインスクリプトファイル</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="261"/>
        <source>Main script file %1 for python job %2 is not readable.</source>
        <translation>pythonジョブ %2 におけるメインスクリプトファイル %1 が読み込めません。</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="306"/>
        <source>Boost.Python error in job &quot;%1&quot;.</source>
        <translation>ジョブ &quot;%1&quot; でのBoost.Pythonエラー</translation>
    </message>
</context>
<context>
    <name>Calamares::ViewManager</name>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="64"/>
        <source>&amp;Back</source>
        <translation>戻る（&amp;B）</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="65"/>
        <source>&amp;Next</source>
        <translation>次へ（&amp;N）</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="66"/>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="302"/>
        <source>&amp;Cancel</source>
        <translation>中止（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="86"/>
        <source>Cancel installation?</source>
        <translation>インストールをキャンセルしますか?</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="87"/>
        <source>Do you really want to cancel the current install process?
The installer will quit and all changes will be lost.</source>
        <translation>本当に現在の作業をキャンセルしますか?
全ての変更が取り消されます。</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="272"/>
        <source>&amp;Quit</source>
        <translation>終了（&amp;Q）</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="183"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="184"/>
        <source>Installation Failed</source>
        <translation>インストールに失敗</translation>
    </message>
</context>
<context>
    <name>CalamaresPython::Helper</name>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="234"/>
        <source>Unknown exception type</source>
        <translation>不知の例外型</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="247"/>
        <source>unparseable Python error</source>
        <translation>解析不能なPythonエラー</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="263"/>
        <source>unparseable Python traceback</source>
        <translation>解析不能なPythonトラックバック</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="267"/>
        <source>Unfetchable Python error.</source>
        <translation>取得不能なPythonエラー。</translation>
    </message>
</context>
<context>
    <name>CalamaresWindow</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="44"/>
        <source>%1 Installer</source>
        <translation>%1 インストーラー</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="98"/>
        <source>Show debug information</source>
        <translation>デバッグ情報を表示</translation>
    </message>
</context>
<context>
    <name>CheckFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="34"/>
        <source>Checking file system on partition %1.</source>
        <translation>パーティション %1 のファイルシステムをチェック。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="50"/>
        <source>The file system check on partition %1 failed.</source>
        <translation>%1 のファイルシステムのチェックに失敗しました。</translation>
    </message>
</context>
<context>
    <name>ChoicePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="115"/>
        <source>This computer currently does not seem to have an operating system on it. What would you like to do?</source>
        <translation>このコンピュータには現在オペレーションシステムが搭載されて無いみたいです。どうしますか?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="119"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="187"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="234"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will delete all of your programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;ディスクを消去して %1をインストール&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;警告: &lt;/font&gt;この操作はすべてのプログラム、文書、画像、音楽などのファイルを削除します。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="125"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="162"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="193"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="240"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which disk to erase.</source>
        <translation>&lt;b&gt;ディスクを消去して %1 をインストール &lt;/b&gt;&lt;br/&gt;どのディスクを消去するか、選択します。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="141"/>
        <source>This computer currently has %1 on it. What would you like to do?</source>
        <translation>このコンピュータには %1 が存在します。どうしますか?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="145"/>
        <source>&lt;b&gt;Install %2 alongside %1&lt;/b&gt;&lt;br/&gt;The installer will shrink the %1 volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation>&lt;b&gt; %1 に共存して %2 をインストール&lt;/b&gt;&lt;br/&gt;インストーラーは %2 のために %1 の容量を縮小します。コンピュータの起動時にどのオペレーティングシステムを起動させるか選択することができます。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="167"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="198"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="245"/>
        <source>&lt;b&gt;Replace a partition with %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which partition to erase.</source>
        <translation>&lt;b&gt;パーティションを %1 に置き換える &lt;/b&gt;&lt;br/&gt;どのディスクを消去するか、選択します。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="179"/>
        <source>&lt;b&gt;Install %1 alongside your current operating system&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation>&lt;b&gt; 現在のオペレーティングシステムに共存して %1 をインストール&lt;/b&gt;&lt;br/&gt;インストーラーは %2 のために現在のパーティションの容量を縮小します。コンピュータの起動時にどのオペレーティングシステムを起動させるか選択することができます。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="226"/>
        <source>&lt;b&gt;Install %1 alongside your current operating systems&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation>&lt;b&gt; 現在のオペレーティングシステムに共存して %1をインストール&lt;/b&gt;&lt;br/&gt;インストーラーは %2 のために現在のパーティションの容量を縮小します。コンピュータの起動時にどのオペレーティングシステムを起動させるか選択することができます。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="261"/>
        <source>&lt;b&gt;Manual partitioning&lt;/b&gt;&lt;br/&gt;You can create or resize partitions yourself, or choose multiple partitions for %1.</source>
        <translation>&lt;b&gt;手動パーティショニング&lt;/b&gt;&lt;br/&gt;手動でのパーティションの作成およびサイズ変更、あるいは %1 のための複数のパーティションの選択を行うことができます。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="154"/>
        <source>&lt;b&gt;Erase entire disk with %1 and install %2&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will erase the whole disk and delete all of your %1 programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;%1ディスクの全てを消去し %2 をインストール&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;警告: &lt;/font&gt;この操作はディスクの全てのデータを消去し、全ての %1 プログラム、文書、画像、音楽、その他ファイルを削除します。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="176"/>
        <source>This computer already has an operating system on it. What would you like to do?</source>
        <translation>このコンピュータにはすでにオペレーティングシステムが搭載されています。どうしますか?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="223"/>
        <source>This computer currently has multiple operating systems on it. What would you like to do?</source>
        <translation>このコンピュータには現在複数のオペレーションシステムが搭載されています。どうしますか?</translation>
    </message>
</context>
<context>
    <name>ClearMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="42"/>
        <source>Clear mounts for partitioning operations on %1</source>
        <translation>%1 のパーティション操作のため、マウントを解除</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="81"/>
        <source>Cleared all mounts for %1</source>
        <translation>%1 の全てのマウントを解除</translation>
    </message>
</context>
<context>
    <name>ClearTempMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="38"/>
        <source>Clear all temporary mounts.</source>
        <translation>全てのテンポラリなマウントをクリア</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="49"/>
        <source>Cannot get list of temporary mounts.</source>
        <translation>テンポラリなマウントのリストを取得できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="88"/>
        <source>Cleared all temporary mounts.</source>
        <translation>全てのテンポラリなマウントがクリアされました。</translation>
    </message>
</context>
<context>
    <name>ConfigurePageAdvanced</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="23"/>
        <source>Permissions</source>
        <translation>パーミッション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="35"/>
        <source>Allow applying operations without administrator privileges</source>
        <translation>管理者権限なしでの操作を許可する</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="51"/>
        <source>Backend</source>
        <translation>バックエンド</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="57"/>
        <source>Active backend:</source>
        <translation>アクティブなバックエンド:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="79"/>
        <source>Units</source>
        <translation>単位</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="85"/>
        <source>Preferred unit:</source>
        <translation>選択する単位:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="96"/>
        <source>Byte</source>
        <translation>Byte</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="101"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="106"/>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="111"/>
        <source>GiB</source>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="116"/>
        <source>TiB</source>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="121"/>
        <source>PiB</source>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="126"/>
        <source>EiB</source>
        <translation>EiB</translation>
    </message>
</context>
<context>
    <name>ConfigurePageFileSystemColors</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="23"/>
        <source>File Systems</source>
        <translation>ファイルシステム</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="29"/>
        <source>luks:</source>
        <translation>luks:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="45"/>
        <source>ntfs:</source>
        <translation>ntfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="58"/>
        <source>ext2:</source>
        <translation>ext2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="87"/>
        <source>ext3:</source>
        <translation>ext3:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="116"/>
        <source>ext4:</source>
        <translation>ext4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="132"/>
        <source>btrfs:</source>
        <translation>btrfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="174"/>
        <source>linuxswap:</source>
        <translation>linuxswap:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="190"/>
        <source>fat16:</source>
        <translation>fat16:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="219"/>
        <source>fat32:</source>
        <translation>fat32:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="248"/>
        <source>zfs:</source>
        <translation>zfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="264"/>
        <source>reiserfs:</source>
        <translation>reiserfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="293"/>
        <source>reiser4:</source>
        <translation>reiser4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="322"/>
        <source>hpfs:</source>
        <translation>hpfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="338"/>
        <source>jfs</source>
        <translation>jfs</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="367"/>
        <source>hfs:</source>
        <translation>hfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="396"/>
        <source>hfsplus:</source>
        <translation>hfsplus:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="412"/>
        <source>ufs:</source>
        <translation>ufs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="441"/>
        <source>xfs:</source>
        <translation>xfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="470"/>
        <source>ocfs2:</source>
        <translation>ocfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="489"/>
        <source>extended:</source>
        <translation>拡張:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="518"/>
        <source>unformatted:</source>
        <translation>フォーマットされていない:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="547"/>
        <source>unknown:</source>
        <translation>未知の:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="570"/>
        <source>exfat:</source>
        <translation>exfat:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="583"/>
        <source>nilfs2:</source>
        <translation>nilfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="622"/>
        <source>lvm2 pv:</source>
        <translation>lvm2 pv:</translation>
    </message>
</context>
<context>
    <name>ConfigurePageGeneral</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="23"/>
        <source>Partition Alignment</source>
        <translation>パーティションアライメント</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="29"/>
        <source>Use cylinder based alignment (Windows XP compatible)</source>
        <translation>Cylinder based alignment (Windows XP と互換性があります) を使用</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="42"/>
        <source>Sector alignment:</source>
        <translation>セクタアライメント:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="55"/>
        <source> sectors</source>
        <translation>セクタ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="71"/>
        <source>Align partitions per default</source>
        <translation>デフォルトの方法でパーティションアライメントを実施</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="90"/>
        <source>Logging</source>
        <translation>Logging</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="96"/>
        <source>Hide messages below:</source>
        <translation>メッセージを表示しない:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="107"/>
        <source>Debug</source>
        <translation>デバッグ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="112"/>
        <source>Information</source>
        <translation>情報</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="117"/>
        <source>Warning</source>
        <translation>警告</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="122"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="139"/>
        <source>File Systems</source>
        <translation>ファイルシステム</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="145"/>
        <source>Default file system:</source>
        <translation>デフォルトのファイルシステム;</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="167"/>
        <source>Shredding</source>
        <translation>破砕</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="173"/>
        <source>Overwrite with:</source>
        <translation>上書き:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="180"/>
        <source>Random data</source>
        <translation>ランダムデータ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="190"/>
        <source>Zeros</source>
        <translation>ゼロ</translation>
    </message>
</context>
<context>
    <name>CreatePartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="14"/>
        <source>Create a Partition</source>
        <translation>パーティションの生成</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="38"/>
        <source>Partition &amp;Type:</source>
        <translation>パーティションの種類（&amp;T）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="50"/>
        <source>&amp;Primary</source>
        <translation>プライマリ（&amp;P）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="60"/>
        <source>E&amp;xtended</source>
        <translation>拡張（&amp;x）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="89"/>
        <source>F&amp;ile System:</source>
        <translation>ファイルシステム:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="118"/>
        <source>&amp;Mount Point:</source>
        <translation>マウントポイント（&amp;M）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="164"/>
        <source>Si&amp;ze:</source>
        <translation>サイズ（&amp;Z）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="174"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="95"/>
        <source>Logical</source>
        <translation>論理</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="100"/>
        <source>Primary</source>
        <translation>プライマリ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="117"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
</context>
<context>
    <name>CreatePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="47"/>
        <source>Create partition (file system: %1, size: %2 MB) on %3.</source>
        <translation>%3 にパーティション(ファイルシステム: %1, サイズ: %2 MB)を作成。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="60"/>
        <source>The installer failed to create partition on disk &apos;%1&apos;.</source>
        <translation>インストーラーはディスク &apos;%1&apos; にパーティションを作成することに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="69"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>デバイス &apos;%1&apos; を開けませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="79"/>
        <source>Could not open partition table.</source>
        <translation>パーティションテーブルを開くことができませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="103"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>インストラーは %1 パーティションにシステムを作成することに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="111"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>インストーラーはディスク &apos;%1&apos; 上のパーティションテーブルのアップデートに失敗しました。</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="20"/>
        <source>Create Partition Table</source>
        <translation>パーティションテーブルの作成</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="39"/>
        <source>Creating a new partition table will delete all existing data on the disk.</source>
        <translation>パーティションテーブルを作成することによって、ディスク上のデータが全て消去されます。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="65"/>
        <source>What kind of partition table do you want to create?</source>
        <translation>どの種類のパーティションテーブルを作成しますか?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="72"/>
        <source>Master Boot Record (MBR)</source>
        <translation>Master Boot Record (MBR)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="82"/>
        <source>GUID Partition Table (GPT)</source>
        <translation>GUID Partition Table (GPT)</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="48"/>
        <source>Create partition table</source>
        <translation>パーティションテーブルの生成</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="55"/>
        <source>The installer failed to create a partition table on %1.</source>
        <translation>インストーラーは%1 上でのパーティションテーブルの作成に失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="63"/>
        <source>Could not open device %1.</source>
        <translation>デバイス %1 を開けませんでした。</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="20"/>
        <source>Choose the type of partition table you want to create:</source>
        <translation>パーティションテーブルの種類を選択してください:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="29"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="39"/>
        <source>MS-Dos</source>
        <translation>MS-Dos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="66"/>
        <source>(icon)</source>
        <translation>(アイコン)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="79"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; This will destroy all data on the device!</source>
        <translation>&lt;b&gt;警告:&lt;/b&gt; デバイス上のすべてのデータが破壊されます!</translation>
    </message>
</context>
<context>
    <name>CreateUserJob</name>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="51"/>
        <source>Create user %1</source>
        <translation>ユーザー %1 を作成</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="67"/>
        <source>Sudoers dir is not writable.</source>
        <translation>Sudoersディレクトリに書き込みできません。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="71"/>
        <source>Cannot create sudoers file for writing.</source>
        <translation>sudoersファイルを作成できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="79"/>
        <source>Cannot chmod sudoers file.</source>
        <translation>sudoersファイルの権限を変更できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="85"/>
        <source>Cannot open groups file for reading.</source>
        <translation>groups ファイルを読み込めません。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="123"/>
        <source>Cannot create user %1.</source>
        <translation>ユーザー %1 を作成できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="125"/>
        <source>useradd terminated with error code %1.</source>
        <translation>エラーコード %1 によりuseraddを中止しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="130"/>
        <source>Cannot set full name for user %1.</source>
        <translation>ユーサー %1 のフルネームを設定できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="132"/>
        <source>chfn terminated with error code %1.</source>
        <translation>エラーコード %1 により chfn は中止しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="141"/>
        <source>Cannot set home directory ownership for user %1.</source>
        <translation>ユーザー %1 のホームディレクトリの所有者の設定ができません。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="143"/>
        <source>chown terminated with error code %1.</source>
        <translation>エラーコード %1 によりchown は中止しました。</translation>
    </message>
</context>
<context>
    <name>DecryptLuksDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="22"/>
        <source>&amp;Name:</source>
        <translation>名前（&amp;N）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="35"/>
        <source>&amp;Passphrase:</source>
        <translation>パスフレーズ（&amp;P）</translation>
    </message>
</context>
<context>
    <name>DeletePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="41"/>
        <source>Delete partition %1</source>
        <translation>パーティション %1 の削除</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="48"/>
        <source>The installer failed to delete partition %1.</source>
        <translation>インストーラーはパーティション %1 の削除に失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="54"/>
        <source>Partition (%1) and device (%2) do not match.</source>
        <translation>パーティション (%1) とデバイス (%2) が適合しません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="66"/>
        <source>Could not open device %1.</source>
        <translation>デバイス %1 を開けませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="75"/>
        <source>Could not open partition table.</source>
        <translation>パーティションテーブルを開くことができませんでした。</translation>
    </message>
</context>
<context>
    <name>DeviceModel</name>
    <message>
        <location filename="../src/modules/partition/core/DeviceModel.cpp" line="79"/>
        <source>%1 - %2 (%3)</source>
        <translation>%1 - %2 (%3)</translation>
    </message>
</context>
<context>
    <name>DevicePropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="58"/>
        <source>Partition table:</source>
        <translation>パーティションテーブル:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="77"/>
        <source>Cylinder alignment</source>
        <translation>シリンダーアライメント:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="84"/>
        <source>Sector based alignment</source>
        <translation>セクタベースのアライメント</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="113"/>
        <source>Capacity:</source>
        <translation>容量:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="130"/>
        <source>Total sectors:</source>
        <translation>トータルセクタ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="160"/>
        <source>Cylinders/Heads/Sectors:</source>
        <translation>シリンダ/ヘッド/セクタ :</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="183"/>
        <source>Logical sector size:</source>
        <translation>論理セクタサイズ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="200"/>
        <source>Physical sector size:</source>
        <translation>物理セクタサイズ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="217"/>
        <source>Cylinder size:</source>
        <translation>シリンダサイズ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="241"/>
        <source>Primaries/Max:</source>
        <translation>プライマリ/最大:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="265"/>
        <source>SMART status:</source>
        <translation>SMART status:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="303"/>
        <source>More...</source>
        <translation>More...</translation>
    </message>
</context>
<context>
    <name>EditExistingPartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="20"/>
        <source>Edit Existing Partition</source>
        <translation>既存のパーティションの編集</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="50"/>
        <source>Content:</source>
        <translation>内容:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="60"/>
        <source>Keep</source>
        <translation>保持</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="70"/>
        <source>Format</source>
        <translation>フォーマット</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="83"/>
        <source>Warning: Formatting the partition will erase all existing data.</source>
        <translation>警告: パーティションのフォーマットはすべてのデータを消去します。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="93"/>
        <source>&amp;Mount Point:</source>
        <translation>マウントポイント（&amp;M）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="113"/>
        <source>Size:</source>
        <translation>サイズ:</translation>
    </message>
</context>
<context>
    <name>EditMountOptionsDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="14"/>
        <source>Edit Mount Options</source>
        <translation>マウントオプションの編集</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="20"/>
        <source>Edit the mount options for this file system:</source>
        <translation>このファイルシステムに対するマウントオプションの編集</translation>
    </message>
</context>
<context>
    <name>EditMountPointDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="17"/>
        <source>Path:</source>
        <translation>パス:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="46"/>
        <source>Select...</source>
        <translation>選択:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="53"/>
        <source>Type:</source>
        <translation>タイプ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="63"/>
        <source>Options:</source>
        <translation>オプション;</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="73"/>
        <source>Read-only</source>
        <translation>読み込み専用</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="80"/>
        <source>Users can mount and unmount</source>
        <translation>マウント・アンマウントが可能</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="87"/>
        <source>No automatic mount</source>
        <translation>自動的にマウントしない</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="94"/>
        <source>No update of file access times</source>
        <translation>ファイルアクセス時刻を更新しない</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="101"/>
        <source>Synchronous access</source>
        <translation>同時にアクセス</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="108"/>
        <source>No update of directory access times</source>
        <translation>ディレクトリアクセス時刻を更新しない</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="115"/>
        <source>No binary execution</source>
        <translation>バイナリを実行しない</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="122"/>
        <source>Update access times relative to modification</source>
        <translation>修正があった時にアクセス時刻を更新</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="142"/>
        <source>More...</source>
        <translation>More...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="149"/>
        <source>Dump Frequency:</source>
        <translation>Dump Frequency:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="178"/>
        <source>Pass Number:</source>
        <translation>Pass Number:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="285"/>
        <source>Device Node</source>
        <translation>デバイスノード</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="295"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="302"/>
        <source>Label</source>
        <translation>ラベル</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="309"/>
        <source>Identify by:</source>
        <translation>確認:</translation>
    </message>
</context>
<context>
    <name>EraseDiskPage</name>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="53"/>
        <source>Select drive:</source>
        <translation>ドライブの選択:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="229"/>
        <source>Before:</source>
        <translation>前 :</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="234"/>
        <source>After:</source>
        <translation>後 :</translation>
    </message>
</context>
<context>
    <name>FileSystemSupportDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="17"/>
        <source>This table shows which file systems are supported and which specific operations can be performed on them.
Some file systems need external tools to be installed for them to be supported. But not all operations can be performed on all file systems, even if all required tools are installed. Please see the documentation for details. </source>
        <translation>このテーブルはどのファイルシステムがサポートされどの操作が可能か示しています。
いくつかのファイルシステムはインストールのために外部ツールを必要とします。しかし、すべてのツールをインストールしたとしても、すべてのファイルシステムですべての操作が可能になるわけではありません。詳細はドキュメントを参照してください。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="65"/>
        <source>File System</source>
        <translation>ファイルシステム</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="70"/>
        <source>Create</source>
        <translation>作成</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="75"/>
        <source>Grow</source>
        <translation>拡大</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="80"/>
        <source>Shrink</source>
        <translation>縮小</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="85"/>
        <source>Move</source>
        <translation>移動</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="90"/>
        <source>Copy</source>
        <translation>コピー</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="95"/>
        <source>Check</source>
        <translation>チェック</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="100"/>
        <source>Read Label</source>
        <translation>ラベルの読み込み</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="105"/>
        <source>Write Label</source>
        <translation>ラベルの書き込み</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="110"/>
        <source>Read Usage</source>
        <translation>Usageの読み込み</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="115"/>
        <source>Backup</source>
        <translation>バックアップ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="120"/>
        <source>Restore</source>
        <translation>復元</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="125"/>
        <source>Support Tools</source>
        <translation>サポートツール</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="135"/>
        <source>Rescan Support</source>
        <comment>@action:button</comment>
        <translation>サポートの再スキャン</translation>
    </message>
</context>
<context>
    <name>FillGlobalStorageJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="75"/>
        <source>Set partition information</source>
        <translation>パーティション情報の設定</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="85"/>
        <source>Failed to find path for boot loader</source>
        <translation>ブートローダーのパスを見つけられません</translation>
    </message>
</context>
<context>
    <name>FinishedPage</name>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="14"/>
        <source>Form</source>
        <translation>フォーム</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="77"/>
        <source>&amp;Restart now</source>
        <translation>今すぐ再起動（&amp;R）</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.cpp" line="50"/>
        <source>&lt;h1&gt;All done.&lt;/h1&gt;&lt;br/&gt;%1 has been installed on your computer.&lt;br/&gt;You may now restart into your new system, or continue using the %2 Live environment.</source>
        <translation>&lt;h1&gt;全て完了しました。&lt;/h1&gt;&lt;br/&gt;%1 はコンピュータにインストールされました。&lt;br/&gt;再起動して新しいシステムを立ち上げるか、%2 Live環境を使用し続けることができます。</translation>
    </message>
</context>
<context>
    <name>FinishedViewStep</name>
    <message>
        <location filename="../src/modules/finished/FinishedViewStep.cpp" line="43"/>
        <source>All done</source>
        <translation>全て完了</translation>
    </message>
</context>
<context>
    <name>FormatPartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="47"/>
        <source>Format partition %1 (file system: %2, size: %3 MB) on %4.</source>
        <translation>%4 上でパーティション %1 (ファイルシステム: %2, サイズ: %3 MB) のフォーマット</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="59"/>
        <source>The installer failed to format partition %1 on disk &apos;%2&apos;.</source>
        <translation>インストーラーはディスク &apos;%2&apos; 上のパーティション %1 のフォーマットに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="67"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>デバイス &apos;%1&apos; を開けませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="76"/>
        <source>Could not open partition table.</source>
        <translation>パーティションテーブルを開くことができませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="84"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>インストラーは %1 パーティションにシステムを作成することに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="92"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>インストーラーはディスク &apos;%1&apos; 上のパーティションテーブルのアップデートに失敗しました。</translation>
    </message>
</context>
<context>
    <name>GreetingPage</name>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="126"/>
        <source>&lt;h1&gt;Welcome to the %1 installer.&lt;/h1&gt;&lt;br/&gt;This program will ask you some questions and set up %2 on your computer.</source>
        <translation>&lt;h1&gt;%1 インストーラーにようこそ。&lt;/h1&gt;&lt;br/&gt;このプログラムはコンピュータに %2 をセットアップするために、いくつか質問をします。</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="144"/>
        <source>About %1 installer</source>
        <translation>%1 インストーラーについて</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="146"/>
        <source>&lt;h1&gt;%1&lt;/h1&gt;&lt;br/&gt;&lt;b&gt;%2&lt;br/&gt;for %3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;Copyright 2014 Teo Mrnjavac &amp;lt;teo@kde.org&amp;gt;&lt;br/&gt;Thanks to: Anke Boersma, Aurélien Gâteau, Kevin Kofler, Philip Müller, Pier Luigi Fiorini and Rohan Garg.&lt;br/&gt;&lt;br/&gt;&lt;a href=&quot;https://calamares.io/&quot;&gt;Calamares&lt;/a&gt; development is sponsored by &lt;br/&gt;&lt;a href=&quot;http://www.blue-systems.com/&quot;&gt;Blue Systems&lt;/a&gt; - technologies for a better world.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="176"/>
        <source>%1 support</source>
        <translation>%1 サポート</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="14"/>
        <source>Form</source>
        <translation>フォーム</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="104"/>
        <source>&amp;Release notes</source>
        <translation>リリースノート（&amp;R）</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="114"/>
        <source>&amp;Known issues</source>
        <translation>既知の問題（&amp;K）</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="124"/>
        <source>&amp;Support</source>
        <translation>サポート（&amp;S）</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="134"/>
        <source>&amp;About</source>
        <translation>説明（&amp;A）</translation>
    </message>
</context>
<context>
    <name>GreetingViewStep</name>
    <message>
        <location filename="../src/modules/greeting/GreetingViewStep.cpp" line="43"/>
        <source>Welcome</source>
        <translation>ようこそ</translation>
    </message>
</context>
<context>
    <name>KeyboardPage</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="200"/>
        <source>Set keyboard model to %1.&lt;br/&gt;</source>
        <translation>キーボードのモデルを %1 に設定。&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="202"/>
        <source>Set keyboard layout to %1/%2.</source>
        <translation>キーボードのレイアウトを %1/%2 に設定。</translation>
    </message>
</context>
<context>
    <name>KeyboardViewStep</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardViewStep.cpp" line="48"/>
        <source>Keyboard</source>
        <translation>キーボード</translation>
    </message>
</context>
<context>
    <name>LCLocaleDialog</name>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="33"/>
        <source>System locale setting</source>
        <translation>システムのロケールの設定</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="40"/>
        <source>The system locale setting affects the language and character set for some command line user interface elements.&lt;br/&gt;The current setting is &lt;b&gt;%1&lt;/b&gt;.</source>
        <translation>システムロケールの設定はコマンドラインやインターフェース上での言語や文字の表示に影響をおよぼします。&lt;br/&gt;現在の設定 &lt;b&gt;%1&lt;/b&gt;.</translation>
    </message>
</context>
<context>
    <name>LocalePage</name>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="159"/>
        <location filename="../src/modules/locale/LocalePage.cpp" line="170"/>
        <source>The system locale is set to %1.</source>
        <translation>システムロケールが %1 に設定されました。</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="167"/>
        <source>Region:</source>
        <translation>地域:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="168"/>
        <source>Zone:</source>
        <translation>ゾーン:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="173"/>
        <source>&amp;Change...</source>
        <translation>変更（&amp;C）...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="267"/>
        <source>Set timezone to %1/%2.&lt;br/&gt;</source>
        <translation>タイムゾーンを  %1/%2 に設定。&lt;br/&gt;</translation>
    </message>
</context>
<context>
    <name>LocaleViewStep</name>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="45"/>
        <source>Loading location data...</source>
        <translation>ロケーションデータのローディング...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="79"/>
        <source>Location</source>
        <translation>ロケーション</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>KDEパーティションマネージャー</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="24"/>
        <source>Devices</source>
        <comment>@title:window</comment>
        <translation>デバイス</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="38"/>
        <source>Pending Operations</source>
        <comment>@title:window</comment>
        <translation>操作のペンディング</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="49"/>
        <source>Information</source>
        <comment>@title:window</comment>
        <translation>情報</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="63"/>
        <source>Log Output</source>
        <comment>@title:window</comment>
        <translation>ログの出力</translation>
    </message>
</context>
<context>
    <name>MoveFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="66"/>
        <source>Move file system of partition %1.</source>
        <translation>パーティション %1 のファイルシステムの移動</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="80"/>
        <source>Could not open file system on partition %1 for moving.</source>
        <translation>パーティション %1 のファイルシステムを開けませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="86"/>
        <source>Could not create target for moving file system on partition %1.</source>
        <translation>パーテション %1 のファイルシステム移動のためのターゲットを作成できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="95"/>
        <source>Moving of partition %1 failed, changes have been rolled back.</source>
        <translation>パーティション %1 の移動に失敗しました。変更はロールバックされます。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="101"/>
        <source>Moving of partition %1 failed. Roll back of the changes have failed.</source>
        <translation>パーティション %1 の移動に失敗しました。変更からのロールバックに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="113"/>
        <source>Updating boot sector after the moving of partition %1 failed.</source>
        <translation>パーティション %1 の移動に失敗した後、ブートセクタを更新しています。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="127"/>
        <source>The logical sector sizes in the source and target for copying are not the same. This is currently unsupported.</source>
        <translation>ソースとターゲットの論理セクタサイズが同じではありません。これは現在サポートされていません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="200"/>
        <source>Source and target for copying do not overlap: Rollback is not required.</source>
        <translation>ソースとコピー用のターゲットは領域が重なりません: ロールバックは必要ではありません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="224"/>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="232"/>
        <source>Could not open device %1 to rollback copying.</source>
        <translation>ロールバック用のデバイス %1 を開けませんでした。</translation>
    </message>
</context>
<context>
    <name>Page_Keyboard</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="14"/>
        <source>Form</source>
        <translation>フォーム</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="70"/>
        <source>Keyboard Model:</source>
        <translation>キーボードモデル:</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>ここでタイプしてキーボードをテストしてください</translation>
    </message>
</context>
<context>
    <name>Page_UserSetup</name>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="14"/>
        <source>Form</source>
        <translation>フォーム</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="33"/>
        <source>What is your name?</source>
        <translation>名前は何ですか?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="111"/>
        <source>What name do you want to use to log in?</source>
        <translation>ログインの際、どの名前を使用しますか?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="191"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="319"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="425"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="553"/>
        <source>font-weight: normal</source>
        <translation>フォントウェイト: normal</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="194"/>
        <source>&lt;small&gt;If more than one person will use this computer, you can set up multiple accounts after installation.&lt;/small&gt;</source>
        <translation>&lt;small&gt;もし複数の人間がこのコンピュータを使用する場合、インストールの後で複数のアカウントのセットアップを行うことができます。&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="217"/>
        <source>Choose a password to keep your account safe.</source>
        <translation>アカウントを安全に使うため、パスワードを選択してください</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="322"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors. A good password will contain a mixture of letters, numbers and punctuation, should be at least eight characters long, and should be changed at regular intervals.&lt;/small&gt;</source>
        <translation>確認のため、同じパスワードを二回入力して下さい。最低8字で、文字・数値・句読点を含めれば、強いパスワードになります。また、パスワードを定期的に変更したほうがお勧めです。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="345"/>
        <source>What is the name of this computer?</source>
        <translation>このコンピュータの名前は何ですか？</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="428"/>
        <source>&lt;small&gt;This name will be used if you make the computer visible to others on a network.&lt;/small&gt;</source>
        <translation>ネットワーク上、他人に当パソコンが見えるように設定されたら、この名前を使われます。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="451"/>
        <source>Choose a password for the administrator account.</source>
        <translation>管理者アカウントにパスワードを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="556"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors.&lt;/small&gt;</source>
        <translation>入力ミス防止のため、同じパスワードを二回入力して下さい。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="596"/>
        <source>Log in automatically</source>
        <translation>自動的にログインする</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="606"/>
        <source>Require my password to log in</source>
        <translation>ログインする時にパスワードを要求する</translation>
    </message>
</context>
<context>
    <name>PartPropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="49"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>ファイルシステム:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="65"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>ラベル:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="82"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>このファイルシステムには、ラベル設定できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="92"/>
        <source>Recreate existing file system</source>
        <comment>@action:button</comment>
        <translation>既存のファイルシステムを再現する</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="106"/>
        <source>Mount point:</source>
        <comment>@label</comment>
        <translation>マウントポイント:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="123"/>
        <source>Partition type:</source>
        <comment>@label</comment>
        <translation>パーティションタイプ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="140"/>
        <source>Status:</source>
        <comment>@label</comment>
        <translation>状態:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="157"/>
        <source>UUID:</source>
        <comment>@label</comment>
        <translation>UUID:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="187"/>
        <source>Size:</source>
        <comment>@label</comment>
        <translation>サイズ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="210"/>
        <source>Available:</source>
        <comment>@label partition capacity available</comment>
        <translation>使用可能:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="227"/>
        <source>Used:</source>
        <comment>@label partition capacity used</comment>
        <translation>使用済み:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="251"/>
        <source>First sector:</source>
        <comment>@label</comment>
        <translation>最初セクタ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="268"/>
        <source>Last sector:</source>
        <comment>@label</comment>
        <translation>最後セクタ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="285"/>
        <source>Number of sectors:</source>
        <comment>@label</comment>
        <translation>セクタ数:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="309"/>
        <source>Flags:</source>
        <comment>@label</comment>
        <translation>フラグ:</translation>
    </message>
</context>
<context>
    <name>PartitionManagerWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>KDEパーティションマネージャー</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="70"/>
        <source>Partition</source>
        <translation>パーティション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="75"/>
        <source>Type</source>
        <translation>タイプ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="80"/>
        <source>Mount Point</source>
        <translation>マウントポイント</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="85"/>
        <source>Label</source>
        <translation>ラベル</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="90"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="95"/>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="100"/>
        <source>Used</source>
        <translation>使用済み</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="105"/>
        <source>Available</source>
        <translation>使用可能</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="110"/>
        <source>First Sector</source>
        <translation>最初セクタ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="115"/>
        <source>Last Sector</source>
        <translation>最後セクタ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="120"/>
        <source>Number of Sectors</source>
        <translation>セクタ数</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="125"/>
        <source>Flags</source>
        <translation>フラグ</translation>
    </message>
</context>
<context>
    <name>PartitionModel</name>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="132"/>
        <source>Free Space</source>
        <translation>空き領域</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="136"/>
        <source>New partition</source>
        <translation>新しいパーティション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="175"/>
        <source>Name</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="177"/>
        <source>File System</source>
        <translation>ファイルシステム</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="179"/>
        <source>Mount Point</source>
        <translation>マウントポイント</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="181"/>
        <source>Size</source>
        <translation>サイズ</translation>
    </message>
</context>
<context>
    <name>PartitionPage</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="14"/>
        <source>Form</source>
        <translation>フォーム</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>ディスク（&amp;D）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="51"/>
        <source>&amp;Revert All Changes</source>
        <translation>全ての変更を元に戻す（&amp;R）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="84"/>
        <source>New Partition &amp;Table</source>
        <translation>新しいパーティションテーブル（&amp;T）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="104"/>
        <source>&amp;Create</source>
        <translation>作成（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="111"/>
        <source>&amp;Edit</source>
        <translation>編集（&amp;E）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="118"/>
        <source>&amp;Delete</source>
        <translation>削除（&amp;D）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="145"/>
        <source>&amp;Install boot loader on:</source>
        <translation>ブートローダをインストールするデバイス（&amp;I）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.cpp" line="135"/>
        <source>Are you sure you want to create a new partition table on %1?</source>
        <translation>％1 上で新しいパーティションテーブルを作成します。よろしいですか？</translation>
    </message>
</context>
<context>
    <name>PartitionViewStep</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="66"/>
        <source>Gathering system information...</source>
        <translation>システム情報を取得中...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="160"/>
        <source>Partitions</source>
        <translation>パーティション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="188"/>
        <source>Before:</source>
        <translation>前:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="193"/>
        <source>After:</source>
        <translation>後:</translation>
    </message>
</context>
<context>
    <name>PreparePage</name>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="39"/>
        <source>For best results, please ensure that this computer:</source>
        <translation>良好な結果を得るために、このコンピュータについて以下の項目を確認して下さい：</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="96"/>
        <source>This computer does not satisfy the minimum requirements for installing %1.
Installation cannot continue.</source>
        <translation>このコンピュータは、 %1 をインストールするための最低要件を満たしていません。
インストールが続行できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="109"/>
        <source>This computer does not satisfy some of the recommended requirements for installing %1.
Installation can continue, but some features might be disabled.</source>
        <translation>このコンピュータは、 %1 をインストールするための推奨条件をいくつか満たしていません。
インストールは続行しますが、一部の機能が無効になる場合があります。</translation>
    </message>
</context>
<context>
    <name>PrepareViewStep</name>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="54"/>
        <source>Gathering system information...</source>
        <translation>システム情報を取得中...</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="91"/>
        <source>has at least %1 GB available drive space</source>
        <translation>最低 %1 GBのディスク空き領域があること</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="99"/>
        <source>has at least %1 GB working memory</source>
        <translation>最低 %1 GBのワーキングメモリーがあること</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="107"/>
        <source>is plugged in to a power source</source>
        <translation>電源が接続されていること</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="114"/>
        <source>is connected to the Internet</source>
        <translation>インターネットに接続されていること</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="158"/>
        <source>Prepare</source>
        <translation>準備</translation>
    </message>
</context>
<context>
    <name>ProgressTreeModel</name>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="138"/>
        <source>Prepare</source>
        <translation>準備</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="151"/>
        <source>Install</source>
        <translation>インストール</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="161"/>
        <source>Finish</source>
        <translation>完了</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="82"/>
        <source>Default Keyboard Model</source>
        <translation>デフォルトのキーボードモデル</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="127"/>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="163"/>
        <source>Default</source>
        <translation>デフォルト</translation>
    </message>
</context>
<context>
    <name>ReleaseDialog</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="20"/>
        <source>KDE Release Builder</source>
        <translation>KDEリリースビルダー</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="32"/>
        <source>Application</source>
        <translation>アプリケーション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="38"/>
        <source>Name:</source>
        <translation>名前</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="48"/>
        <source>&amp;Version:</source>
        <translation>バージョン（&amp;V）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="93"/>
        <source>Repository and Revision</source>
        <translation>リポジトリ及びリビジョン</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="99"/>
        <source>&amp;Checkout From:</source>
        <translation>チェックアウト（&amp;C）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="119"/>
        <source>trunk</source>
        <translation>トランク</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="124"/>
        <source>branches</source>
        <translation>ブランチ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="129"/>
        <source>tags</source>
        <translation>タグ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="137"/>
        <source>Ta&amp;g/Branch:</source>
        <translation>タグ/ブランチ（&amp;G）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="163"/>
        <source>&amp;SVN Access:</source>
        <translation>SVNアクセス（&amp;S）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="183"/>
        <source>anonsvn</source>
        <translation>anonsvn</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="188"/>
        <source>https</source>
        <translation>https</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="193"/>
        <source>svn+ssh</source>
        <translation>svn+ssh</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="201"/>
        <source>&amp;User:</source>
        <translation>ユーザ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="236"/>
        <source>Options</source>
        <translation>オプション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="242"/>
        <source>Get &amp;Documentation</source>
        <translation>ドキュメントの入手（&amp;D）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="252"/>
        <source>Get &amp;Translations</source>
        <translation>翻訳の入手（&amp;T）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="262"/>
        <source>C&amp;reate Tag</source>
        <translation>タグを作成（&amp;C）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="271"/>
        <source>S&amp;kip translations below completion:</source>
        <translation>終了まで翻訳をスキップ（&amp;K）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="306"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="324"/>
        <source>Create Tar&amp;ball</source>
        <translation>Tarballの作成（&amp;B）</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="334"/>
        <source>Apply &amp;fixes</source>
        <translation>適用及び修復（&amp;F）</translation>
    </message>
</context>
<context>
    <name>ReplacePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="14"/>
        <source>Form</source>
        <translation>フォーム</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>ディスク（&amp;D）:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="109"/>
        <source>Select where to install %1.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;this will delete all files on the selected partition.</source>
        <translation>%1 をインストールする場所を選択してください。&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;警告: &lt;/font&gt;この操作は選択したパーティションのファイルを全て削除します。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="136"/>
        <source>The selected item does not appear to be a valid partition.</source>
        <translation>選択した項目は適切なパーティション上に存在しません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="144"/>
        <source>%1 cannot be installed on empty space. Please select an existing partition.</source>
        <translation>%1 は空き容量にインストールできません。他のパーティションを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="155"/>
        <source>%1 cannot be installed on an extended partition. Please select an existing primary or logical partition.</source>
        <translation>%1 は拡張パーティションにインストールできません。プライマリまたは論理パーティションを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="166"/>
        <source>%1 cannot be installed on this partition.</source>
        <translation>%1 はこのパーティションにインストールできません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="173"/>
        <source>Data partition (%1)</source>
        <translation>データパーティション (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="190"/>
        <source>Unknown system partition (%1)</source>
        <translation>未知のシステムパーティション (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="195"/>
        <source>%1 system partition (%2)</source>
        <translation>%1 システムパーティション (%2)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="206"/>
        <source>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;The partition %1 is too small for %2. Please select a partition with capacity at least %3 GiB.</source>
        <translation>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;パーティション %1 は %2 に対して容量が小さいです. 少なくとも %3 GiB 以上のパーティションを選択してください。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="220"/>
        <source>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 will be installed on %2.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;all data on partition%2 will be lost.</source>
        <translation>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 は %2 にインストールされます。&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;警告: &lt;/font&gt;パーティション %2 上の全てのデータが失われます。</translation>
    </message>
</context>
<context>
    <name>ResizeFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="75"/>
        <source>Resize file system on partition %1.</source>
        <translation>パーティション %1 でのファイルシステムのリサイズ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="90"/>
        <source>Parted failed to resize filesystem.</source>
        <translation>Partedは、ファイルシステムのリサイズに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="100"/>
        <source>Failed to resize filesystem.</source>
        <translation>ファイルシステムリサイズに失敗しました。</translation>
    </message>
</context>
<context>
    <name>ResizePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="186"/>
        <source>Resize partition %1.</source>
        <translation>パーティション %1 をリサイズする</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="208"/>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="266"/>
        <source>The installer failed to resize partition %1 on disk &apos;%2&apos;.</source>
        <translation>インストーラが、ディスク &apos;%2&apos; でのパーティション %1 のリサイズに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="213"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>デバイス &apos;%1&apos; を開けませんでした。</translation>
    </message>
</context>
<context>
    <name>SetHostNameJob</name>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="36"/>
        <source>Set hostname %1</source>
        <translation>ホスト名 %1 の設定</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="46"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="53"/>
        <source>Internal Error</source>
        <translation>内部エラー</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="60"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="71"/>
        <source>Cannot write hostname to target system</source>
        <translation>ターゲットとするシステムにホスト名を書き込めません</translation>
    </message>
</context>
<context>
    <name>SetKeyboardLayoutJob</name>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="57"/>
        <source>Set keyboard model to %1, layout to %2-%3</source>
        <translation>キーボードのモデルを %1 に、レイアウトを %2-%3に設定</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="284"/>
        <source>Failed to write keyboard configuration for the virtual console.</source>
        <translation>仮想コンソールでのキーボード設定の書き込みに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="285"/>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="289"/>
        <source>Failed to write to %1</source>
        <translation>%1 への書き込みに失敗しました</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="288"/>
        <source>Failed to write keyboard configuration for X11.</source>
        <translation>X11のためのキーボード設定の書き込みに失敗しました。</translation>
    </message>
</context>
<context>
    <name>SetPartGeometryJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="143"/>
        <source>Update geometry of partition %1.</source>
        <translation>パーティション %1 のジオメトリーの更新</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="155"/>
        <source>Failed to change the geometry of the partition.</source>
        <translation>パーティションのジオメトリーの変更に失敗しました。</translation>
    </message>
</context>
<context>
    <name>SetPasswordJob</name>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="42"/>
        <source>Set password for user %1</source>
        <translation>ユーザ %1 のパスワード設定</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="52"/>
        <source>Bad destination system path.</source>
        <translation>不正なシステムパス。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="53"/>
        <source>rootMountPoint is %1</source>
        <translation>root のマウントポイントは %1 。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="62"/>
        <source>Cannot set password for user %1.</source>
        <translation>ユーザ %1 のパスワードは設定できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="64"/>
        <source>usermod terminated with error code %1.</source>
        <translation>エラーコード %1 によりusermodが停止しました。</translation>
    </message>
</context>
<context>
    <name>SetTimezoneJob</name>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="41"/>
        <source>Set timezone to %1/%2</source>
        <translation>タイムゾーンを %1/%2 に設定</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="56"/>
        <source>Cannot access selected timezone path.</source>
        <translation>選択したタイムゾーンのパスにアクセスできません。</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="57"/>
        <source>Bad path: %1</source>
        <translation>不正なパス: %1</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="69"/>
        <source>Cannot set timezone.</source>
        <translation>タイムゾーンを設定できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="70"/>
        <source>Link creation failed, target: %1; link name: %2</source>
        <translation>リンクの作成に失敗しました、ターゲット: %1 ; リンク名: %2</translation>
    </message>
</context>
<context>
    <name>SizeDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="62"/>
        <source>First sector:</source>
        <comment>@label:listbox</comment>
        <translation>最初セクタ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="97"/>
        <source>Last sector:</source>
        <comment>@label:listbox</comment>
        <translation>最後セクタ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="120"/>
        <source>Align partition</source>
        <translation>パーティション位置合わせ</translation>
    </message>
</context>
<context>
    <name>SizeDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="55"/>
        <source>Partition type:</source>
        <comment>@label:listbox</comment>
        <translation>パーティションタイプ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="70"/>
        <source>Primary</source>
        <translation>基本パーティション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="77"/>
        <source>Extended</source>
        <translation>拡張パーティション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="84"/>
        <source>Logical</source>
        <translation>論理パーティション</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="99"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>ファイルシステム</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="115"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>ラベル</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="134"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>このファイルシステムには、ラベルを設定できません。</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="152"/>
        <source>Minimum size:</source>
        <comment>@label</comment>
        <translation>最小サイズ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="175"/>
        <source>Maximum size:</source>
        <comment>@label</comment>
        <translation>最大サイズ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="198"/>
        <source>Free space before:</source>
        <comment>@label:listbox</comment>
        <translation>以前の空き領域:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="233"/>
        <source>Size:</source>
        <comment>@label:listbox</comment>
        <translation>サイズ:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="262"/>
        <source>Free space after:</source>
        <comment>@label:listbox</comment>
        <translation>操作後の空き領域:</translation>
    </message>
</context>
<context>
    <name>SmartDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="23"/>
        <source>SMART status:</source>
        <translation>SMART状態:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="63"/>
        <source>Model:</source>
        <translation>モデル</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="92"/>
        <source>Serial number:</source>
        <translation>シリアル番号</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="121"/>
        <source>Firmware revision:</source>
        <translation>ファームウェアのリビジョン:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="150"/>
        <source>Temperature:</source>
        <translation>温度</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="179"/>
        <source>Bad sectors:</source>
        <translation>不正なセクタ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="208"/>
        <source>Powered on for:</source>
        <translation>Powered on for:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="237"/>
        <source>Power cycles:</source>
        <translation>Power cycles:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="289"/>
        <source>Id</source>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="294"/>
        <source>Attribute</source>
        <translation>Attribute</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="299"/>
        <source>Failure Type</source>
        <translation>Failure Type</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="304"/>
        <source>Update Type</source>
        <translation>アップデートタイプ</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="309"/>
        <source>Worst</source>
        <translation>Worst</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="314"/>
        <source>Current</source>
        <translation>Current</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="319"/>
        <source>Threshold</source>
        <translation>Threshold</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="324"/>
        <source>Raw</source>
        <translation>Raw</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="329"/>
        <source>Assessment</source>
        <translation>評価</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="334"/>
        <source>Value</source>
        <translation>値</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="385"/>
        <source>Overall assessment:</source>
        <translation>総合的な評価:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="414"/>
        <source>Self tests:</source>
        <translation>セルフテスト:</translation>
    </message>
</context>
<context>
    <name>SummaryViewStep</name>
    <message>
        <location filename="../src/modules/summary/SummaryViewStep.cpp" line="41"/>
        <source>Summary</source>
        <translation>要約</translation>
    </message>
</context>
<context>
    <name>TreeLogBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="54"/>
        <source>Sev.</source>
        <comment>@title:column Severity of a log entry / log level. Text must be very short.</comment>
        <translation>Sev.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="57"/>
        <source>Severity</source>
        <translation>重要度</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="62"/>
        <source>Time</source>
        <comment>@title:column a time stamp of a log entry</comment>
        <translation>時間</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="67"/>
        <source>Message</source>
        <comment>@title:column the text message of a log entry</comment>
        <translation>メッセージ</translation>
    </message>
</context>
<context>
    <name>UsersPage</name>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="233"/>
        <source>Your username is too long.</source>
        <translation>ユーザー名が長すぎます。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="243"/>
        <source>Your username contains invalid characters. Only lowercase letters and numbers are allowed.</source>
        <translation>ユーザー名に不適切な文字が含まれています。アルファベットの小文字と数字のみが使用できます。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="287"/>
        <source>Your hostname is too short.</source>
        <translation>ホスト名が短すぎます。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="298"/>
        <source>Your hostname is too long.</source>
        <translation>ホスト名が長過ぎます。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="309"/>
        <source>Your hostname contains invalid characters. Only letters, numbers and dashes are allowed.</source>
        <translation>ホスト名に不適切な文字が含まれています。アルファベット、数字及びハイフンのみが使用できます。</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="340"/>
        <location filename="../src/modules/users/UsersPage.cpp" line="373"/>
        <source>Your passwords do not match!</source>
        <translation>パスワードが一致していません！</translation>
    </message>
</context>
<context>
    <name>UsersViewStep</name>
    <message>
        <location filename="../src/modules/users/UsersViewStep.cpp" line="46"/>
        <source>Users</source>
        <translation>ユーザー情報</translation>
    </message>
</context>
</TS>