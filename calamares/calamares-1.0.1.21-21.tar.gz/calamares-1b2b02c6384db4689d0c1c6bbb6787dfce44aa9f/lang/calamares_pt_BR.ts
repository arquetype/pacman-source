<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.1">
<context>
    <name>AlongsidePage</name>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="67"/>
        <source>Choose partition to shrink:</source>
        <translation>Escolha a partição a ser encolhida:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="68"/>
        <source>Allocate drive space by dragging the divider below:</source>
        <translation>Aloque espaço no disco deslizando o divisor abaixo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/AlongsidePage.cpp" line="167"/>
        <source>With this operation, the partition &lt;b&gt;%1&lt;/b&gt; which contains %4 will be shrunk to %2MB and a new %3MB partition will be created for %5.</source>
        <translation>Com esta operação, a partição &lt;b&gt;%1&lt;/b&gt; que contém %4 será encolhida para %2MB e uma nova partição de %3MB será criada para %5.</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="37"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdetailswidgetbase.ui" line="44"/>
        <source>Open in External Browser</source>
        <translation>Abrir em um Navegador externo</translation>
    </message>
</context>
<context>
    <name>ApplyProgressDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="33"/>
        <source>Operations and Jobs</source>
        <translation>Operações e Tarefas</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="38"/>
        <source>Time Elapsed</source>
        <translation>Tempo transcorrido</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="64"/>
        <source>Total Time: 00:00:00</source>
        <translation>Tempo Total: 00:00:00</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="81"/>
        <source>Operation: %p%</source>
        <translation>Operação: %p%</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="91"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/applyprogressdialogwidgetbase.ui" line="107"/>
        <source>Total: %p%</source>
        <translation>Total: %p%</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="20"/>
        <source>Installer</source>
        <translation>Instalador</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="168"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Welcome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Bem- vindo&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="198"/>
        <source>Location</source>
        <translation>Localidade</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="224"/>
        <source>License Approval</source>
        <translation>Aprovação de licença</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="257"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Installation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Instalação&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="287"/>
        <source>Install System</source>
        <translation>Sistema de Instalação</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="320"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Configuration&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Configuração&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="331"/>
        <source>Reboot</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="410"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="443"/>
        <source>User Info</source>
        <translation>Informações do Usuário</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="469"/>
        <source>Summary</source>
        <translation>Sumário</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="514"/>
        <source>Keyboard</source>
        <translation>Teclado</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="521"/>
        <source>Disk Setup</source>
        <translation>Configuração de Disco</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.ui" line="528"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Preparation&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600; color:#343434;&quot;&gt;Preparação&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>BootLoaderModel</name>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="57"/>
        <source>Master Boot Record of %1</source>
        <translation>Master Boot Record de %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="71"/>
        <source>Boot Partition</source>
        <translation>Partição de Boot</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/BootLoaderModel.cpp" line="76"/>
        <source>System Partition</source>
        <translation>Partição de Sistema</translation>
    </message>
</context>
<context>
    <name>Calamares::DebugWindow</name>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="24"/>
        <source>GlobalStorage</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="34"/>
        <source>JobQueue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.ui" line="44"/>
        <source>Modules</source>
        <translation>Módulos</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/utils/DebugWindow.cpp" line="95"/>
        <source>Debug information</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Calamares::InstallationViewStep</name>
    <message>
        <location filename="../src/libcalamaresui/InstallationViewStep.cpp" line="75"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
</context>
<context>
    <name>Calamares::JobThread</name>
    <message>
        <location filename="../src/libcalamares/JobQueue.cpp" line="88"/>
        <source>Done</source>
        <translation>Concluído</translation>
    </message>
</context>
<context>
    <name>Calamares::ProcessJob</name>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="51"/>
        <source>Run command %1 %2</source>
        <translation>Executar comando %1 %2</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="79"/>
        <source>External command crashed</source>
        <translation>Comando externo falhou</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="80"/>
        <source>Command %1 crashed.
Output:
%2</source>
        <translation>Comando %1 falhou
Saída:
%2</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="85"/>
        <source>External command failed to start</source>
        <translation>Comando externo falhou ao inciar</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="86"/>
        <source>Command %1 failed to start.</source>
        <translation>Comando %1 falhou ao iniciar.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="90"/>
        <source>Internal error when starting command</source>
        <translation>Erro interno ao iniciar comando</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="91"/>
        <source>Bad parameters for process job call.</source>
        <translation>Parâmetros ruins para a chamada da tarefa do processo.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="94"/>
        <source>External command failed to finish</source>
        <translation>Comando externo falhou ao finalizar</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="95"/>
        <source>Command %1 failed to finish in %2s.
Output:
%3</source>
        <translation>Comando %1 falhou ao finalizar em %2.
Saída:
%3</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="101"/>
        <source>External command finished with errors</source>
        <translation>Comando externo terminou com erros</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/ProcessJob.cpp" line="102"/>
        <source>Command %1 finished with exit code %2.
Output:
%3</source>
        <translation>Comando %1 finalizou com o código de saída %2.
Saída:
%3</translation>
    </message>
</context>
<context>
    <name>Calamares::PythonJob</name>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="234"/>
        <source>Run script %1</source>
        <translation>Executar script %1</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="249"/>
        <source>Bad working directory path</source>
        <translation>Caminho de diretório de trabalho ruim</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="250"/>
        <source>Working directory %1 for python job %2 is not readable.</source>
        <translation>Diretório de trabalho %1 para a tarefa do python %2 não é legível.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="260"/>
        <source>Bad main script file</source>
        <translation>Arquivo de script principal ruim</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="261"/>
        <source>Main script file %1 for python job %2 is not readable.</source>
        <translation>Arquivo de script principal %1 para a tarefa do python %2 não é legível.</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonJob.cpp" line="306"/>
        <source>Boost.Python error in job &quot;%1&quot;.</source>
        <translation>Boost.Python erro na tarefa &quot;%1&quot;.</translation>
    </message>
</context>
<context>
    <name>Calamares::ViewManager</name>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="64"/>
        <source>&amp;Back</source>
        <translation>&amp;Voltar</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="65"/>
        <source>&amp;Next</source>
        <translation>&amp;Próximo</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="66"/>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="302"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Cancelar</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="86"/>
        <source>Cancel installation?</source>
        <translation>Cancelar a instalação?</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="87"/>
        <source>Do you really want to cancel the current install process?
The installer will quit and all changes will be lost.</source>
        <translation>Você deseja realmente cancelar a instalação atual?
O instalador será fechado e todas as alterações serão perdidas.</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="272"/>
        <source>&amp;Quit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="183"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/libcalamaresui/ViewManager.cpp" line="184"/>
        <source>Installation Failed</source>
        <translation>Falha na Instalação</translation>
    </message>
</context>
<context>
    <name>CalamaresPython::Helper</name>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="234"/>
        <source>Unknown exception type</source>
        <translation>Tipo de exceção desconhecida</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="247"/>
        <source>unparseable Python error</source>
        <translation>erro inanalisável do Python</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="263"/>
        <source>unparseable Python traceback</source>
        <translation>rastreamento inanalisável do Python</translation>
    </message>
    <message>
        <location filename="../src/libcalamares/PythonHelper.cpp" line="267"/>
        <source>Unfetchable Python error.</source>
        <translation>Erro inbuscável do Python.</translation>
    </message>
</context>
<context>
    <name>CalamaresWindow</name>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="44"/>
        <source>%1 Installer</source>
        <translation>Instalador %1</translation>
    </message>
    <message>
        <location filename="../src/calamares/CalamaresWindow.cpp" line="98"/>
        <source>Show debug information</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CheckFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="34"/>
        <source>Checking file system on partition %1.</source>
        <translation>Verificando sistema de arquivos na partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CheckFileSystemJob.cpp" line="50"/>
        <source>The file system check on partition %1 failed.</source>
        <translation>A verificação do sistema de arquivo na partição %1 falhou.</translation>
    </message>
</context>
<context>
    <name>ChoicePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="115"/>
        <source>This computer currently does not seem to have an operating system on it. What would you like to do?</source>
        <translation>O computador aparenta não ter algum sistema operacional instalado. O que você deseja fazer?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="119"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="187"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="234"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will delete all of your programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;Apagar o disco e instalar %1&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Atenção: &lt;/font&gt;Isto irá deletar todos os seus programas, documentos, fotos, músicas e quaisquer outros arquivos.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="125"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="162"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="193"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="240"/>
        <source>&lt;b&gt;Erase disk and install %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which disk to erase.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="141"/>
        <source>This computer currently has %1 on it. What would you like to do?</source>
        <translation>O computador atualmente tem %1. O que você deseja fazer?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="145"/>
        <source>&lt;b&gt;Install %2 alongside %1&lt;/b&gt;&lt;br/&gt;The installer will shrink the %1 volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="167"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="198"/>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="245"/>
        <source>&lt;b&gt;Replace a partition with %1&lt;/b&gt;&lt;br/&gt;You will be offered a choice of which partition to erase.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="179"/>
        <source>&lt;b&gt;Install %1 alongside your current operating system&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="226"/>
        <source>&lt;b&gt;Install %1 alongside your current operating systems&lt;/b&gt;&lt;br/&gt;The installer will shrink an existing volume to make room for %2. You can choose which operating system you want each time the computer starts up.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="261"/>
        <source>&lt;b&gt;Manual partitioning&lt;/b&gt;&lt;br/&gt;You can create or resize partitions yourself, or choose multiple partitions for %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="154"/>
        <source>&lt;b&gt;Erase entire disk with %1 and install %2&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;This will erase the whole disk and delete all of your %1 programs, documents, photos, music, and any other files.</source>
        <translation>&lt;b&gt;Apagar disco inteiro com %1 e instalar %2&lt;/b&gt;&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Aviso: &lt;/font&gt;Isso irá apagar todo o disco e deletar todos os seus %1 programas, documentos, fotos, músicas e outros arquivos.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="176"/>
        <source>This computer already has an operating system on it. What would you like to do?</source>
        <translation>O computador já tem um sistema operacional instalado. O que você deseja fazer?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ChoicePage.cpp" line="223"/>
        <source>This computer currently has multiple operating systems on it. What would you like to do?</source>
        <translation>Este computador possui mais de um sistema operacional. O que gostaria de fazer?</translation>
    </message>
</context>
<context>
    <name>ClearMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="42"/>
        <source>Clear mounts for partitioning operations on %1</source>
        <translation>Limpar as montagens para as operações nas partições em %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearMountsJob.cpp" line="81"/>
        <source>Cleared all mounts for %1</source>
        <translation>Todos os pontos de montagem para %1 foram limpos</translation>
    </message>
</context>
<context>
    <name>ClearTempMountsJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="38"/>
        <source>Clear all temporary mounts.</source>
        <translation>Limpar pontos de montagens temporários.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="49"/>
        <source>Cannot get list of temporary mounts.</source>
        <translation>Não foi possível listar os pontos de montagens.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ClearTempMountsJob.cpp" line="88"/>
        <source>Cleared all temporary mounts.</source>
        <translation>Pontos de montagens temporários limpos.</translation>
    </message>
</context>
<context>
    <name>ConfigurePageAdvanced</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="23"/>
        <source>Permissions</source>
        <translation>Permissões</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="35"/>
        <source>Allow applying operations without administrator privileges</source>
        <translation>Permitir aplicar operações sem privilégios de administrador</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="51"/>
        <source>Backend</source>
        <translation>Back-end</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="57"/>
        <source>Active backend:</source>
        <translation>Back-end ativo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="79"/>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="85"/>
        <source>Preferred unit:</source>
        <translation>Unidade preferida:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="96"/>
        <source>Byte</source>
        <translation>Byte</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="101"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="106"/>
        <source>MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="111"/>
        <source>GiB</source>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="116"/>
        <source>TiB</source>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="121"/>
        <source>PiB</source>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepageadvanced.ui" line="126"/>
        <source>EiB</source>
        <translation>EiB</translation>
    </message>
</context>
<context>
    <name>ConfigurePageFileSystemColors</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="23"/>
        <source>File Systems</source>
        <translation>Sistemas de Arquivos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="29"/>
        <source>luks:</source>
        <translation>luks:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="45"/>
        <source>ntfs:</source>
        <translation>ntfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="58"/>
        <source>ext2:</source>
        <translation>ext2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="87"/>
        <source>ext3:</source>
        <translation>ext3:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="116"/>
        <source>ext4:</source>
        <translation>ext4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="132"/>
        <source>btrfs:</source>
        <translation>btrfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="174"/>
        <source>linuxswap:</source>
        <translation>linuxswap:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="190"/>
        <source>fat16:</source>
        <translation>fat16:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="219"/>
        <source>fat32:</source>
        <translation>fat32:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="248"/>
        <source>zfs:</source>
        <translation>zfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="264"/>
        <source>reiserfs:</source>
        <translation>reiserfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="293"/>
        <source>reiser4:</source>
        <translation>reiser4:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="322"/>
        <source>hpfs:</source>
        <translation>hpfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="338"/>
        <source>jfs</source>
        <translation>jfs</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="367"/>
        <source>hfs:</source>
        <translation>hfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="396"/>
        <source>hfsplus:</source>
        <translation>hfsplus:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="412"/>
        <source>ufs:</source>
        <translation>ufs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="441"/>
        <source>xfs:</source>
        <translation>xfs:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="470"/>
        <source>ocfs2:</source>
        <translation>ocfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="489"/>
        <source>extended:</source>
        <translation>extended:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="518"/>
        <source>unformatted:</source>
        <translation>não formatado:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="547"/>
        <source>unknown:</source>
        <translation>desconhecido:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="570"/>
        <source>exfat:</source>
        <translation>exfat:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="583"/>
        <source>nilfs2:</source>
        <translation>nilfs2:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagefilesystemcolors.ui" line="622"/>
        <source>lvm2 pv:</source>
        <translation>lvm2 pv:</translation>
    </message>
</context>
<context>
    <name>ConfigurePageGeneral</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="23"/>
        <source>Partition Alignment</source>
        <translation>Alinhamento de partição</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="29"/>
        <source>Use cylinder based alignment (Windows XP compatible)</source>
        <translation>Use o alinhamento baseado em cilindro (compatível com Windows XP)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="42"/>
        <source>Sector alignment:</source>
        <translation>Alinhamento de setor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="55"/>
        <source> sectors</source>
        <translation>setores</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="71"/>
        <source>Align partitions per default</source>
        <translation>Alinhe partições por padrão</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="90"/>
        <source>Logging</source>
        <translation>Logging</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="96"/>
        <source>Hide messages below:</source>
        <translation>Esconder mensagens abaixo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="107"/>
        <source>Debug</source>
        <translation>Depuração</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="112"/>
        <source>Information</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="117"/>
        <source>Warning</source>
        <translation>Atenção</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="122"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="139"/>
        <source>File Systems</source>
        <translation>Sistemas de arquivos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="145"/>
        <source>Default file system:</source>
        <translation>Sistema de arquivos padrão:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="167"/>
        <source>Shredding</source>
        <translation>Apagando</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="173"/>
        <source>Overwrite with:</source>
        <translation>Sobrescrever com:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="180"/>
        <source>Random data</source>
        <translation>Dados aleatórios</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/config/configurepagegeneral.ui" line="190"/>
        <source>Zeros</source>
        <translation>Zeros</translation>
    </message>
</context>
<context>
    <name>CreatePartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="14"/>
        <source>Create a Partition</source>
        <translation>Criar uma partição</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="38"/>
        <source>Partition &amp;Type:</source>
        <translation>&amp;Tipo da partição:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="50"/>
        <source>&amp;Primary</source>
        <translation>&amp;Primária</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="60"/>
        <source>E&amp;xtended</source>
        <translation>E&amp;xtendida</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="89"/>
        <source>F&amp;ile System:</source>
        <translation>S&amp;istema de Arquivos:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="118"/>
        <source>&amp;Mount Point:</source>
        <translation>Ponto de &amp;Montagem:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="164"/>
        <source>Si&amp;ze:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.ui" line="174"/>
        <source> MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="95"/>
        <source>Logical</source>
        <translation>Lógica</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="100"/>
        <source>Primary</source>
        <translation>Primária</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionDialog.cpp" line="117"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
</context>
<context>
    <name>CreatePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="47"/>
        <source>Create partition (file system: %1, size: %2 MB) on %3.</source>
        <translation>Criar partição (sistema de arquivos: %1, tamanho %2 MB) em %3.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="60"/>
        <source>The installer failed to create partition on disk &apos;%1&apos;.</source>
        <translation>O instalador não conseguiu criar partições no disco &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="69"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Não foi possível abrir o dispositivo &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="79"/>
        <source>Could not open partition table.</source>
        <translation>Não foi possível abrir a tabela de partições.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="103"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>O instalador não conseguiu criar o sistema de arquivos na partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionJob.cpp" line="111"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>O instalador falhou ao atualizar a tabela de partição no disco &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="20"/>
        <source>Create Partition Table</source>
        <translation>Criar tabela de partições</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="39"/>
        <source>Creating a new partition table will delete all existing data on the disk.</source>
        <translation>Criando uma nova tabela de partição irá apagar todos os dados existentes no disco.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="65"/>
        <source>What kind of partition table do you want to create?</source>
        <translation>Você deseja criar que tipo de tabela de partições?</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="72"/>
        <source>Master Boot Record (MBR)</source>
        <translation>Master Boot Record (MBR)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/CreatePartitionTableDialog.ui" line="82"/>
        <source>GUID Partition Table (GPT)</source>
        <translation>GUID Partition Table (GPT)</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="48"/>
        <source>Create partition table</source>
        <translation>Criar tabela de partições</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="55"/>
        <source>The installer failed to create a partition table on %1.</source>
        <translation>O instalador não conseguiu criar uma tabela de partições em %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/CreatePartitionTableJob.cpp" line="63"/>
        <source>Could not open device %1.</source>
        <translation>Não foi possível abrir o dispositivo %1.</translation>
    </message>
</context>
<context>
    <name>CreatePartitionTableWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="20"/>
        <source>Choose the type of partition table you want to create:</source>
        <translation>Escolha o tipo de tabela de partições que deseja criar:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="29"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="39"/>
        <source>MS-Dos</source>
        <translation>MS-Dos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="66"/>
        <source>(icon)</source>
        <translation>(ícone)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/createpartitiontablewidgetbase.ui" line="79"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; This will destroy all data on the device!</source>
        <translation>&lt;b&gt;Atenção:&lt;/b&gt; Isso apagará todos os dados no dispositivo!</translation>
    </message>
</context>
<context>
    <name>CreateUserJob</name>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="51"/>
        <source>Create user %1</source>
        <translation>Criar usuário %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="67"/>
        <source>Sudoers dir is not writable.</source>
        <translation>O diretório do superusuário não é gravável.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="71"/>
        <source>Cannot create sudoers file for writing.</source>
        <translation>Impossível criar arquivo do superusuário para gravação.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="79"/>
        <source>Cannot chmod sudoers file.</source>
        <translation>Impossível alterar permissões do arquivo do superusuário.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="85"/>
        <source>Cannot open groups file for reading.</source>
        <translation>Impossível abrir arquivos do grupo para leitura.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="123"/>
        <source>Cannot create user %1.</source>
        <translation>Impossível criar o usuário %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="125"/>
        <source>useradd terminated with error code %1.</source>
        <translation>useradd terminou com código de erro %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="130"/>
        <source>Cannot set full name for user %1.</source>
        <translation>Impossível definir o nome completo para o usuário %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="132"/>
        <source>chfn terminated with error code %1.</source>
        <translation>chfn terminou com código de erro %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="141"/>
        <source>Cannot set home directory ownership for user %1.</source>
        <translation>Impossível definir proprietário da pasta pessoal para o usuário %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/CreateUserJob.cpp" line="143"/>
        <source>chown terminated with error code %1.</source>
        <translation>chown terminou com código de erro %1.</translation>
    </message>
</context>
<context>
    <name>DecryptLuksDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="22"/>
        <source>&amp;Name:</source>
        <translation>&amp;Nome:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/decryptluksdialogwidgetbase.ui" line="35"/>
        <source>&amp;Passphrase:</source>
        <translation>&amp;Senha:</translation>
    </message>
</context>
<context>
    <name>DeletePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="41"/>
        <source>Delete partition %1</source>
        <translation>Apagar partição %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="48"/>
        <source>The installer failed to delete partition %1.</source>
        <translation>O instalador não conseguiu apagar a partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="54"/>
        <source>Partition (%1) and device (%2) do not match.</source>
        <translation>Partição (%1) e dispositivo (%2) não correspondem.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="66"/>
        <source>Could not open device %1.</source>
        <translation>Não foi possível abrir o dispositivo %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/DeletePartitionJob.cpp" line="75"/>
        <source>Could not open partition table.</source>
        <translation>Não foi possível abrir a tabela de partições.</translation>
    </message>
</context>
<context>
    <name>DeviceModel</name>
    <message>
        <location filename="../src/modules/partition/core/DeviceModel.cpp" line="79"/>
        <source>%1 - %2 (%3)</source>
        <translation>%1 - %2 (%3)</translation>
    </message>
</context>
<context>
    <name>DevicePropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="58"/>
        <source>Partition table:</source>
        <translation>Tabela de partições:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="77"/>
        <source>Cylinder alignment</source>
        <translation>Alinhamento baseado no cilindro</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="84"/>
        <source>Sector based alignment</source>
        <translation>Alinhamento baseado no setor</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="113"/>
        <source>Capacity:</source>
        <translation>Capacidade:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="130"/>
        <source>Total sectors:</source>
        <translation>Total de setores:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="160"/>
        <source>Cylinders/Heads/Sectors:</source>
        <translation>Cilindros/Cabeças/Setores:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="183"/>
        <source>Logical sector size:</source>
        <translation>Tamanho do setor lógico:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="200"/>
        <source>Physical sector size:</source>
        <translation>Tamanho do setor físico:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="217"/>
        <source>Cylinder size:</source>
        <translation>Tamanho do cilindro:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="241"/>
        <source>Primaries/Max:</source>
        <translation>Primários/Máx:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="265"/>
        <source>SMART status:</source>
        <translation>Estado (SMART):</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/devicepropswidgetbase.ui" line="303"/>
        <source>More...</source>
        <translation>Mais...</translation>
    </message>
</context>
<context>
    <name>EditExistingPartitionDialog</name>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="20"/>
        <source>Edit Existing Partition</source>
        <translation>Editar Partição Existente</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="50"/>
        <source>Content:</source>
        <translation>Conteúdo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="60"/>
        <source>Keep</source>
        <translation>Manter</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="70"/>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="83"/>
        <source>Warning: Formatting the partition will erase all existing data.</source>
        <translation>Atenção: A formatação apagará todos os dados existentes.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="93"/>
        <source>&amp;Mount Point:</source>
        <translation>Ponto de &amp;Montagem:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EditExistingPartitionDialog.ui" line="113"/>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
</context>
<context>
    <name>EditMountOptionsDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="14"/>
        <source>Edit Mount Options</source>
        <translation>Editar Opções de Montagem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountoptionsdialogwidgetbase.ui" line="20"/>
        <source>Edit the mount options for this file system:</source>
        <translation>Editar opções de montagem para este sistema de arquivos:</translation>
    </message>
</context>
<context>
    <name>EditMountPointDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="17"/>
        <source>Path:</source>
        <translation>Caminho:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="46"/>
        <source>Select...</source>
        <translation>Selecione...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="53"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="63"/>
        <source>Options:</source>
        <translation>Opções:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="73"/>
        <source>Read-only</source>
        <translation>Somente leitura</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="80"/>
        <source>Users can mount and unmount</source>
        <translation>Os usuários podem montar e desmontar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="87"/>
        <source>No automatic mount</source>
        <translation>Sem montagem automática</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="94"/>
        <source>No update of file access times</source>
        <translation>Sem atualização nos tempos de acesso do arquivo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="101"/>
        <source>Synchronous access</source>
        <translation>Acesso síncrono</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="108"/>
        <source>No update of directory access times</source>
        <translation>Sem atualização nos tempos de acesso do diretório</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="115"/>
        <source>No binary execution</source>
        <translation>Sem execução binária</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="122"/>
        <source>Update access times relative to modification</source>
        <translation>Atualiza os tempos de acesso relativo à modificações</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="142"/>
        <source>More...</source>
        <translation>Mais...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="149"/>
        <source>Dump Frequency:</source>
        <translation>Frequência de Esvaziamento:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="178"/>
        <source>Pass Number:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="285"/>
        <source>Device Node</source>
        <translation>Nó do dispositivo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="295"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="302"/>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/editmountpointdialogwidgetbase.ui" line="309"/>
        <source>Identify by:</source>
        <translation>Identificar por:</translation>
    </message>
</context>
<context>
    <name>EraseDiskPage</name>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="53"/>
        <source>Select drive:</source>
        <translation>Selecione o drive:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="229"/>
        <source>Before:</source>
        <translation>Antes:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/EraseDiskPage.cpp" line="234"/>
        <source>After:</source>
        <translation>Depois:</translation>
    </message>
</context>
<context>
    <name>FileSystemSupportDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="17"/>
        <source>This table shows which file systems are supported and which specific operations can be performed on them.
Some file systems need external tools to be installed for them to be supported. But not all operations can be performed on all file systems, even if all required tools are installed. Please see the documentation for details. </source>
        <translation>Esta tabela mostra os sistemas de arquivos suportados e as operações possíveis de serem executadas.
Alguns sistemas de arquivos necessitam de ferramentas externas para serem suportados. Contudo, mesmo com todas as ferramentas instaladas, nem todas as operações podem ser realizadas em todos os sistemas de arquivo. Consulte a documentação para maiores informações.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="65"/>
        <source>File System</source>
        <translation>Sistema de Arquivos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="70"/>
        <source>Create</source>
        <translation>Criar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="75"/>
        <source>Grow</source>
        <translation>Aumentar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="80"/>
        <source>Shrink</source>
        <translation>Diminuir</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="85"/>
        <source>Move</source>
        <translation>Mover</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="90"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="95"/>
        <source>Check</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="100"/>
        <source>Read Label</source>
        <translation>Ler Rótulo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="105"/>
        <source>Write Label</source>
        <translation>Gravar Rótulo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="110"/>
        <source>Read Usage</source>
        <translation>Verificar o Uso</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="115"/>
        <source>Backup</source>
        <translation>Cópia de segurança</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="120"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="125"/>
        <source>Support Tools</source>
        <translation>Ferramentas Auxiliares</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/filesystemsupportdialogwidgetbase.ui" line="135"/>
        <source>Rescan Support</source>
        <comment>@action:button</comment>
        <translation>Suporte para Novo Exame</translation>
    </message>
</context>
<context>
    <name>FillGlobalStorageJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="75"/>
        <source>Set partition information</source>
        <translation>Definir informações da partição</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FillGlobalStorageJob.cpp" line="85"/>
        <source>Failed to find path for boot loader</source>
        <translation>Falha ao encontrar o inicalizador</translation>
    </message>
</context>
<context>
    <name>FinishedPage</name>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.ui" line="77"/>
        <source>&amp;Restart now</source>
        <translation>&amp;Reiniciar agora</translation>
    </message>
    <message>
        <location filename="../src/modules/finished/FinishedPage.cpp" line="50"/>
        <source>&lt;h1&gt;All done.&lt;/h1&gt;&lt;br/&gt;%1 has been installed on your computer.&lt;br/&gt;You may now restart into your new system, or continue using the %2 Live environment.</source>
        <translation>&lt;h1&gt;Tudo pronto.&lt;/h1&gt;&lt;br/&gt;%1 foi instalado no seu computador.&lt;br/&gt;Agora você pode reiniciar seu novo sistema, ou continuar usando o %2 o ambiente Live.</translation>
    </message>
</context>
<context>
    <name>FinishedViewStep</name>
    <message>
        <location filename="../src/modules/finished/FinishedViewStep.cpp" line="43"/>
        <source>All done</source>
        <translation>Tudo pronto</translation>
    </message>
</context>
<context>
    <name>FormatPartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="47"/>
        <source>Format partition %1 (file system: %2, size: %3 MB) on %4.</source>
        <translation>Formatar partição %1 (sistema de arquivos: %2, tamanho: %3 MB) em %4.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="59"/>
        <source>The installer failed to format partition %1 on disk &apos;%2&apos;.</source>
        <translation>O instalador falhou em formatar a partição %1 no disco &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="67"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Não foi possível abrir o dispositivo &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="76"/>
        <source>Could not open partition table.</source>
        <translation>Não foi possível abrir a tabela de partições.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="84"/>
        <source>The installer failed to create file system on partition %1.</source>
        <translation>O instalador falhou ao criar o sistema de aquivos na partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/FormatPartitionJob.cpp" line="92"/>
        <source>The installer failed to update partition table on disk &apos;%1&apos;.</source>
        <translation>O instalador falhou ao atualizar a tabela de partições no disco &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>GreetingPage</name>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="126"/>
        <source>&lt;h1&gt;Welcome to the %1 installer.&lt;/h1&gt;&lt;br/&gt;This program will ask you some questions and set up %2 on your computer.</source>
        <translation>&lt;h1&gt;Bem-vindo ao instalador do %1.&lt;/h1&gt;&lt;br/&gt;Esse programa fará algumas perguntas e instalará o %2 no computador.</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="144"/>
        <source>About %1 installer</source>
        <translation>Sobre %1 intalador</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="146"/>
        <source>&lt;h1&gt;%1&lt;/h1&gt;&lt;br/&gt;&lt;b&gt;%2&lt;br/&gt;for %3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;Copyright 2014 Teo Mrnjavac &amp;lt;teo@kde.org&amp;gt;&lt;br/&gt;Thanks to: Anke Boersma, Aurélien Gâteau, Kevin Kofler, Philip Müller, Pier Luigi Fiorini and Rohan Garg.&lt;br/&gt;&lt;br/&gt;&lt;a href=&quot;https://calamares.io/&quot;&gt;Calamares&lt;/a&gt; development is sponsored by &lt;br/&gt;&lt;a href=&quot;http://www.blue-systems.com/&quot;&gt;Blue Systems&lt;/a&gt; - technologies for a better world.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.cpp" line="176"/>
        <source>%1 support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="104"/>
        <source>&amp;Release notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="114"/>
        <source>&amp;Known issues</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="124"/>
        <source>&amp;Support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/modules/greeting/GreetingPage.ui" line="134"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
</context>
<context>
    <name>GreetingViewStep</name>
    <message>
        <location filename="../src/modules/greeting/GreetingViewStep.cpp" line="43"/>
        <source>Welcome</source>
        <translation>Bem vindo</translation>
    </message>
</context>
<context>
    <name>KeyboardPage</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="200"/>
        <source>Set keyboard model to %1.&lt;br/&gt;</source>
        <translation>Definir o modelo de teclado para %1.&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.cpp" line="202"/>
        <source>Set keyboard layout to %1/%2.</source>
        <translation>Definir o layout do teclado para %1/%2.</translation>
    </message>
</context>
<context>
    <name>KeyboardViewStep</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardViewStep.cpp" line="48"/>
        <source>Keyboard</source>
        <translation>Teclado</translation>
    </message>
</context>
<context>
    <name>LCLocaleDialog</name>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="33"/>
        <source>System locale setting</source>
        <translation>Definição de localidade do sistema</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LCLocaleDialog.cpp" line="40"/>
        <source>The system locale setting affects the language and character set for some command line user interface elements.&lt;br/&gt;The current setting is &lt;b&gt;%1&lt;/b&gt;.</source>
        <translation>A configuração de localidade do sistema afeta a linguagem e o conjunto de caracteres para algumas linhas de comando e elementos da interface do usuário.&lt;br/&gt;A configuração atual é &lt;b&gt;%1&lt;/b&gt;.</translation>
    </message>
</context>
<context>
    <name>LocalePage</name>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="159"/>
        <location filename="../src/modules/locale/LocalePage.cpp" line="170"/>
        <source>The system locale is set to %1.</source>
        <translation>A localidade do sistema está definida para %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="167"/>
        <source>Region:</source>
        <translation>Região:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="168"/>
        <source>Zone:</source>
        <translation>Área:</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="173"/>
        <source>&amp;Change...</source>
        <translation>&amp;Mudar...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocalePage.cpp" line="267"/>
        <source>Set timezone to %1/%2.&lt;br/&gt;</source>
        <translation>Definir o fuso horário para %1/%2.&lt;br/&gt;</translation>
    </message>
</context>
<context>
    <name>LocaleViewStep</name>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="45"/>
        <source>Loading location data...</source>
        <translation>Carregando dados de localização...</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/LocaleViewStep.cpp" line="79"/>
        <source>Location</source>
        <translation>Localização</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>Gestor de Partições do KDE</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="24"/>
        <source>Devices</source>
        <comment>@title:window</comment>
        <translation>Dispositivos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="38"/>
        <source>Pending Operations</source>
        <comment>@title:window</comment>
        <translation>Operações pendentes</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="49"/>
        <source>Information</source>
        <comment>@title:window</comment>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/mainwindowbase.ui" line="63"/>
        <source>Log Output</source>
        <comment>@title:window</comment>
        <translation>Log de saída</translation>
    </message>
</context>
<context>
    <name>MoveFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="66"/>
        <source>Move file system of partition %1.</source>
        <translation>Mover sistema de arquivos para partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="80"/>
        <source>Could not open file system on partition %1 for moving.</source>
        <translation>Não foi possível abrir o sistema de arquivos na partição %1 para mover.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="86"/>
        <source>Could not create target for moving file system on partition %1.</source>
        <translation>Não foi possível criar o alvo para mover o sistema de aquivos na partição %1</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="95"/>
        <source>Moving of partition %1 failed, changes have been rolled back.</source>
        <translation>Impossível mover a partição %1 e as alterações foram revertidas.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="101"/>
        <source>Moving of partition %1 failed. Roll back of the changes have failed.</source>
        <translation>Impossível mover a partição %1 e as alterações não foram revertidas.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="113"/>
        <source>Updating boot sector after the moving of partition %1 failed.</source>
        <translation>Atualização de setor de boot da partição %1 falhou.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="127"/>
        <source>The logical sector sizes in the source and target for copying are not the same. This is currently unsupported.</source>
        <translation>O tamanho de setor lógico do destino e da fonte não são os mesmos. Esta operação não é suportada atualmente.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="200"/>
        <source>Source and target for copying do not overlap: Rollback is not required.</source>
        <translation>Origem e alvo da cópia não coincidem: a reversão não é necessária.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="224"/>
        <location filename="../src/modules/partition/jobs/MoveFileSystemJob.cpp" line="232"/>
        <source>Could not open device %1 to rollback copying.</source>
        <translation>Não foi possível abrir o dispositivo %1 para reverter a cópia.</translation>
    </message>
</context>
<context>
    <name>Page_Keyboard</name>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="70"/>
        <source>Keyboard Model:</source>
        <translation>Modelo de teclado:</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/KeyboardPage.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Escreva aqui para testar o seu teclado</translation>
    </message>
</context>
<context>
    <name>Page_UserSetup</name>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="33"/>
        <source>What is your name?</source>
        <translation>Qual é o seu nome?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="111"/>
        <source>What name do you want to use to log in?</source>
        <translation>Qual nome você quer usar para entrar?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="191"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="319"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="425"/>
        <location filename="../src/modules/users/page_usersetup.ui" line="553"/>
        <source>font-weight: normal</source>
        <translation>fonte: normal</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="194"/>
        <source>&lt;small&gt;If more than one person will use this computer, you can set up multiple accounts after installation.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Se mais de uma pessoa usará este computador, você pode definir múltiplas contas após a instalação.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="217"/>
        <source>Choose a password to keep your account safe.</source>
        <translation>Escolha uma senha para mantar a sua conta segura.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="322"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors. A good password will contain a mixture of letters, numbers and punctuation, should be at least eight characters long, and should be changed at regular intervals.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Digite a mesma senha duas vezes, de modo que possam ser verificados erros de digitação. Uma boa senha contém uma mistura de letras, números e sinais de pontuação, deve ter pelo menos oito caracteres e deve ser alterada em intervalos regulares.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="345"/>
        <source>What is the name of this computer?</source>
        <translation>Qual é o nome deste computador?</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="428"/>
        <source>&lt;small&gt;This name will be used if you make the computer visible to others on a network.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Este nome será usado caso você deixe o computador visível a outros na rede.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="451"/>
        <source>Choose a password for the administrator account.</source>
        <translation>Escolha uma senha para a conta administradora.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="556"/>
        <source>&lt;small&gt;Enter the same password twice, so that it can be checked for typing errors.&lt;/small&gt;</source>
        <translation>&lt;small&gt;Digite a mesma senha duas vezes para que possa ser checada contra erros de digitação.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="596"/>
        <source>Log in automatically</source>
        <translation>Fazer login automático</translation>
    </message>
    <message>
        <location filename="../src/modules/users/page_usersetup.ui" line="606"/>
        <source>Require my password to log in</source>
        <translation>Exigir minha senha para entrar</translation>
    </message>
</context>
<context>
    <name>PartPropsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="49"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>Sistema de arquivos:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="65"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>Rótulo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="82"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>Este sistema de arquivos não suporta etiquetas.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="92"/>
        <source>Recreate existing file system</source>
        <comment>@action:button</comment>
        <translation>Recriando sistema de arquivos existente</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="106"/>
        <source>Mount point:</source>
        <comment>@label</comment>
        <translation>Ponto de montagem:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="123"/>
        <source>Partition type:</source>
        <comment>@label</comment>
        <translation>Tipo de partição:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="140"/>
        <source>Status:</source>
        <comment>@label</comment>
        <translation>Estado:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="157"/>
        <source>UUID:</source>
        <comment>@label</comment>
        <translation>UUID:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="187"/>
        <source>Size:</source>
        <comment>@label</comment>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="210"/>
        <source>Available:</source>
        <comment>@label partition capacity available</comment>
        <translation>Disponível:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="227"/>
        <source>Used:</source>
        <comment>@label partition capacity used</comment>
        <translation>Usado:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="251"/>
        <source>First sector:</source>
        <comment>@label</comment>
        <translation>Primeiro setor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="268"/>
        <source>Last sector:</source>
        <comment>@label</comment>
        <translation>Último setor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="285"/>
        <source>Number of sectors:</source>
        <comment>@label</comment>
        <translation>Número de setores:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partpropswidgetbase.ui" line="309"/>
        <source>Flags:</source>
        <comment>@label</comment>
        <translation>Flags:</translation>
    </message>
</context>
<context>
    <name>PartitionManagerWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="14"/>
        <source>KDE Partition Manager</source>
        <comment>@title:window</comment>
        <translation>Gerenciador de partições do KDE</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="70"/>
        <source>Partition</source>
        <translation>Partição</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="75"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="80"/>
        <source>Mount Point</source>
        <translation>Ponto de montagem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="85"/>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="90"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="95"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="100"/>
        <source>Used</source>
        <translation>Usado</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="105"/>
        <source>Available</source>
        <translation>Disponível</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="110"/>
        <source>First Sector</source>
        <translation>Primeiro setor</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="115"/>
        <source>Last Sector</source>
        <translation>Último setor</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="120"/>
        <source>Number of Sectors</source>
        <translation>Número de setores</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/partitionmanagerwidgetbase.ui" line="125"/>
        <source>Flags</source>
        <translation>Flags</translation>
    </message>
</context>
<context>
    <name>PartitionModel</name>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="132"/>
        <source>Free Space</source>
        <translation>Espaço livre</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="136"/>
        <source>New partition</source>
        <translation>Nova partição</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="175"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="177"/>
        <source>File System</source>
        <translation>Sistema de arquivos</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="179"/>
        <source>Mount Point</source>
        <translation>Ponto de montagem</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/core/PartitionModel.cpp" line="181"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
</context>
<context>
    <name>PartitionPage</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>&amp;Disco:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="51"/>
        <source>&amp;Revert All Changes</source>
        <translation>&amp;Reverter todas as alterações</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="84"/>
        <source>New Partition &amp;Table</source>
        <translation>Nova Tabela de Partições</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="104"/>
        <source>&amp;Create</source>
        <translation>&amp;Criar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="111"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="118"/>
        <source>&amp;Delete</source>
        <translation>&amp;Deletar</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.ui" line="145"/>
        <source>&amp;Install boot loader on:</source>
        <translation>&amp;Instalar o gerenciador de boot em:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionPage.cpp" line="135"/>
        <source>Are you sure you want to create a new partition table on %1?</source>
        <translation>Você tem certeza de que deseja criar uma nova tabela de partição em %1?</translation>
    </message>
</context>
<context>
    <name>PartitionViewStep</name>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="66"/>
        <source>Gathering system information...</source>
        <translation>Coletando informações do sistema...</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="160"/>
        <source>Partitions</source>
        <translation>Partições</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="188"/>
        <source>Before:</source>
        <translation>Antes:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/PartitionViewStep.cpp" line="193"/>
        <source>After:</source>
        <translation>Depois:</translation>
    </message>
</context>
<context>
    <name>PreparePage</name>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="39"/>
        <source>For best results, please ensure that this computer:</source>
        <translation>Para melhores resultados, por favor certifique-se de que este computador:</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="96"/>
        <source>This computer does not satisfy the minimum requirements for installing %1.
Installation cannot continue.</source>
        <translation>Este computador não satisfaz os requisitos mínimos para a instalação %1.
A instalação não pode continuar.</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PreparePage.cpp" line="109"/>
        <source>This computer does not satisfy some of the recommended requirements for installing %1.
Installation can continue, but some features might be disabled.</source>
        <translation>Este computador não satisfaz algumas das recomendações para instalação do %1.
A instalação pode continuar, mas alguns recursos podem ser desativados.</translation>
    </message>
</context>
<context>
    <name>PrepareViewStep</name>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="54"/>
        <source>Gathering system information...</source>
        <translation>Recolhendo informações do sistema...</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="91"/>
        <source>has at least %1 GB available drive space</source>
        <translation>tem pelo menos %1 GB de espaço disponível no disco</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="99"/>
        <source>has at least %1 GB working memory</source>
        <translation>tem pelo menos %1 GB de memória</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="107"/>
        <source>is plugged in to a power source</source>
        <translation>está ligado à uma fonte de energia</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="114"/>
        <source>is connected to the Internet</source>
        <translation>está conectado a internet</translation>
    </message>
    <message>
        <location filename="../src/modules/prepare/PrepareViewStep.cpp" line="158"/>
        <source>Prepare</source>
        <translation>Preparar</translation>
    </message>
</context>
<context>
    <name>ProgressTreeModel</name>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="138"/>
        <source>Prepare</source>
        <translation>Preparar</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="151"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/calamares/progresstree/ProgressTreeModel.cpp" line="161"/>
        <source>Finish</source>
        <translation>Finalizar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="82"/>
        <source>Default Keyboard Model</source>
        <translation>Modelo de teclado padrão</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="127"/>
        <location filename="../src/modules/keyboard/keyboardwidget/keyboardglobal.cpp" line="163"/>
        <source>Default</source>
        <translation>Padrão</translation>
    </message>
</context>
<context>
    <name>ReleaseDialog</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="20"/>
        <source>KDE Release Builder</source>
        <translation>KDE Release Builder</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="32"/>
        <source>Application</source>
        <translation>Aplicação</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="38"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="48"/>
        <source>&amp;Version:</source>
        <translation>&amp;Versão:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="93"/>
        <source>Repository and Revision</source>
        <translation>Repositório e Revisão</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="99"/>
        <source>&amp;Checkout From:</source>
        <translation>&amp;Verificar de:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="119"/>
        <source>trunk</source>
        <translation>tronco</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="124"/>
        <source>branches</source>
        <translation>ramificações</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="129"/>
        <source>tags</source>
        <translation>etiquetas</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="137"/>
        <source>Ta&amp;g/Branch:</source>
        <translation>Etiqueta/Ramificação</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="163"/>
        <source>&amp;SVN Access:</source>
        <translation>Acesso &amp;SVN:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="183"/>
        <source>anonsvn</source>
        <translation>anonsvn</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="188"/>
        <source>https</source>
        <translation>https</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="193"/>
        <source>svn+ssh</source>
        <translation>svn+ssh</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="201"/>
        <source>&amp;User:</source>
        <translation>&amp;Usuário:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="236"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="242"/>
        <source>Get &amp;Documentation</source>
        <translation>Obter &amp;Documentação</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="252"/>
        <source>Get &amp;Translations</source>
        <translation>Obter &amp;Traduções</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="262"/>
        <source>C&amp;reate Tag</source>
        <translation>C&amp;riar Etiqueta</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="271"/>
        <source>S&amp;kip translations below completion:</source>
        <translation>Pular traduções incompletas:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="306"/>
        <source> %</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="324"/>
        <source>Create Tar&amp;ball</source>
        <translation>Criar Tar&amp;ball</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/scripts/release/releasedialog.ui" line="334"/>
        <source>Apply &amp;fixes</source>
        <translation>Aplicar &amp;correções</translation>
    </message>
</context>
<context>
    <name>ReplacePage</name>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.ui" line="22"/>
        <source>&amp;Disk:</source>
        <translation>&amp;Disco:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="109"/>
        <source>Select where to install %1.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;this will delete all files on the selected partition.</source>
        <translation>Selecione onde instalar %1.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Aviso: &lt;/font&gt;isso irá apagar todos os arquivos na partição selecionada.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="136"/>
        <source>The selected item does not appear to be a valid partition.</source>
        <translation>O item selecionado não parece ser uma partição válida.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="144"/>
        <source>%1 cannot be installed on empty space. Please select an existing partition.</source>
        <translation>%1 não pode ser instalado no espaço vazio. Por favor, selecione uma partição existente.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="155"/>
        <source>%1 cannot be installed on an extended partition. Please select an existing primary or logical partition.</source>
        <translation>%1 não pode ser instalado numa partição estendida. Por favor selecione uma partição primária ou partição lógica existente. </translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="166"/>
        <source>%1 cannot be installed on this partition.</source>
        <translation>%1 não pode ser instalado nesta partição.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="173"/>
        <source>Data partition (%1)</source>
        <translation>Partição de dados (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="190"/>
        <source>Unknown system partition (%1)</source>
        <translation>Partição do sistema desconhecida (%1)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="195"/>
        <source>%1 system partition (%2)</source>
        <translation>%1 Partição do sistema (%2)</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="206"/>
        <source>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;The partition %1 is too small for %2. Please select a partition with capacity at least %3 GiB.</source>
        <translation>&lt;b&gt;%4&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;A partição %1 é pequena para %2. Por favor selecione um partição com capacidade de pelo menos %3 GiB.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/gui/ReplacePage.cpp" line="220"/>
        <source>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 will be installed on %2.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Warning: &lt;/font&gt;all data on partition%2 will be lost.</source>
        <translation>&lt;b&gt;%3&lt;/b&gt;&lt;br/&gt;&lt;br/&gt;%1 Será instalado em %2.&lt;br/&gt;&lt;font color=&quot;red&quot;&gt;Aviso: &lt;/font&gt;todos os dados na partição%2 serão perdidos.</translation>
    </message>
</context>
<context>
    <name>ResizeFileSystemJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="75"/>
        <source>Resize file system on partition %1.</source>
        <translation>Redimensionar o sistema de arquivos na partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="90"/>
        <source>Parted failed to resize filesystem.</source>
        <translation>Parted falhou ao redimensionar o sistema de arquivos.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="100"/>
        <source>Failed to resize filesystem.</source>
        <translation>Falha ao redimensionar o sistema de arquivos.</translation>
    </message>
</context>
<context>
    <name>ResizePartitionJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="186"/>
        <source>Resize partition %1.</source>
        <translation>Redimensionar partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="208"/>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="266"/>
        <source>The installer failed to resize partition %1 on disk &apos;%2&apos;.</source>
        <translation>O instalador falhou em redimensionar a partição %1 no disco &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="213"/>
        <source>Could not open device &apos;%1&apos;.</source>
        <translation>Não foi possível abrir o dispositivo &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>SetHostNameJob</name>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="36"/>
        <source>Set hostname %1</source>
        <translation>Definir nome da máquina %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="46"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="53"/>
        <source>Internal Error</source>
        <translation>Erro interno</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="60"/>
        <location filename="../src/modules/users/SetHostNameJob.cpp" line="71"/>
        <source>Cannot write hostname to target system</source>
        <translation>Não é possível gravar o nome da máquina para o sistema alvo</translation>
    </message>
</context>
<context>
    <name>SetKeyboardLayoutJob</name>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="57"/>
        <source>Set keyboard model to %1, layout to %2-%3</source>
        <translation>Definir modelo de teclado para %1, layout para %2-%3</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="284"/>
        <source>Failed to write keyboard configuration for the virtual console.</source>
        <translation>Falha ao gravar a configuração do teclado para o console virtual.</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="285"/>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="289"/>
        <source>Failed to write to %1</source>
        <translation>Falha ao gravar no %1</translation>
    </message>
    <message>
        <location filename="../src/modules/keyboard/SetKeyboardLayoutJob.cpp" line="288"/>
        <source>Failed to write keyboard configuration for X11.</source>
        <translation>Falha ao gravar a configuração do teclado para X11.</translation>
    </message>
</context>
<context>
    <name>SetPartGeometryJob</name>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="143"/>
        <source>Update geometry of partition %1.</source>
        <translation>Atualizar geometria da partição %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/jobs/ResizePartitionJob.cpp" line="155"/>
        <source>Failed to change the geometry of the partition.</source>
        <translation>Falha ao alterar a geometria da partição</translation>
    </message>
</context>
<context>
    <name>SetPasswordJob</name>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="42"/>
        <source>Set password for user %1</source>
        <translation>Definir senha para usuário %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="52"/>
        <source>Bad destination system path.</source>
        <translation>O caminho para o sistema está mal direcionado.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="53"/>
        <source>rootMountPoint is %1</source>
        <translation>Ponto de Montagem do root é %1</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="62"/>
        <source>Cannot set password for user %1.</source>
        <translation>Impossível definir senha para o usuário %1.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/SetPasswordJob.cpp" line="64"/>
        <source>usermod terminated with error code %1.</source>
        <translation>usermod terminou com código de erra %1.</translation>
    </message>
</context>
<context>
    <name>SetTimezoneJob</name>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="41"/>
        <source>Set timezone to %1/%2</source>
        <translation>Definir fuso horário para %1/%2</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="56"/>
        <source>Cannot access selected timezone path.</source>
        <translation>Não é possível acessar o caminho do fuso horário selecionado.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="57"/>
        <source>Bad path: %1</source>
        <translation>Direcionamento ruim: %1</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="69"/>
        <source>Cannot set timezone.</source>
        <translation>Não foi possível definir o fuso horário.</translation>
    </message>
    <message>
        <location filename="../src/modules/locale/SetTimezoneJob.cpp" line="70"/>
        <source>Link creation failed, target: %1; link name: %2</source>
        <translation>Não foi possível criar o link, alvo: %1; nome: %2</translation>
    </message>
</context>
<context>
    <name>SizeDetailsWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="62"/>
        <source>First sector:</source>
        <comment>@label:listbox</comment>
        <translation>Primeiro setor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="97"/>
        <source>Last sector:</source>
        <comment>@label:listbox</comment>
        <translation>Último Setor:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedetailswidgetbase.ui" line="120"/>
        <source>Align partition</source>
        <translation>Alinhar partição</translation>
    </message>
</context>
<context>
    <name>SizeDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="55"/>
        <source>Partition type:</source>
        <comment>@label:listbox</comment>
        <translation>Tipo de partição:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="70"/>
        <source>Primary</source>
        <translation>Primária</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="77"/>
        <source>Extended</source>
        <translation>Extendida</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="84"/>
        <source>Logical</source>
        <translation>Lógica</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="99"/>
        <source>File system:</source>
        <comment>@label:listbox</comment>
        <translation>Sistema de arquivos:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="115"/>
        <source>Label:</source>
        <comment>@label</comment>
        <translation>Etiqueta:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="134"/>
        <source>This file system does not support setting a label.</source>
        <comment>@label</comment>
        <translation>Este sistema de arquivos não suporta etiquetas.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="152"/>
        <source>Minimum size:</source>
        <comment>@label</comment>
        <translation>Tamanho mínimo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="175"/>
        <source>Maximum size:</source>
        <comment>@label</comment>
        <translation>Tamanho máximo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="198"/>
        <source>Free space before:</source>
        <comment>@label:listbox</comment>
        <translation>Espaço livre anterior:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="233"/>
        <source>Size:</source>
        <comment>@label:listbox</comment>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/sizedialogwidgetbase.ui" line="262"/>
        <source>Free space after:</source>
        <comment>@label:listbox</comment>
        <translation>Espaço livre posterior:</translation>
    </message>
</context>
<context>
    <name>SmartDialogWidgetBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="23"/>
        <source>SMART status:</source>
        <translation>Estado do SMART:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="63"/>
        <source>Model:</source>
        <translation>Modelo:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="92"/>
        <source>Serial number:</source>
        <translation>Número de Série:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="121"/>
        <source>Firmware revision:</source>
        <translation>Revisão de Firmware:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="150"/>
        <source>Temperature:</source>
        <translation>Temperatura:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="179"/>
        <source>Bad sectors:</source>
        <translation>Setores ruins:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="208"/>
        <source>Powered on for:</source>
        <translation>Ligado há:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="237"/>
        <source>Power cycles:</source>
        <translation>Ciclos de potência:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="289"/>
        <source>Id</source>
        <translation>Id</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="294"/>
        <source>Attribute</source>
        <translation>Atributo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="299"/>
        <source>Failure Type</source>
        <translation>Tipo de falha</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="304"/>
        <source>Update Type</source>
        <translation>Tipo de atualização</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="309"/>
        <source>Worst</source>
        <translation>Pior</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="314"/>
        <source>Current</source>
        <translation>Atual</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="319"/>
        <source>Threshold</source>
        <translation>Limite</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="324"/>
        <source>Raw</source>
        <translation>Não tratado</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="329"/>
        <source>Assessment</source>
        <translation>Avaliação</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="334"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="385"/>
        <source>Overall assessment:</source>
        <translation>Avaliação geral:</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/smartdialogwidgetbase.ui" line="414"/>
        <source>Self tests:</source>
        <translation>Auto-testes:</translation>
    </message>
</context>
<context>
    <name>SummaryViewStep</name>
    <message>
        <location filename="../src/modules/summary/SummaryViewStep.cpp" line="41"/>
        <source>Summary</source>
        <translation>Resumo</translation>
    </message>
</context>
<context>
    <name>TreeLogBase</name>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="54"/>
        <source>Sev.</source>
        <comment>@title:column Severity of a log entry / log level. Text must be very short.</comment>
        <translation>Sev.</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="57"/>
        <source>Severity</source>
        <translation>Severidade</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="62"/>
        <source>Time</source>
        <comment>@title:column a time stamp of a log entry</comment>
        <translation>Tempo</translation>
    </message>
    <message>
        <location filename="../src/modules/partition/partitionmanager/src/gui/treelogbase.ui" line="67"/>
        <source>Message</source>
        <comment>@title:column the text message of a log entry</comment>
        <translation>Mensagem</translation>
    </message>
</context>
<context>
    <name>UsersPage</name>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="233"/>
        <source>Your username is too long.</source>
        <translation>O nome de usuário é grande demais.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="243"/>
        <source>Your username contains invalid characters. Only lowercase letters and numbers are allowed.</source>
        <translation>O nome de usuário contém caracteres inválidos. Apenas letras minúsculas e números são permitidos.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="287"/>
        <source>Your hostname is too short.</source>
        <translation>O nome da máquina é muito curto.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="298"/>
        <source>Your hostname is too long.</source>
        <translation>O nome da máquina é muito grande.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="309"/>
        <source>Your hostname contains invalid characters. Only letters, numbers and dashes are allowed.</source>
        <translation>O nome da máquina contém caracteres inválidos. Apenas letras, números e traços são permitidos.</translation>
    </message>
    <message>
        <location filename="../src/modules/users/UsersPage.cpp" line="340"/>
        <location filename="../src/modules/users/UsersPage.cpp" line="373"/>
        <source>Your passwords do not match!</source>
        <translation>As senhas não estão iguais!</translation>
    </message>
</context>
<context>
    <name>UsersViewStep</name>
    <message>
        <location filename="../src/modules/users/UsersViewStep.cpp" line="46"/>
        <source>Users</source>
        <translation>Usuários</translation>
    </message>
</context>
</TS>