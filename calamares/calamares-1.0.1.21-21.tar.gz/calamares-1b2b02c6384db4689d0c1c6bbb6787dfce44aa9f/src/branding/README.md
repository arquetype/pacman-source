# Branding directory

Branding components go here.

A branding component is a subdirectory with a branding.desc descriptor file, containing brand-specific strings in a key-value structure, plus brand-specific images. Such a subdirectory, when placed here, is automatically picked up by CMake and made available to Calamares.
